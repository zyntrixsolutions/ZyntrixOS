# FastAPI + PostgreSQL

Production-ready Python REST API with async SQLAlchemy, Redis caching, and JWT auth.

## Getting started

```bash
zyntrix run install    # install Python deps
zyntrix run migrate    # run Alembic migrations
zyntrix run dev        # start server → http://localhost:8000/docs
```

## Stack

- **FastAPI** — async Python web framework
- **PostgreSQL 16** + **Redis 7** — managed by Podman devbox containers
- **SQLAlchemy 2** (async) + **Alembic** — ORM + migrations
- **Pydantic v2** — data validation
- **Ruff** — linting + formatting
