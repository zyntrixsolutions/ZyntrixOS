# Local LLM Agent

Python agent running on a local Ollama model. No API keys. No cloud.

## Getting started

```bash
zyntrix run install      # install dependencies
zyntrix run pull-model   # pull llama3.2 (~2GB, one-time)
zyntrix run dev          # run agent.py
```

Ollama must be running (`zyntrix run serve` or from the Agents tile).

## Stack

- **Ollama** — local LLM runtime (llama3.2 by default, swap in zyntrix.toml)
- **LangChain** — agent framework
- **Rich** — beautiful terminal output
- Runs fully offline after model pull
