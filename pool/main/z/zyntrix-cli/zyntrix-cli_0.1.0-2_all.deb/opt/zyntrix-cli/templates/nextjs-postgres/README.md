# Next.js + PostgreSQL

Full-stack Next.js app with PostgreSQL database and Prisma ORM.

## Getting started

```bash
zyntrix run install    # install dependencies
zyntrix run migrate    # run database migrations
zyntrix run dev        # start dev server → http://localhost:3000
```

## Stack

- **Next.js 14** — React framework (App Router)
- **PostgreSQL 16** — managed by Podman devbox container
- **Prisma** — type-safe ORM
- **Tailwind CSS** — utility CSS

## Environment

Variables are set automatically by `zyntrix open`. Edit `zyntrix.toml` to add
secrets (never commit real credentials).
