# Node.js REST API

Lightweight Express API with PostgreSQL, JWT auth, and native Node test runner.

## Getting started

```bash
zyntrix run install    # npm install
zyntrix run migrate    # create tables
zyntrix run dev        # start with --watch → http://localhost:4000
```

## Stack

- **Express 5** — minimal HTTP framework
- **PostgreSQL 16** — managed by Podman devbox container
- **pg** — native Postgres driver (no ORM overhead)
- **Node --watch** — built-in hot-reload (no nodemon needed)
- **Node --test** — built-in test runner
