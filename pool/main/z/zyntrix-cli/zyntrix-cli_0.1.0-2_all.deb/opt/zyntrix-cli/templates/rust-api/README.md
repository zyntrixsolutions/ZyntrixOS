# Rust API — Axum + SQLite

Minimal, blazing-fast REST API in Rust. No external DB container required.

## Getting started

```bash
zyntrix run dev       # cargo watch — rebuilds on file change → http://localhost:3000
zyntrix run test      # cargo test
zyntrix run build     # release binary → target/release/rust-api
```

## Stack

- **Axum** — ergonomic async Rust web framework
- **SQLite** via **sqlx** — embedded database, zero ops overhead
- **Tokio** — async runtime
- **cargo-watch** — hot-reload on save
