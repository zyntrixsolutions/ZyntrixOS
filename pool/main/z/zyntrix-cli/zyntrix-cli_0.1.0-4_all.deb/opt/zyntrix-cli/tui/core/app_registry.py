"""App registry wrapper for tiles.py and appdb.py."""
import os
import sys
import subprocess

_CORE_DIR = os.path.dirname(os.path.realpath(__file__))
_SHELL_CANDIDATES = (
    "/opt/zyntrix-shell",
    os.path.abspath(os.path.join(_CORE_DIR, "..", "..", "..", "shell")),
)

for _shell_dir in _SHELL_CANDIDATES:
    if os.path.exists(os.path.join(_shell_dir, "tiles.py")):
        if _shell_dir not in sys.path:
            sys.path.insert(0, _shell_dir)
        break

from tiles import load_config as load_tiles
from appdb import get_apps, search, prewarm


class AppRegistry:
    """Unified interface to ZyntrixOS app sources."""

    def __init__(self):
        prewarm()
        self._tiles = load_tiles()

    def list_builtin(self):
        """Return built-in tiles."""
        return [
            {
                "id": t.id,
                "name": t.label,
                "subtitle": t.subtitle,
                "icon": t.icon,
                "command": t.command,
                "fallbacks": t.fallbacks,
            }
            for t in self._tiles
        ]

    def list_installed(self):
        """Return .desktop apps."""
        return get_apps()

    def search(self, query: str):
        """Search across all sources."""
        query = query.lower()
        results = []
        for t in self._tiles:
            if query in t.label.lower() or query in t.subtitle.lower():
                results.append({
                    "id": t.id, "name": t.label,
                    "subtitle": t.subtitle, "icon": t.icon,
                    "command": t.command, "source": "builtin",
                })
        for a in get_apps():
            if query in a.get("name", "").lower():
                results.append({
                    **a, "source": "desktop",
                })
        return results

    def get_info(self, app_id: str):
        """Get detailed app info."""
        for t in self._tiles:
            if t.id == app_id:
                return {
                    "id": t.id, "name": t.label,
                    "description": t.subtitle,
                    "icon": t.icon,
                    "command": t.command,
                }
        for a in get_apps():
            if a.get("name") == app_id:
                return a
        return None
