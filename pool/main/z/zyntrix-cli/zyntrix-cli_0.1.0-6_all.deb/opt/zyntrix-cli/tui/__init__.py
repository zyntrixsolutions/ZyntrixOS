"""ZyntrixOS Terminal User Interface (TUI) package."""

__version__ = "0.1.0"
