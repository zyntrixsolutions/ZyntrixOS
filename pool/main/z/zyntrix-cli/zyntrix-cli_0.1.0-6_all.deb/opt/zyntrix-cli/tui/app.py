"""Main Textual App for zyntrix-tui."""
import os
from textual.app import App

from .screens import (
    HomeScreen, AppsScreen, StoreScreen,
    MonitorScreen, WindowsScreen, SettingsScreen, HelpScreen,
)
from .core.term_detect import detect_capabilities

# Get absolute path to theme file
_THEME_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "themes")


class ZyntrixTUI(App):
    """ZyntrixOS Terminal User Interface."""

    CSS_PATH = os.path.join(_THEME_DIR, "zyntrix.css")
    TITLE = "ZyntrixOS TUI"
    SUB_TITLE = "Control your entire PC from the terminal"

    SCREENS = {
        "home": HomeScreen,
        "apps": AppsScreen,
        "store": StoreScreen,
        "monitor": MonitorScreen,
        "windows": WindowsScreen,
        "settings": SettingsScreen,
        "help": HelpScreen,
    }

    def __init__(self, start_screen: str = "home", mouse: bool = True, **kwargs):
        super().__init__(**kwargs)
        self._start_screen = start_screen
        self._mouse = mouse
        self._caps = detect_capabilities()

    def on_mount(self):
        self.push_screen(self._start_screen)

    def check_action(self, action: str, parameters: tuple):
        if action == "quit":
            self.push_screen("quit")
        return True

    def action_quit(self):
        from textual.screen import ModalScreen
        from textual.widgets import Static, Button
        from textual.containers import Vertical

        class QuitModal(ModalScreen[bool]):
            def compose(self):
                with Vertical(id="quit-modal"):
                    yield Static("Are you sure you want to quit?")
                    yield Button("Yes", id="yes", variant="error")
                    yield Button("No", id="no", variant="primary")

            def on_button_pressed(self, event):
                if event.button.id == "yes":
                    self.dismiss(True)
                else:
                    self.dismiss(False)

        def on_quit(result):
            if result:
                self.exit()

        self.push_screen(QuitModal(), on_quit)
