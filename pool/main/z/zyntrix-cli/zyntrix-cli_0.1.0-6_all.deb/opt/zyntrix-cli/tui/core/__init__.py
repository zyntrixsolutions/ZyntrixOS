"""Core backend integration modules for zyntrix-tui."""

from .sysinfo import SysInfo
from .app_registry import AppRegistry
from .wm_client import WMClient
from .launcher import TUILauncher
from .term_detect import detect_capabilities

__all__ = ["SysInfo", "AppRegistry", "WMClient", "TUILauncher", "detect_capabilities"]
