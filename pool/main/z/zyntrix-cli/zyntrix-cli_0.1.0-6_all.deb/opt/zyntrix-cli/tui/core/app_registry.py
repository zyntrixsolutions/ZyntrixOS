"""App registry wrapper for tiles.py and appdb.py."""
import os
import sys
import subprocess

_CORE_DIR = os.path.dirname(os.path.realpath(__file__))
_SHELL_CANDIDATES = (
    "/opt/zyntrix-shell",
    os.path.abspath(os.path.join(_CORE_DIR, "..", "..", "..", "shell")),
)

for _shell_dir in _SHELL_CANDIDATES:
    if os.path.exists(os.path.join(_shell_dir, "tiles.py")):
        if _shell_dir not in sys.path:
            sys.path.insert(0, _shell_dir)
        break

from tiles import load_tiles
from appdb import get_apps, search, prewarm


def _flatten_tiles(items):
    """Yield tile-like objects from nested config/list shapes."""
    for item in items or []:
        if isinstance(item, (list, tuple)):
            yield from _flatten_tiles(item)
        else:
            yield item


def _tile_get(tile, key, default=None):
    if isinstance(tile, dict):
        return tile.get(key, default)
    return getattr(tile, key, default)


def _argv(value):
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return value if isinstance(value, list) else list(value)


def _fallbacks(value):
    result = []
    for entry in value or []:
        result.append(_argv(entry))
    return result


def _tile_to_app(tile):
    app_id = _tile_get(tile, "id")
    name = _tile_get(tile, "label", _tile_get(tile, "name", app_id or "App"))
    if not app_id:
        return None
    return {
        "id": app_id,
        "name": name,
        "subtitle": _tile_get(tile, "subtitle", ""),
        "icon": _tile_get(tile, "icon", "applications-other"),
        "command": _argv(_tile_get(tile, "command", [])),
        "fallbacks": _fallbacks(_tile_get(tile, "fallbacks", [])),
    }


class AppRegistry:
    """Unified interface to ZyntrixOS app sources."""

    def __init__(self):
        prewarm()
        self._tiles = [
            app for app in (_tile_to_app(tile) for tile in _flatten_tiles(load_tiles()))
            if app is not None
        ]

    def list_builtin(self):
        """Return built-in tiles."""
        return [
            dict(app)
            for app in self._tiles
        ]

    def list_installed(self):
        """Return .desktop apps."""
        return get_apps()

    def search(self, query: str):
        """Search across all sources."""
        query = query.lower()
        results = []
        for app in self._tiles:
            if query in app["name"].lower() or query in app["subtitle"].lower():
                results.append({
                    **app, "source": "builtin",
                })
        for a in get_apps():
            if query in a.get("name", "").lower():
                results.append({
                    **a, "source": "desktop",
                })
        return results

    def get_info(self, app_id: str):
        """Get detailed app info."""
        for app in self._tiles:
            if app["id"] == app_id:
                return {
                    "id": app["id"], "name": app["name"],
                    "description": app["subtitle"],
                    "icon": app["icon"],
                    "command": app["command"],
                }
        for a in get_apps():
            if a.get("name") == app_id:
                return a
        return None
