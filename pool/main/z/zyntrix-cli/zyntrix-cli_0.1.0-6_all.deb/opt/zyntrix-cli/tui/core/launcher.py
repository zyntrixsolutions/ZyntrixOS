"""App launcher with shell coordination."""
import os
import subprocess
import signal
import time
import threading


class TUILauncher:
    """Launch apps with GTK shell coordination."""

    def __init__(self):
        self._children = {}
        self._lock = threading.Lock()

    def _signal_shell(self, sig: int) -> None:
        """Signal GTK shell to minimize/restore."""
        try:
            result = subprocess.run(
                ["pgrep", "-f", "main.py"],
                capture_output=True, text=True, timeout=2
            )
            for pid in result.stdout.strip().split():
                try:
                    os.kill(int(pid), sig)
                except Exception:
                    pass
        except Exception:
            pass

    def minimize_shell(self):
        self._signal_shell(signal.SIGUSR1)

    def restore_shell(self):
        self._signal_shell(signal.SIGUSR2)

    def launch(self, command: list, fallbacks: list = None) -> bool:
        """Launch app with fallback chain."""
        candidates = [command] + (fallbacks or [])
        self.minimize_shell()

        for cmd in candidates:
            if not cmd:
                continue
            exe = cmd[0]
            if not self._resolve(exe):
                continue
            try:
                proc = subprocess.Popen(
                    cmd, env=os.environ.copy(),
                    start_new_session=True,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                with self._lock:
                    self._children[proc.pid] = proc
                threading.Thread(target=self._watch, args=(proc,), daemon=True).start()
                return True
            except Exception:
                continue

        self.restore_shell()
        return False

    def _watch(self, proc):
        proc.wait()
        time.sleep(0.1)
        self.restore_shell()
        with self._lock:
            self._children.pop(proc.pid, None)

    @staticmethod
    def _resolve(exe: str) -> str:
        if os.path.isabs(exe):
            return exe if os.path.isfile(exe) else ""
        for d in os.environ.get("PATH", "").split(":"):
            full = os.path.join(d, exe)
            if os.access(full, os.X_OK):
                return full
        return ""
