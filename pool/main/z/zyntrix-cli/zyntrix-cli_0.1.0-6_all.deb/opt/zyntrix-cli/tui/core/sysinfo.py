"""System information collector for zyntrix-tui."""
import os
import time
from collections import deque


class SysInfo:
    """Collects system resource data."""

    def __init__(self):
        self._cpu_history = deque(maxlen=60)
        self._prev_cpu = None
        self._last_check = 0.0

    def _read(self, path):
        try:
            with open(path) as f:
                return f.read()
        except Exception:
            return ""

    def cpu_stats(self):
        lines = self._read("/proc/stat").splitlines()
        stats = []
        for line in lines:
            if not line.startswith("cpu"):
                break
            parts = line.split()
            stats.append([int(x) for x in parts[1:]])
        return stats

    def cpu_percent(self):
        now = time.time()
        if now - self._last_check < 0.5:
            return self._cpu_history[-1] if self._cpu_history else 0.0
        self._last_check = now

        stats = self.cpu_stats()
        if not stats or not self._prev_cpu:
            self._prev_cpu = stats
            return 0.0

        s1, s2 = self._prev_cpu[0], stats[0]
        total = sum(s2) - sum(s1)
        idle = (s2[3] + s2[4]) - (s1[3] + s1[4])
        pct = 0.0 if total == 0 else max(0.0, min(100.0, (1 - idle / total) * 100))
        self._prev_cpu = stats
        self._cpu_history.append(pct)
        return pct

    def cpu_history(self):
        return list(self._cpu_history)

    def mem_info(self):
        data = {}
        for line in self._read("/proc/meminfo").splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                try:
                    data[k.strip()] = int(v.split()[0])
                except Exception:
                    pass
        total = data.get("MemTotal", 0)
        avail = data.get("MemAvailable", 0)
        return {
            "total_kb": total, "used_kb": total - avail,
            "pct": ((total - avail) / total * 100) if total else 0.0,
            "swap_total_kb": data.get("SwapTotal", 0),
            "swap_used_kb": data.get("SwapTotal", 0) - data.get("SwapFree", 0),
        }

    def uptime(self):
        try:
            return float(self._read("/proc/uptime").split()[0])
        except Exception:
            return 0.0

    def hostname(self):
        return os.uname().nodename

    def battery(self):
        try:
            return int(self._read("/sys/class/power_supply/BAT0/capacity"))
        except Exception:
            return None

    def disk_partitions(self):
        parts = []
        for line in self._read("/proc/mounts").splitlines():
            cols = line.split()
            if len(cols) < 2:
                continue
            dev, mp = cols[0], cols[1]
            if not dev.startswith("/"):
                continue
            if any(mp.startswith(x) for x in ("/proc", "/sys", "/dev", "/run")):
                continue
            try:
                st = os.statvfs(mp)
                total = st.f_blocks * st.f_frsize
                free = st.f_bavail * st.f_frsize
                parts.append({
                    "dev": dev, "mp": mp, "total": total,
                    "used": total - free, "free": free,
                    "pct": ((total - free) / total * 100) if total else 0.0,
                })
            except Exception:
                pass
        return parts

    def processes(self):
        procs = []
        for pid in os.listdir("/proc"):
            if not pid.isdigit():
                continue
            try:
                with open(f"/proc/{pid}/stat") as f:
                    stat = f.read().split()
                with open(f"/proc/{pid}/status") as f:
                    status = f.read()
                name = stat[1].strip("()")
                cpu = float(stat[13]) + float(stat[14])
                mem = 0
                for line in status.splitlines():
                    if line.startswith("VmRSS:"):
                        mem = int(line.split()[1])
                        break
                procs.append({
                    "pid": int(pid), "name": name,
                    "cpu": cpu, "mem": mem,
                })
            except Exception:
                pass
        return sorted(procs, key=lambda p: p["cpu"], reverse=True)[:20]
