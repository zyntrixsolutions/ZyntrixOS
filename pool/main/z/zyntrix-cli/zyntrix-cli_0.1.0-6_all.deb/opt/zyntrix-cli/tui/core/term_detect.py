"""Terminal capability detection for zyntrix-tui."""

import os
import sys


def detect_capabilities() -> dict:
    """Detect terminal capabilities for graceful degradation."""
    cap = {
        "true_color": False,
        "256_color": False,
        "mouse": False,
        "unicode": False,
        "emoji": False,
        "size": (80, 24),
        "sixel": False,
    }

    try:
        import textual
        cap["textual"] = True
    except ImportError:
        cap["textual"] = False
        return cap

    # True color detection
    term = os.environ.get("TERM", "")
    colorterm = os.environ.get("COLORTERM", "")
    if "truecolor" in colorterm.lower() or "24bit" in colorterm.lower():
        cap["true_color"] = True
    if "256" in term or "256" in colorterm.lower():
        cap["256_color"] = True

    # Mouse support
    if os.environ.get("TERM_PROGRAM") in ("iTerm.app", "WezTerm", "kitty"):
        cap["mouse"] = True
    if "xterm" in term.lower() or "screen" in term.lower() or "tmux" in term.lower():
        cap["mouse"] = True

    # Unicode / emoji
    lang = os.environ.get("LANG", "")
    if "utf" in lang.lower():
        cap["unicode"] = True
        cap["emoji"] = True

    # Terminal size
    try:
        size = os.get_terminal_size()
        cap["size"] = (size.columns, size.lines)
    except Exception:
        pass

    # Kitty graphics / sixel
    if "kitty" in term.lower():
        cap["sixel"] = True
    if os.environ.get("TERM_PROGRAM") == "iTerm.app":
        cap["sixel"] = True

    return cap


def supports_true_color() -> bool:
    return detect_capabilities()["true_color"]


def supports_mouse() -> bool:
    return detect_capabilities()["mouse"]


def get_term_size() -> tuple[int, int]:
    return detect_capabilities()["size"]
