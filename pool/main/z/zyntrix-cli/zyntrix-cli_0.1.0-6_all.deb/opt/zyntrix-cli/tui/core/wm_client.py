"""Window manager client for herbstluftwm."""
import shutil
import subprocess


class WMClient:
    """herbstluftwm client interface."""

    def __init__(self):
        self._hc = shutil.which("herbstclient") or ""

    def _run(self, args: list, timeout: float = 0.8) -> str:
        if not self._hc:
            return ""
        try:
            return subprocess.check_output(
                [self._hc] + args, text=True, timeout=timeout, stderr=subprocess.DEVNULL
            ).strip()
        except Exception:
            return ""

    def get_workspaces(self) -> list[dict]:
        """Return all 9 workspace states."""
        wss = []
        try:
            tags = self._run(["tag_status"]).split("\t")
            for i, t in enumerate(tags[1:], 1):
                wss.append({
                    "idx": i,
                    "name": str(i),
                    "occupied": t[0] in ("#", "+", ":", "!", "-", "%"),
                    "current": t[0] == "#",
                })
        except Exception:
            for i in range(1, 10):
                wss.append({"idx": i, "name": str(i), "occupied": False, "current": i == 1})
        return wss

    def get_windows(self, workspace: int = None) -> list[dict]:
        """Return windows in current or specified workspace."""
        wins = []
        if workspace:
            self._run(["use_index", str(workspace - 1)])
        try:
            out = self._run(["clients"])
            for wid in out.split():
                title = self._run(["get_attr", f"clients.{wid}.title"])
                cls = self._run(["get_attr", f"clients.{wid}.class"])
                wins.append({
                    "wid": wid, "title": title, "class": cls,
                    "workspace": workspace,
                })
        except Exception:
            pass
        return wins

    def switch_workspace(self, idx: int) -> bool:
        return bool(self._run(["use_index", str(idx - 1)]))

    def focus_window(self, wid: str) -> bool:
        return bool(self._run(["jumpto", wid]))

    def close_window(self, wid: str) -> bool:
        return bool(self._run(["close", wid]))

    def move_window(self, wid: str, workspace: int) -> bool:
        return bool(self._run(["move_index", str(workspace - 1), wid]))

    def toggle_float(self, wid: str) -> bool:
        return bool(self._run(["set_attr", f"clients.{wid}.floating", "toggle"]))

    def get_layout(self) -> str:
        return self._run(["get_attr", "tags.focus.layout"])

    def set_layout(self, name: str) -> bool:
        return bool(self._run(["set_layout", name]))
