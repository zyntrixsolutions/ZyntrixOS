"""Screens for zyntrix-tui."""
from .home import HomeScreen
from .apps import AppsScreen
from .store import StoreScreen
from .monitor import MonitorScreen
from .windows import WindowsScreen
from .settings import SettingsScreen
from .help import HelpScreen

__all__ = [
    "HomeScreen", "AppsScreen", "StoreScreen",
    "MonitorScreen", "WindowsScreen", "SettingsScreen", "HelpScreen"
]
