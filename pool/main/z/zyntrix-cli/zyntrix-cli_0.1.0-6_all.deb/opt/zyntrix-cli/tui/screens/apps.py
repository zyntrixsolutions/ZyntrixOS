"""Apps screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import DataTable, Static, Input, Label
from textual.containers import Horizontal, Vertical


class AppsScreen(Screen):
    """Installed apps manager screen."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
        ("/", "search", "Search"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def compose(self):
        from textual.widgets import Header, Footer
        yield Header()
        yield Input(placeholder="Search apps...", id="search")
        with Horizontal():
            with Vertical(id="list-pane"):
                table = DataTable(id="apps-table")
                table.add_columns("Name", "Source", "Version")
                yield table
            with Vertical(id="detail-pane"):
                yield Static("Select an app", id="details")
        yield Footer()

    def on_mount(self):
        from ..core.app_registry import AppRegistry
        registry = AppRegistry()
        table = self.query_one("#apps-table", DataTable)
        for app in registry.list_installed()[:50]:
            table.add_row(
                app.get("name", "Unknown"),
                app.get("source", "desktop"),
                "",
            )

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()
