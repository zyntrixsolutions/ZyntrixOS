"""Help screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import Tree, Markdown
from textual.containers import Horizontal


class HelpScreen(Screen):
    """Interactive help browser."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
    ]

    HELP_TEXT = """
# ZyntrixOS TUI Help

## Quick Start
The TUI provides keyboard-driven control of your system.

## Navigation
- **h** - Home screen
- **a** - App manager
- **s** - Store
- **m** - System monitor
- **w** - Windows
- **,** - Settings
- **?** - This help

## Keybindings
- **Tab/Shift+Tab** - Navigate widgets
- **Arrow keys/hjkl** - Move selection
- **Enter** - Activate
- **q** - Quit

## Monitor
View CPU, memory, network, and disk usage.
Press **k** to kill selected process.

## Windows
Manage herbstluftwm workspaces and windows.
Press **1-9** to switch workspaces.
"""

    def compose(self):
        from textual.widgets import Header, Footer
        yield Header()
        with Horizontal():
            tree = Tree("Help Topics", id="topics")
            tree.root.add_leaf("Quick Start")
            tree.root.add_leaf("Navigation")
            tree.root.add_leaf("Apps")
            tree.root.add_leaf("Store")
            tree.root.add_leaf("Monitor")
            tree.root.add_leaf("Windows")
            tree.root.add_leaf("Shortcuts")
            tree.root.add_leaf("FAQ")
            yield tree
            yield Markdown(self.HELP_TEXT, id="content")
        yield Footer()

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()
