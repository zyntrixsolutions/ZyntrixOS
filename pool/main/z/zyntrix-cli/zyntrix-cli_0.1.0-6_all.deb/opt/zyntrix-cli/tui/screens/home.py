"""Home screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import Header, Footer
from textual.containers import Grid
from textual.reactive import reactive

from ..widgets.app_card import AppCard
from ..widgets.sidebar import Sidebar
from ..widgets.status_bar import StatusBar
from ..core.sysinfo import SysInfo
from ..core.app_registry import AppRegistry
from ..core.launcher import TUILauncher


class HomeScreen(Screen):
    """Main home screen with app grid."""

    BINDINGS = [
        ("h", "go_home", "Home"),
        ("a", "go_apps", "Apps"),
        ("s", "go_store", "Store"),
        ("m", "go_monitor", "Monitor"),
        ("w", "go_windows", "Windows"),
        ("comma", "go_settings", "Settings"),
        ("q", "quit", "Quit"),
        ("question", "go_help", "Help"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.sysinfo = SysInfo()
        self.registry = AppRegistry()
        self.launcher = TUILauncher()

    def compose(self):
        from textual.containers import Horizontal, Vertical
        yield Header(show_clock=True)
        with Horizontal():
            yield Sidebar(self.sysinfo)
            with Vertical(id="main"):
                yield Grid(id="app-grid")
        yield StatusBar(self.sysinfo)

    def on_mount(self):
        grid = self.query_one("#app-grid", Grid)
        grid.columns = 4
        for app in self.registry.list_builtin():
            card = AppCard(app)
            card.styles.margin = 1
            grid.mount(card)

    def action_go_home(self):
        pass

    def action_go_apps(self):
        self.app.switch_screen("apps")

    def action_go_store(self):
        self.app.switch_screen("store")

    def action_go_monitor(self):
        self.app.switch_screen("monitor")

    def action_go_windows(self):
        self.app.switch_screen("windows")

    def action_go_settings(self):
        self.app.switch_screen("settings")

    def action_go_help(self):
        self.app.switch_screen("help")

    def action_quit(self):
        self.app.exit()

    def on_app_card_app_selected(self, event: AppCard.AppSelected):
        app = event.app_data
        self.launcher.launch(app.get("command", []), app.get("fallbacks", []))
