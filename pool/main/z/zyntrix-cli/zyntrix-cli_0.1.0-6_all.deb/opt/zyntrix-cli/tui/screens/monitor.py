"""Monitor screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import Static, DataTable, ProgressBar
from textual.containers import Grid, Horizontal
from textual.reactive import reactive
from textual.worker import Worker

from ..core.sysinfo import SysInfo


class MonitorScreen(Screen):
    """System monitor screen."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
        ("k", "kill", "Kill"),
        ("r", "refresh", "Refresh"),
    ]

    cpu_percent = reactive(0.0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.sysinfo = SysInfo()

    def compose(self):
        from textual.widgets import Header, Footer, Label
        yield Header()
        with Grid(columns=2):
            with Static(id="cpu-panel"):
                yield Label("CPU", classes="panel-title")
                yield ProgressBar(total=100, id="cpu-bar")
                yield Static(id="cpu-text")
            with Static(id="mem-panel"):
                yield Label("Memory", classes="panel-title")
                yield ProgressBar(total=100, id="mem-bar")
                yield Static(id="mem-text")
            with Static(id="net-panel"):
                yield Label("Network", classes="panel-title")
                yield Static(id="net-text")
            with Static(id="disk-panel"):
                yield Label("Disk", classes="panel-title")
                yield Static(id="disk-text")
        table = DataTable(id="proc-table")
        table.add_columns("PID", "Name", "CPU%", "MEM%")
        yield table
        yield Footer()

    def on_mount(self):
        self.set_interval(1.0, self.update_stats)

    def update_stats(self):
        self.cpu_percent = self.sysinfo.cpu_percent()
        mem = self.sysinfo.mem_info()

        cpu_bar = self.query_one("#cpu-bar", ProgressBar)
        cpu_bar.progress = int(self.cpu_percent)

        mem_bar = self.query_one("#mem-bar", ProgressBar)
        mem_bar.progress = int(mem["pct"])

        self.query_one("#mem-text", Static).update(
            f"{mem['used_kb'] // 1024}M / {mem['total_kb'] // 1024}M"
        )

        table = self.query_one("#proc-table", DataTable)
        table.clear()
        for p in self.sysinfo.processes()[:10]:
            table.add_row(str(p["pid"]), p["name"], "0.0", str(p["mem"] // 1024))

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()

    def action_kill(self):
        pass
