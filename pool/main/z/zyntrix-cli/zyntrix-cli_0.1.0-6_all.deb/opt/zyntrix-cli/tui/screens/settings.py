"""Settings screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import TabbedContent, TabPane, Input, Select, Button, Static
from textual.containers import Vertical


class SettingsScreen(Screen):
    """Settings screen."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
    ]

    def compose(self):
        from textual.widgets import Header, Footer
        yield Header()
        with TabbedContent():
            with TabPane("General"):
                with Vertical():
                    yield Static("Hostname:")
                    yield Input(placeholder="hostname")
                    yield Static("Default Terminal:")
                    yield Select([("foot", "foot"), ("alacritty", "alacritty"), ("xterm", "xterm")])
            with TabPane("Appearance"):
                with Vertical():
                    yield Static("Theme:")
                    yield Select([("dark", "Dark"), ("light", "Light"), ("high-contrast", "High Contrast")])
                    yield Static("Accent Color:")
                    yield Select([("cyan", "Cyan"), ("green", "Green"), ("yellow", "Yellow")])
            with TabPane("System"):
                with Vertical():
                    yield Button("Check for Updates")
                    yield Button("Shutdown", variant="error")
                    yield Button("Reboot", variant="warning")
        yield Footer()

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()
