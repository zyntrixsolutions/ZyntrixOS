"""Store screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import TabbedContent, TabPane, Input, Static
from textual.containers import Vertical, Grid


class StoreScreen(Screen):
    """App store browser screen."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
    ]

    def compose(self):
        from textual.widgets import Header, Footer
        yield Header()
        with TabbedContent():
            with TabPane("Featured"):
                yield Grid(id="featured-grid")
            with TabPane("Categories"):
                yield Static("Categories: Dev, Internet, Multimedia, System, Games")
            with TabPane("Search"):
                with Vertical():
                    yield Input(placeholder="Search packages...")
                    yield Static("Search results will appear here")
            with TabPane("Installed"):
                yield Static("Installed packages")
        yield Footer()

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()
