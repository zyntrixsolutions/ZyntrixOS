"""Windows screen for zyntrix-tui."""
from textual.screen import Screen
from textual.widgets import Button, DataTable, Static
from textual.containers import Grid, Horizontal

from ..core.wm_client import WMClient


class WindowsScreen(Screen):
    """Window manager screen."""

    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("q", "quit", "Quit"),
        ("x", "close", "Close"),
        ("m", "move", "Move"),
    ]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.wm = WMClient()

    def compose(self):
        from textual.widgets import Header, Footer
        yield Header()
        yield Static("Workspaces (1-9):")
        with Grid(id="workspaces", columns=3):
            for i in range(1, 10):
                yield Button(str(i), id=f"ws-{i}")
        yield Static("Windows:")
        table = DataTable(id="windows-table")
        table.add_columns("Title", "Class", "Workspace")
        yield table
        yield Footer()

    def on_mount(self):
        self.update_workspaces()

    def update_workspaces(self):
        wss = self.wm.get_workspaces()
        for ws in wss:
            btn = self.query_one(f"#ws-{ws['idx']}", Button)
            if ws["current"]:
                btn.variant = "primary"
            elif ws["occupied"]:
                btn.variant = "success"
            else:
                btn.variant = "default"

    def on_button_pressed(self, event):
        if event.button.id and event.button.id.startswith("ws-"):
            idx = int(event.button.id.split("-")[1])
            self.wm.switch_workspace(idx)
            self.update_workspaces()

    def action_go_home(self):
        self.app.switch_screen("home")

    def action_quit(self):
        self.app.exit()

    def action_close(self):
        pass
