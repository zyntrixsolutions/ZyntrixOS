"""App card widget for zyntrix-tui."""
from textual.widgets import Static
from textual.reactive import reactive
from textual.message import Message


class AppCard(Static):
    """Selectable app tile/card."""

    DEFAULT_CSS = """
    AppCard {
        width: auto;
        height: auto;
        padding: 1 2;
        border: solid #333;
        background: $surface;
    }
    AppCard:hover {
        border: solid $accent;
    }
    AppCard.focus {
        border: solid $accent;
        background: $accent-darken-1;
    }
    AppCard .icon {
        width: auto;
        text-align: center;
        color: $accent;
    }
    AppCard .name {
        text-align: center;
        color: $text;
    }
    AppCard .subtitle {
        text-align: center;
        color: $text-muted;
    }
    """

    icon = reactive("")
    name = reactive("")
    subtitle = reactive("")
    selected = reactive(False)

    def __init__(self, app_data: dict, **kwargs):
        super().__init__(**kwargs)
        self.app_data = app_data
        self.icon = app_data.get("icon", "")
        self.name = app_data.get("name", "")
        self.subtitle = app_data.get("subtitle", "")

    def compose(self):
        from textual.widgets import Label
        yield Label(self.icon, classes="icon")
        yield Label(self.name, classes="name")
        yield Label(self.subtitle, classes="subtitle")

    def on_click(self):
        self.post_message(self.AppSelected(self.app_data))

    def watch_selected(self, selected: bool):
        self.set_class(selected, "focus")

    class AppSelected(Message):
        def __init__(self, app_data: dict):
            self.app_data = app_data
            super().__init__()
