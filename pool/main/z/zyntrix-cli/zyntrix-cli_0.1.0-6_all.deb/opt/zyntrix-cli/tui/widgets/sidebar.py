"""Sidebar widget for zyntrix-tui."""
from textual.widgets import Static
from textual.reactive import reactive


class Sidebar(Static):
    """Left navigation sidebar."""

    DEFAULT_CSS = """
    Sidebar {
        width: 20;
        height: 100%;
        background: $surface;
        border-right: solid #333;
        padding: 1;
    }
    Sidebar .item {
        padding: 1;
        color: $text-muted;
    }
    Sidebar .item.current {
        color: $accent;
        background: $accent-darken-2;
    }
    Sidebar .item:hover {
        color: $text;
    }
    """

    current_screen = reactive("home")

    SCREENS = [
        ("home", "h", "Home"),
        ("apps", "a", "Apps"),
        ("store", "s", "Store"),
        ("monitor", "m", "Monitor"),
        ("windows", "w", "Windows"),
        ("settings", ",", "Settings"),
        ("help", "?", "Help"),
    ]

    def compose(self):
        from textual.widgets import Label
        yield Label("ZyntrixOS", classes="title")
        for name, key, label in self.SCREENS:
            item = Label(f"[{key}] {label}", classes=f"item {name}")
            yield item

    def watch_current_screen(self, screen: str):
        for child in self.query(".item"):
            child.set_class(child.has_class(screen), "current")
