"""Status bar widget for zyntrix-tui."""
from textual.widgets import Static
from textual.reactive import reactive


class StatusBar(Static):
    """Bottom status bar with system info."""

    DEFAULT_CSS = """
    StatusBar {
        height: 3;
        background: $surface;
        border-top: solid #333;
        padding: 0 2;
    }
    """

    hostname = reactive("")
    uptime = reactive("")
    battery = reactive("")
    clock = reactive("")

    def __init__(self, sysinfo, **kwargs):
        super().__init__(**kwargs)
        self.sysinfo = sysinfo

    def compose(self):
        from textual.widgets import Label
        from textual.containers import Horizontal
        with Horizontal():
            yield Label(self.hostname, id="hostname")
            yield Label(self.uptime, id="uptime")
            yield Label(self.battery, id="battery")
            yield Label(self.clock, id="clock")

    def update_info(self):
        self.hostname = f" {self.sysinfo.hostname()}"
        uptime = self.sysinfo.uptime()
        hours = int(uptime / 3600)
        mins = int((uptime % 3600) / 60)
        self.uptime = f"{hours}h {mins}m"
        batt = self.sysinfo.battery()
        if batt:
            self.battery = f"{batt}%"
        else:
            self.battery = ""
