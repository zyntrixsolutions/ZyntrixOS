# ZyntrixOS ~/.bash_profile
# Auto-start X on TTY1 login (no display manager needed)

[[ -f ~/.bashrc ]] && . ~/.bashrc

if [[ -z "$DISPLAY" && "$(tty)" = "/dev/tty1" ]]; then
    exec startx -- vt1
fi
