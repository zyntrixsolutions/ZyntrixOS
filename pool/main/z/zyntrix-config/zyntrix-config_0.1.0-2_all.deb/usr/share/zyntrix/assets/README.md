# ZyntrixOS brand assets

| File | Use | Size |
|---|---|---|
| `zyntrix-logo.svg` | Source — edit this to update all derived assets | — |
| `zyntrix-logo.png` | Shell lock screen, Plymouth, Slimski | 400×480 |
| `zyntrix-logo-splash.png` | Plymouth boot splash | 300×360 |
| `login-bg.png` | Slimski login background | 1920×1080 |
| `grub-bg.png` | GRUB boot menu background | 1920×1080 |

## Replacing with the real logo

Drop the official `zyntrix-logo.png` (400×480 px, dark background) here,
then regenerate derived assets:

```bash
cd config/assets

# Login background (embeds the logo)
rsvg-convert -w 1920 -h 1080 -b '#0a0b0f' login-bg.svg -o login-bg.png

# GRUB background
rsvg-convert -w 1920 -h 1080 -b '#060708' grub-bg.svg  -o grub-bg.png

# Plymouth splash copy
cp zyntrix-logo.png ../plymouth/zyntrixos/zyntrix-logo.png

# Slimski copy
cp login-bg.png ../slim/zyntrixos/background.png
cp zyntrix-logo.png ../slim/zyntrixos/zyntrix-logo.png
cp grub-bg.png ../grub/zyntrixos-theme/background.png
```
