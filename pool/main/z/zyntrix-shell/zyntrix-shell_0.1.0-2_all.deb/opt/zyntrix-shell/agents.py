#!/usr/bin/env python3
"""
ZyntrixOS Agent Workspace Panel.
A GTK3 window combining:
  - tmux session browser (list, attach, create, kill)
  - Ollama model manager (list, pull, delete, run)
  - Live agent log tail
  - Quick-prompt bar (one-shot ollama query)
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Pango

import os
import sys
import shutil
import subprocess
import threading
import time
import json
from typing import Optional

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore

# ── Paths ─────────────────────────────────────────────────────────────────────
AGENTS_DIR    = os.path.expanduser("~/agents")
SESSIONS_DIR  = os.path.join(AGENTS_DIR, "sessions")
LOGS_DIR      = os.path.join(AGENTS_DIR, "logs")
SHELL_DIR     = os.path.dirname(os.path.abspath(__file__))
REPO_SESSIONS = os.path.join(os.path.dirname(SHELL_DIR), "agents", "sessions")

TERMINAL_CANDIDATES = ["foot", "alacritty", "kitty", "xfce4-terminal", "xterm"]

WINDOW_W, WINDOW_H = 1100, 680


# ── Helpers ───────────────────────────────────────────────────────────────────
def _find_terminal() -> list:
    for t in TERMINAL_CANDIDATES:
        if shutil.which(t):
            if t in ("foot", "alacritty", "kitty"):
                return [t, "--title", "Agents", "--"]
            if t in ("xfce4-terminal", "mate-terminal", "gnome-terminal"):
                return [t, "--title=Agents", "--"]
            return [t, "-title", "Agents", "-e"]
    return ["xterm", "-title", "Agents", "-e"]


# Cached once at import — these don't change during a session
_HAS_TMUX: bool   = shutil.which("tmux")   is not None
_HAS_OLLAMA: bool = shutil.which("ollama") is not None
_TERM_CMD: list   = _find_terminal()


def _tmux_available() -> bool:
    return _HAS_TMUX


def _ollama_available() -> bool:
    return _HAS_OLLAMA


def _run_bg(cmd: list, **kwargs) -> subprocess.Popen:
    return subprocess.Popen(cmd, start_new_session=True, **kwargs)


def _check_output(cmd: list, timeout: int = 8) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=timeout)
    except Exception:
        return ""


def _load_toml(path: str) -> dict:
    if tomllib is None:
        return {}
    try:
        with open(path, "rb") as fh:
            return tomllib.load(fh)
    except Exception:
        return {}


# ── tmux helpers ──────────────────────────────────────────────────────────────
def _tmux_sessions() -> list[dict]:
    if not _tmux_available():
        return []
    out = _check_output(["tmux", "list-sessions", "-F",
                         "#{session_name}\t#{session_windows}\t#{session_attached}"])
    sessions = []
    for line in out.strip().splitlines():
        parts = line.split("\t")
        if len(parts) >= 3:
            sessions.append({
                "name":     parts[0],
                "windows":  parts[1],
                "attached": parts[2] == "1",
            })
    return sessions


def _tmux_kill(name: str) -> None:
    subprocess.run(["tmux", "kill-session", "-t", name],
                   capture_output=True, timeout=5)


def _tmux_new(name: str, start_dir: str = AGENTS_DIR) -> None:
    os.makedirs(start_dir, exist_ok=True)
    subprocess.run(["tmux", "new-session", "-d", "-s", name, "-c", start_dir],
                   capture_output=True, timeout=5)


def _tmux_attach(name: str) -> None:
    _run_bg([*_TERM_CMD, "tmux", "attach", "-t", name])


def _launch_session_from_toml(path: str) -> Optional[str]:
    """Create a tmux session from a TOML file. Returns session name or None."""
    data = _load_toml(path)
    sess = data.get("session", {})
    name = sess.get("name", os.path.splitext(os.path.basename(path))[0])
    start_dir = os.path.expanduser(sess.get("dir", AGENTS_DIR))
    os.makedirs(start_dir, exist_ok=True)

    # Kill old session of same name if exists
    existing = [s["name"] for s in _tmux_sessions()]
    if name in existing:
        _tmux_attach(name)
        return name

    windows = data.get("window", [])
    if not windows:
        _tmux_new(name, start_dir)
        _tmux_attach(name)
        return name

    # Create session with first window
    w0 = windows[0]
    w0_dir = os.path.expanduser(w0.get("dir", start_dir))
    os.makedirs(w0_dir, exist_ok=True)
    cmd = ["tmux", "new-session", "-d", "-s", name, "-n", w0.get("name", "main"), "-c", w0_dir]
    subprocess.run(cmd, capture_output=True, timeout=5)

    if w0.get("command"):
        subprocess.run(["tmux", "send-keys", "-t", f"{name}:0",
                        w0["command"], "Enter"], capture_output=True, timeout=5)

    # Add remaining windows
    for i, w in enumerate(windows[1:], 1):
        w_dir = os.path.expanduser(w.get("dir", start_dir))
        os.makedirs(w_dir, exist_ok=True)
        subprocess.run(["tmux", "new-window", "-t", f"{name}:{i}",
                        "-n", w.get("name", f"win{i}"), "-c", w_dir],
                       capture_output=True, timeout=5)
        if w.get("command"):
            subprocess.run(["tmux", "send-keys", "-t", f"{name}:{i}",
                            w["command"], "Enter"], capture_output=True, timeout=5)

    _tmux_attach(name)
    return name


# ── Ollama helpers ────────────────────────────────────────────────────────────
def _ollama_models() -> list[dict]:
    if not _ollama_available():
        return []
    out = _check_output(["ollama", "list"])
    models = []
    for line in out.strip().splitlines()[1:]:
        parts = line.split()
        if parts:
            models.append({
                "name":     parts[0],
                "size":     parts[2] if len(parts) > 2 else "",
                "modified": " ".join(parts[3:]) if len(parts) > 3 else "",
            })
    return models


def _ollama_running() -> list[dict]:
    if not _ollama_available():
        return []
    out = _check_output(["ollama", "ps"])
    running = []
    for line in out.strip().splitlines()[1:]:
        parts = line.split()
        if parts:
            running.append({"name": parts[0], "size": parts[1] if len(parts) > 1 else ""})
    return running


def _ollama_ask(model: str, prompt: str) -> str:
    if not _ollama_available():
        return "ollama not found. Install from https://ollama.com"
    try:
        out = subprocess.check_output(
            ["ollama", "run", model, prompt],
            stderr=subprocess.DEVNULL, text=True, timeout=120
        )
        return out.strip()
    except subprocess.TimeoutExpired:
        return "[timeout — model took too long]"
    except Exception as e:
        return f"[error: {e}]"


# ── Session row ───────────────────────────────────────────────────────────────
class SessionRow(Gtk.ListBoxRow):
    def __init__(self, session: dict, on_attach, on_kill):
        super().__init__()
        self.session = session
        self.set_margin_top(2)
        self.set_margin_bottom(2)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_margin_start(14)
        box.set_margin_end(12)
        box.set_margin_top(8)
        box.set_margin_bottom(8)

        dot = Gtk.Label(label="●")
        dot.get_style_context().add_class("badge-ok" if session["attached"] else "badge-fallback")
        box.pack_start(dot, False, False, 0)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        name_lbl = Gtk.Label()
        name_lbl.set_markup(f"<b>{GLib.markup_escape_text(session['name'])}</b>")
        name_lbl.set_halign(Gtk.Align.START)
        detail_lbl = Gtk.Label(label=f"{session['windows']} window(s)  {'[attached]' if session['attached'] else ''}")
        detail_lbl.set_halign(Gtk.Align.START)
        detail_lbl.get_style_context().add_class("dim-label")
        info.pack_start(name_lbl, False, False, 0)
        info.pack_start(detail_lbl, False, False, 0)
        box.pack_start(info, True, True, 0)

        attach_btn = Gtk.Button(label="Attach")
        attach_btn.connect("clicked", lambda _: on_attach(session["name"]))
        attach_btn.set_valign(Gtk.Align.CENTER)
        box.pack_end(attach_btn, False, False, 0)

        kill_btn = Gtk.Button(label="Kill")
        kill_btn.get_style_context().add_class("destructive-action")
        kill_btn.connect("clicked", lambda _: on_kill(session["name"]))
        kill_btn.set_valign(Gtk.Align.CENTER)
        box.pack_end(kill_btn, False, False, 4)

        self.add(box)


# ── Model row ─────────────────────────────────────────────────────────────────
class ModelRow(Gtk.ListBoxRow):
    def __init__(self, model: dict, on_run, on_delete):
        super().__init__()
        self.model = model
        self.set_margin_top(2)
        self.set_margin_bottom(2)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_margin_start(14)
        box.set_margin_end(12)
        box.set_margin_top(8)
        box.set_margin_bottom(8)

        icon = Gtk.Image.new_from_icon_name("applications-science", Gtk.IconSize.MENU)
        box.pack_start(icon, False, False, 0)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        name_lbl = Gtk.Label()
        name_lbl.set_markup(f"<b>{GLib.markup_escape_text(model['name'])}</b>")
        name_lbl.set_halign(Gtk.Align.START)
        size_lbl = Gtk.Label(label=model.get("size", ""))
        size_lbl.set_halign(Gtk.Align.START)
        size_lbl.get_style_context().add_class("dim-label")
        info.pack_start(name_lbl, False, False, 0)
        info.pack_start(size_lbl, False, False, 0)
        box.pack_start(info, True, True, 0)

        run_btn = Gtk.Button(label="Run")
        run_btn.connect("clicked", lambda _: on_run(model["name"]))
        run_btn.set_valign(Gtk.Align.CENTER)
        box.pack_end(run_btn, False, False, 0)

        del_btn = Gtk.Button(label="Delete")
        del_btn.get_style_context().add_class("destructive-action")
        del_btn.connect("clicked", lambda _: on_delete(model["name"]))
        del_btn.set_valign(Gtk.Align.CENTER)
        box.pack_end(del_btn, False, False, 4)

        self.add(box)


# ── Agent Panel window ────────────────────────────────────────────────────────
class AgentsPanel(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS — Agent Workspace")
        self.set_default_size(WINDOW_W, WINDOW_H)
        self.connect("destroy", Gtk.main_quit)

        self._active_model = "llama3"
        self._refreshing: bool = False

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # ── Header ──
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.set_margin_start(18)
        header.set_margin_end(18)
        header.set_margin_top(14)
        header.set_margin_bottom(12)

        title = Gtk.Label()
        title.set_markup("<b>Agent Workspace</b>")
        title.set_halign(Gtk.Align.START)
        header.pack_start(title, True, True, 0)

        # Ollama status indicator
        self._ollama_status = Gtk.Label(label="ollama: checking…")
        self._ollama_status.set_halign(Gtk.Align.END)
        header.pack_end(self._ollama_status, False, False, 0)

        vbox.pack_start(header, False, False, 0)

        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        vbox.pack_start(sep, False, False, 0)

        # ── Paned layout: left sidebar + right content ──
        paned = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        paned.set_position(280)

        # ── Left: notebook tabs ──
        left_nb = Gtk.Notebook()
        left_nb.set_tab_pos(Gtk.PositionType.TOP)
        left_nb.append_page(self._build_sessions_tab(), Gtk.Label(label="Sessions"))
        left_nb.append_page(self._build_templates_tab(), Gtk.Label(label="Templates"))
        left_nb.append_page(self._build_models_tab(), Gtk.Label(label="Models"))
        paned.pack1(left_nb, shrink=False)

        # ── Right: log tail + prompt ──
        right_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        right_box.pack_start(self._build_log_tab(), True, True, 0)
        right_box.pack_start(self._build_prompt_bar(), False, False, 0)
        paned.pack2(right_box, shrink=False)

        vbox.pack_start(paned, True, True, 0)
        self.add(vbox)

        # Start background refresh — one-shot at 150 ms, then every 3 s
        GLib.timeout_add(150, self._initial_refresh)
        GLib.timeout_add_seconds(3, self._refresh_all)

    # ── Sessions tab ─────────────────────────────────────────────────────────
    def _build_sessions_tab(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.set_margin_start(10)
        toolbar.set_margin_end(10)
        toolbar.set_margin_top(8)
        toolbar.set_margin_bottom(6)

        new_btn = Gtk.Button(label="+ New")
        new_btn.connect("clicked", self._on_new_session)
        toolbar.pack_start(new_btn, False, False, 0)

        refresh_btn = Gtk.Button(label="↻")
        refresh_btn.connect("clicked", lambda _: self._refresh_sessions())
        toolbar.pack_end(refresh_btn, False, False, 0)

        box.pack_start(toolbar, False, False, 0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._sessions_list = Gtk.ListBox()
        self._sessions_list.set_selection_mode(Gtk.SelectionMode.NONE)
        sw.add(self._sessions_list)
        box.pack_start(sw, True, True, 0)

        return box

    # ── Templates tab ────────────────────────────────────────────────────────
    def _build_templates_tab(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        info = Gtk.Label(label="TOML session templates. Click Launch to start.")
        info.set_margin_start(10)
        info.set_margin_top(8)
        info.set_margin_bottom(6)
        info.set_halign(Gtk.Align.START)
        info.get_style_context().add_class("dim-label")
        box.pack_start(info, False, False, 0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._templates_list = Gtk.ListBox()
        self._templates_list.set_selection_mode(Gtk.SelectionMode.NONE)
        sw.add(self._templates_list)
        box.pack_start(sw, True, True, 0)

        return box

    # ── Models tab ───────────────────────────────────────────────────────────
    def _build_models_tab(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        pull_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        pull_box.set_margin_start(10)
        pull_box.set_margin_end(10)
        pull_box.set_margin_top(8)
        pull_box.set_margin_bottom(6)

        self._pull_entry = Gtk.Entry()
        self._pull_entry.set_placeholder_text("model name (e.g. llama3, mistral)")
        self._pull_entry.set_hexpand(True)
        self._pull_entry.connect("activate", self._on_pull)

        pull_btn = Gtk.Button(label="Pull")
        pull_btn.connect("clicked", self._on_pull)

        pull_box.pack_start(self._pull_entry, True, True, 0)
        pull_box.pack_start(pull_btn, False, False, 0)

        if not _ollama_available():
            warn = Gtk.Label(label="ollama not installed.\nVisit https://ollama.com")
            warn.set_margin_start(10)
            warn.set_margin_top(4)
            warn.set_halign(Gtk.Align.START)
            box.pack_start(warn, False, False, 0)

        box.pack_start(pull_box, False, False, 0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._models_list = Gtk.ListBox()
        self._models_list.set_selection_mode(Gtk.SelectionMode.NONE)
        sw.add(self._models_list)
        box.pack_start(sw, True, True, 0)

        return box

    # ── Log tab ───────────────────────────────────────────────────────────────
    def _build_log_tab(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        toolbar.set_margin_start(10)
        toolbar.set_margin_end(10)
        toolbar.set_margin_top(8)
        toolbar.set_margin_bottom(6)

        log_title = Gtk.Label(label="Agent Log")
        log_title.set_markup("<b>Agent Log</b>")
        log_title.set_halign(Gtk.Align.START)
        toolbar.pack_start(log_title, True, True, 0)

        open_log_btn = Gtk.Button(label="Open in terminal")
        open_log_btn.connect("clicked", self._on_open_log)
        toolbar.pack_end(open_log_btn, False, False, 0)

        clear_btn = Gtk.Button(label="Clear")
        clear_btn.connect("clicked", self._on_clear_log)
        toolbar.pack_end(clear_btn, False, False, 0)

        box.pack_start(toolbar, False, False, 0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)

        self._log_view = Gtk.TextView()
        self._log_view.set_editable(False)
        self._log_view.set_cursor_visible(False)
        self._log_view.set_monospace(True)
        self._log_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self._log_buf = self._log_view.get_buffer()
        sw.add(self._log_view)
        box.pack_start(sw, True, True, 0)

        # Start tailing
        self._log_file = os.path.join(LOGS_DIR, "agent.log")
        os.makedirs(LOGS_DIR, exist_ok=True)
        if not os.path.exists(self._log_file):
            with open(self._log_file, "a"):
                pass
        self._log_offset = 0
        GLib.timeout_add(1500, self._tail_log)

        return box

    # ── Prompt bar ────────────────────────────────────────────────────────────
    def _build_prompt_bar(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        inner.set_margin_start(12)
        inner.set_margin_end(12)
        inner.set_margin_top(8)
        inner.set_margin_bottom(8)

        # Model selector
        self._model_combo = Gtk.ComboBoxText()
        self._model_combo.append_text("llama3")
        self._model_combo.append_text("mistral")
        self._model_combo.append_text("codellama")
        self._model_combo.append_text("phi3")
        self._model_combo.set_active(0)
        self._model_combo.connect("changed", self._on_model_changed)
        self._model_combo.set_tooltip_text("Active model")
        inner.pack_start(self._model_combo, False, False, 0)

        self._prompt_entry = Gtk.Entry()
        self._prompt_entry.set_placeholder_text("Ask a question… (Enter to send)")
        self._prompt_entry.set_hexpand(True)
        self._prompt_entry.connect("activate", self._on_prompt_send)
        inner.pack_start(self._prompt_entry, True, True, 0)

        send_btn = Gtk.Button(label="Ask")
        send_btn.connect("clicked", self._on_prompt_send)
        inner.pack_start(send_btn, False, False, 0)

        self._thinking_spinner = Gtk.Spinner()
        inner.pack_start(self._thinking_spinner, False, False, 0)

        box.pack_start(inner, False, False, 0)
        return box

    # ── Data refresh ─────────────────────────────────────────────────────────
    def _initial_refresh(self) -> bool:
        """One-shot called ~150 ms after window shown."""
        if not self._refreshing:
            self._refreshing = True
            threading.Thread(target=self._fetch_all_bg, daemon=True,
                             name="agents-initial").start()
        return False  # do NOT re-queue

    def _refresh_all(self) -> bool:
        if not self._refreshing:
            self._refreshing = True
            threading.Thread(target=self._fetch_all_bg, daemon=True,
                             name="agents-refresh").start()
        return True  # keep 3 s GLib timer alive

    def _fetch_all_bg(self) -> None:
        """Collect all slow data off the GTK main thread, then apply via idle_add."""
        try:
            sessions = _tmux_sessions()
            models = _ollama_models()
            templates = self._collect_templates()
            GLib.idle_add(self._apply_sessions, sessions)
            GLib.idle_add(self._apply_models, models)
            GLib.idle_add(self._apply_templates, templates)
            self._refresh_ollama_status()
        finally:
            self._refreshing = False

    def _collect_templates(self) -> list:
        """Read TOML template files off the main thread; return plain data list."""
        dirs_to_check = [
            os.path.join(AGENTS_DIR, "sessions"),
            REPO_SESSIONS,
        ]
        seen: set[str] = set()
        results = []
        for d in dirs_to_check:
            if not os.path.isdir(d):
                continue
            with os.scandir(d) as it:
                toml_names = sorted(e.name for e in it
                                    if e.name.endswith(".toml") and e.is_file())
            for fname in toml_names:
                if fname in seen:
                    continue
                seen.add(fname)
                path = os.path.join(d, fname)
                data = _load_toml(path)
                sess = data.get("session", {})
                results.append({
                    "name": sess.get("name", fname.replace(".toml", "")),
                    "desc": sess.get("description", ""),
                    "path": path,
                })
        return results

    def _refresh_sessions(self) -> None:
        threading.Thread(
            target=lambda: GLib.idle_add(self._apply_sessions, _tmux_sessions()),
            daemon=True, name="agents-sessions",
        ).start()

    def _apply_sessions(self, sessions: list) -> bool:
        for child in self._sessions_list.get_children():
            self._sessions_list.remove(child)

        if not _tmux_available():
            lbl = Gtk.Label(label="tmux not installed.\nsudo apt install tmux")
            lbl.set_margin_start(12)
            lbl.set_margin_top(8)
            self._sessions_list.add(lbl)
        elif not sessions:
            lbl = Gtk.Label(label="No active tmux sessions.\nClick + New to start one.")
            lbl.set_margin_start(12)
            lbl.set_margin_top(8)
            self._sessions_list.add(lbl)
        else:
            for s in sessions:
                row = SessionRow(s, self._on_attach_session, self._on_kill_session)
                self._sessions_list.add(row)

        self._sessions_list.show_all()
        return False

    def _refresh_templates(self) -> None:
        threading.Thread(
            target=lambda: GLib.idle_add(self._apply_templates, self._collect_templates()),
            daemon=True, name="agents-templates",
        ).start()

    def _apply_templates(self, templates: list) -> bool:
        for child in self._templates_list.get_children():
            self._templates_list.remove(child)

        for t in templates:
            name, desc, path = t["name"], t["desc"], t["path"]
            row = Gtk.ListBoxRow()
            row.set_margin_top(2)
            row.set_margin_bottom(2)
            rbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            rbox.set_margin_start(12)
            rbox.set_margin_end(10)
            rbox.set_margin_top(8)
            rbox.set_margin_bottom(8)

            info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name_lbl = Gtk.Label()
            name_lbl.set_markup(f"<b>{GLib.markup_escape_text(name)}</b>")
            name_lbl.set_halign(Gtk.Align.START)
            desc_lbl = Gtk.Label(label=desc)
            desc_lbl.set_halign(Gtk.Align.START)
            desc_lbl.get_style_context().add_class("dim-label")
            info_box.pack_start(name_lbl, False, False, 0)
            if desc:
                info_box.pack_start(desc_lbl, False, False, 0)
            rbox.pack_start(info_box, True, True, 0)

            launch_btn = Gtk.Button(label="Launch")
            launch_btn.set_valign(Gtk.Align.CENTER)
            launch_btn.connect("clicked", lambda _, p=path: self._on_launch_template(p))
            rbox.pack_end(launch_btn, False, False, 0)

            row.add(rbox)
            self._templates_list.add(row)

        self._templates_list.show_all()
        return False

    def _refresh_models(self) -> None:
        threading.Thread(
            target=lambda: GLib.idle_add(self._apply_models, _ollama_models()),
            daemon=True, name="agents-models",
        ).start()

    def _apply_models(self, models: list) -> bool:
        for child in self._models_list.get_children():
            self._models_list.remove(child)

        if not models:
            lbl = Gtk.Label(
                label="No models downloaded.\nUse the Pull field above." if _ollama_available()
                else "ollama not installed.\nVisit https://ollama.com"
            )
            lbl.set_margin_start(12)
            lbl.set_margin_top(8)
            self._models_list.add(lbl)
        else:
            # Populate model combo with real models
            model_names = [m["name"] for m in models]
            current = self._model_combo.get_active_text()
            self._model_combo.remove_all()
            for m in model_names:
                self._model_combo.append_text(m)
            if current in model_names:
                self._model_combo.set_active(model_names.index(current))
            elif model_names:
                self._model_combo.set_active(0)
                self._active_model = model_names[0]

            for m in models:
                row = ModelRow(m, self._on_run_model, self._on_delete_model)
                self._models_list.add(row)

        self._models_list.show_all()
        return False

    def _refresh_ollama_status(self) -> None:
        def _check():
            if not _ollama_available():
                GLib.idle_add(self._ollama_status.set_text, "ollama: not installed")
                return
            running = _ollama_running()
            if running:
                names = ", ".join(r["name"] for r in running[:2])
                GLib.idle_add(self._ollama_status.set_text, f"ollama: ● {names}")
            else:
                GLib.idle_add(self._ollama_status.set_text, "ollama: idle")
        threading.Thread(target=_check, daemon=True).start()

    # ── Log tail ─────────────────────────────────────────────────────────────
    def _tail_log(self) -> bool:
        try:
            with open(self._log_file, "r") as fh:
                fh.seek(self._log_offset)
                new_text = fh.read()
                self._log_offset = fh.tell()
            if new_text:
                end = self._log_buf.get_end_iter()
                self._log_buf.insert(end, new_text)
                # Auto-scroll to bottom
                adj = self._log_view.get_parent().get_vadjustment()
                adj.set_value(adj.get_upper() - adj.get_page_size())
        except Exception:
            pass
        return True

    def _on_open_log(self, _btn) -> None:
        _run_bg([*_TERM_CMD, "tail", "-F", self._log_file])

    def _on_clear_log(self, _btn) -> None:
        self._log_buf.set_text("")
        try:
            with open(self._log_file, "w"):
                pass
            self._log_offset = 0
        except Exception:
            pass

    # ── Prompt ────────────────────────────────────────────────────────────────
    def _on_model_changed(self, combo) -> None:
        text = combo.get_active_text()
        if text:
            self._active_model = text

    def _on_prompt_send(self, _widget) -> None:
        prompt = self._prompt_entry.get_text().strip()
        if not prompt:
            return
        model = self._active_model
        self._prompt_entry.set_text("")
        self._thinking_spinner.start()

        # Log the prompt
        self._append_log(f"\n[YOU → {model}] {prompt}\n")

        def _work():
            resp = _ollama_ask(model, prompt)
            GLib.idle_add(self._on_response, resp)

        threading.Thread(target=_work, daemon=True).start()

    def _on_response(self, resp: str) -> bool:
        self._thinking_spinner.stop()
        self._append_log(f"[AGENT] {resp}\n")
        return False

    def _append_log(self, text: str) -> None:
        end = self._log_buf.get_end_iter()
        self._log_buf.insert(end, text)
        adj = self._log_view.get_parent().get_vadjustment()
        GLib.idle_add(lambda: adj.set_value(adj.get_upper() - adj.get_page_size()))
        threading.Thread(target=self._write_log, args=(text,), daemon=True).start()

    def _write_log(self, text: str) -> None:
        try:
            with open(self._log_file, "a") as fh:
                fh.write(text)
        except Exception:
            pass

    # ── Session actions ───────────────────────────────────────────────────────
    def _on_new_session(self, _btn) -> None:
        dialog = Gtk.Dialog(
            title="New tmux Session",
            transient_for=self,
            modal=True,
        )
        dialog.set_default_size(320, 120)
        area = dialog.get_content_area()
        area.set_margin_start(16)
        area.set_margin_end(16)
        area.set_margin_top(14)
        area.set_margin_bottom(8)

        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hbox.pack_start(Gtk.Label(label="Name:"), False, False, 0)
        name_entry = Gtk.Entry()
        name_entry.set_placeholder_text("session-name")
        name_entry.set_hexpand(True)
        hbox.pack_start(name_entry, True, True, 0)
        area.add(hbox)

        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Create", Gtk.ResponseType.OK)
        dialog.show_all()

        if dialog.run() == Gtk.ResponseType.OK:
            name = name_entry.get_text().strip().replace(" ", "-") or "agents"
            _tmux_new(name)
            _tmux_attach(name)
            GLib.timeout_add(1000, self._refresh_sessions)
        dialog.destroy()

    def _on_attach_session(self, name: str) -> None:
        _tmux_attach(name)

    def _on_kill_session(self, name: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Kill session '{name}'?",
            secondary_text="All windows in this session will be closed.",
        )
        if dialog.run() == Gtk.ResponseType.YES:
            threading.Thread(
                target=lambda: (_tmux_kill(name),
                                GLib.idle_add(self._refresh_sessions)),
                daemon=True,
            ).start()
        dialog.destroy()

    def _on_launch_template(self, path: str) -> None:
        threading.Thread(
            target=lambda: _launch_session_from_toml(path),
            daemon=True
        ).start()
        GLib.timeout_add(1200, self._refresh_sessions)

    # ── Model actions ─────────────────────────────────────────────────────────
    def _on_run_model(self, name: str) -> None:
        _run_bg([*_TERM_CMD, "ollama", "run", name])

    def _on_delete_model(self, name: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete model '{name}'?",
        )
        if dialog.run() == Gtk.ResponseType.YES:
            def _do_delete():
                subprocess.run(["ollama", "rm", name],
                               capture_output=True, timeout=15)
                GLib.idle_add(self._refresh_models)
            threading.Thread(target=_do_delete, daemon=True).start()
        dialog.destroy()

    def _on_pull(self, _widget) -> None:
        name = self._pull_entry.get_text().strip()
        if not name:
            return
        self._pull_entry.set_text("")
        _run_bg([*_TERM_CMD, "bash", "-c",
                 f"echo 'Pulling {name}…' && ollama pull {name}; echo; read -p 'Done. Press Enter…'"])
        GLib.timeout_add(5000, self._refresh_models)


# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    win = AgentsPanel()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
