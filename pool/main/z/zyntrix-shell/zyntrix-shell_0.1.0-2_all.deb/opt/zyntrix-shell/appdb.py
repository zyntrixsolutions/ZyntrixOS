#!/usr/bin/env python3
"""
ZyntrixOS App Database.

Scans XDG .desktop files and provides a cached list of installed applications.
Shared by fuzzy_launcher.py and switcher.py. Call prewarm() once at startup.
"""

from __future__ import annotations

import os
import re
import shlex
import threading
from typing import Optional

_app_cache: list[dict] = []
_cache_ready = threading.Event()
_cache_lock = threading.Lock()
_scan_started = False
_scan_started_lock = threading.Lock()

# Standard XDG app directories (scanned in order; user dir takes precedence
# via the seen-name dedup, since it's checked last → later entries are skipped
# if the name was already found in a system dir, which is what we want for
# per-user overrides to win).
_SYSTEM_APP_DIRS = [
    "/usr/share/applications",
    "/usr/local/share/applications",
    "/var/lib/flatpak/exports/share/applications",
    "/var/lib/snapd/desktop/applications",
]


def _get_all_app_dirs() -> list[str]:
    dirs: list[str] = list(_SYSTEM_APP_DIRS)

    # $XDG_DATA_DIRS
    for d in os.environ.get("XDG_DATA_DIRS", "").split(":"):
        if d:
            candidate = os.path.join(d, "applications")
            if candidate not in dirs:
                dirs.append(candidate)

    # User dir — checked last so it can override system entries
    user_base = os.environ.get(
        "XDG_DATA_HOME", os.path.expanduser("~/.local/share")
    )
    user_dir = os.path.join(user_base, "applications")
    if user_dir not in dirs:
        dirs.append(user_dir)

    return dirs


def _parse_desktop(path: str) -> Optional[dict]:
    """Parse a .desktop file. Returns a dict or None if not showable."""
    name = exec_raw = desc = icon = app_type = ""
    no_display = hidden = False
    in_entry = False

    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for raw_line in fh:
                line = raw_line.rstrip("\n")

                if line == "[Desktop Entry]":
                    in_entry = True
                    continue
                if line.startswith("[") and line != "[Desktop Entry]":
                    if in_entry:
                        break  # left the Desktop Entry section
                    continue
                if not in_entry or not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue

                k, _, v = line.partition("=")
                k = k.strip()
                v = v.strip()

                if k == "Name" and not name:
                    name = v
                elif k == "Exec" and not exec_raw:
                    exec_raw = v
                elif k == "Comment" and not desc:
                    desc = v
                elif k == "Icon" and not icon:
                    icon = v
                elif k == "Type":
                    app_type = v
                elif k == "NoDisplay":
                    no_display = v.lower() == "true"
                elif k == "Hidden":
                    hidden = v.lower() == "true"
    except Exception:
        return None

    if not name or not exec_raw:
        return None
    if no_display or hidden:
        return None
    if app_type and app_type != "Application":
        return None

    exec_cmd = _clean_exec(exec_raw)
    if not exec_cmd:
        return None

    return {
        "name":    name,
        "exec":    exec_cmd,  # cleaned, ready for subprocess
        "desc":    desc,
        "icon":    icon,
        "name_lc": name.lower(),
        "desc_lc": desc.lower(),
    }


def _clean_exec(raw: str) -> str:
    """Strip .desktop field codes (%f %u etc.) and sanitise the command."""
    # Remove all field codes
    cleaned = re.sub(r'\s*%[a-zA-Z]', "", raw).strip()
    try:
        parts = shlex.split(cleaned)
        # Drop leading 'env' keyword
        while parts and parts[0] == "env":
            parts.pop(0)
        # Drop leading VAR=val assignments (env var overrides in desktop files)
        while parts and "=" in parts[0] and "/" not in parts[0]:
            parts.pop(0)
        return shlex.join(parts) if parts else ""
    except Exception:
        return cleaned


def _scan_bg() -> None:
    """Background thread: scan all XDG app dirs and populate cache."""
    seen: set[str] = set()
    found: list[dict] = []

    for app_dir in _get_all_app_dirs():
        if not os.path.isdir(app_dir):
            continue
        try:
            with os.scandir(app_dir) as it:
                entries = sorted(e.name for e in it
                                 if e.name.endswith(".desktop") and e.is_file())
        except OSError:
            continue
        for fname in entries:
            app = _parse_desktop(os.path.join(app_dir, fname))
            if app and app["name"] not in seen:
                seen.add(app["name"])
                found.append(app)

    found.sort(key=lambda a: a["name"].lower())

    with _cache_lock:
        global _app_cache
        _app_cache = found
    _cache_ready.set()


# ── Public API ────────────────────────────────────────────────────────────────

def prewarm() -> None:
    """Start background scan. Truly idempotent — only one scan thread ever runs
    regardless of how many callers invoke this before the scan completes."""
    global _scan_started
    with _scan_started_lock:
        if _scan_started:
            return
        _scan_started = True
    threading.Thread(target=_scan_bg, daemon=True, name="appdb-scan").start()


def get_apps() -> list[dict]:
    """Return the current app list. May be empty until scan completes.

    The returned list is a shallow reference copy, not duplicated app dicts.
    Call app_count() for status labels that only need the count.
    """
    with _cache_lock:
        return list(_app_cache)


def app_count() -> int:
    with _cache_lock:
        return len(_app_cache)


def wait_ready(timeout: float = 10.0) -> bool:
    """Block until scan is done or timeout expires. Returns True if ready."""
    return _cache_ready.wait(timeout)


def is_ready() -> bool:
    return _cache_ready.is_set()


def search(query: str, limit: int = 80) -> list[dict]:
    """Return apps matching query (name-prefix first, then substring)."""
    apps = get_apps()
    if not query:
        return apps[:limit]
    q = query.lower()
    prefix = [a for a in apps if a["name_lc"].startswith(q)]
    # already mutually exclusive with prefix (startswith check inverted)
    other  = [a for a in apps if q in a["name_lc"] and not a["name_lc"].startswith(q)]
    # use id() sets for O(1) dedup instead of O(n) list membership
    seen   = {id(a) for a in prefix}
    seen.update(id(a) for a in other)
    desc   = [a for a in apps if q in a["desc_lc"] and id(a) not in seen]
    return (prefix + other + desc)[:limit]
