#!/usr/bin/env python3
"""ZyntrixOS File Manager — native GTK3 file manager."""
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
gi.require_version("Gio", "2.0")

import mimetypes, os, shutil, subprocess, sys, threading, datetime
from pathlib import Path
from typing import Optional
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Gio, Pango

SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
HOME = str(Path.home())

C_NAME, C_SIZE, C_SIZE_B, C_DATE, C_ICON, C_PATH, C_IS_DIR, C_HIDDEN, C_MIME = range(9)

BOOKMARKS = [
    ("Home",      HOME,                               "user-home"),
    ("Desktop",   os.path.join(HOME, "Desktop"),      "user-desktop"),
    ("Downloads", os.path.join(HOME, "Downloads"),    "folder-download"),
    ("Documents", os.path.join(HOME, "Documents"),    "folder-documents"),
    ("Pictures",  os.path.join(HOME, "Pictures"),     "folder-pictures"),
    ("Music",     os.path.join(HOME, "Music"),        "folder-music"),
    ("Videos",    os.path.join(HOME, "Videos"),       "folder-videos"),
    ("Projects",  os.path.join(HOME, "projects"),     "folder"),
    ("Root (/)", "/",                                 "drive-harddisk"),
]

_ICON_CACHE: dict = {}  # (icon_name, size) → Pixbuf; populated on main thread


MIME_ICONS = {
    "image/": "image-x-generic", "video/": "video-x-generic",
    "audio/": "audio-x-generic", "text/html": "text-html",
    "text/": "text-x-generic",   "application/pdf": "application-pdf",
    "application/zip": "package-x-generic", "application/gzip": "package-x-generic",
    "application/x-tar": "package-x-generic", "application/x-bzip2": "package-x-generic",
    "application/javascript": "text-x-script", "application/json": "text-x-generic",
    "application/x-python": "text-x-script", "application/x-executable": "application-x-executable",
}


def _fmt_size(n: int) -> str:
    if n < 1024: return f"{n} B"
    if n < 1024**2: return f"{n/1024:.1f} KB"
    if n < 1024**3: return f"{n/1024**2:.1f} MB"
    return f"{n/1024**3:.2f} GB"


def _fmt_date(path: str) -> str:
    try:
        t = os.path.getmtime(path)
        return datetime.datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return ""


def _get_mime(path: str) -> str:
    mime, _ = mimetypes.guess_type(path)
    return mime or "application/octet-stream"


def _icon_for(is_dir: bool, mime: str, size: int = 48) -> Optional[GdkPixbuf.Pixbuf]:
    """Load and cache a themed icon. Must be called on the GTK main thread."""
    icon_name = "folder" if is_dir else "text-x-generic"
    if not is_dir:
        for prefix, name in MIME_ICONS.items():
            if mime.startswith(prefix):
                icon_name = name
                break
    key = (icon_name, size)
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    theme = Gtk.IconTheme.get_default()
    flags = Gtk.IconLookupFlags.FORCE_SIZE
    pixbuf = None
    for name in [icon_name, "text-x-generic", "application-x-executable"]:
        try:
            pixbuf = theme.load_icon(name, size, flags)
            break
        except Exception:
            pass
    _ICON_CACHE[key] = pixbuf
    return pixbuf


_CSS = b"""
window.fm-window { background-color: #0a0b0f; }
.fm-sidebar { background-color: #0e1018; border-right: 1px solid rgba(0,240,200,0.12); min-width: 170px; }
.fm-sidebar row { padding: 2px 0; }
.fm-sidebar row:selected { background-color: rgba(0,240,200,0.15); }
.fm-sidebar-label { font-size: 12px; color: #e8eaf0; padding: 6px 14px; }
.fm-sidebar-section { font-size: 9px; font-weight: 700; letter-spacing: 2px;
    color: rgba(0,240,200,0.5); padding: 12px 14px 4px 14px; }
.fm-header { background-color: #0e1018; border-bottom: 1px solid rgba(0,240,200,0.12); padding: 8px 14px; }
.fm-path-entry { background-color: #12141a; color: #e8eaf0; border: 1px solid rgba(0,240,200,0.2);
    border-radius: 5px; padding: 4px 10px; font-size: 13px; }
.fm-path-entry:focus { border-color: #00f0c8; box-shadow: 0 0 0 2px rgba(0,240,200,0.15); }
.fm-nav-btn { background-color: transparent; border: 1px solid rgba(0,240,200,0.18);
    border-radius: 5px; color: #e8eaf0; padding: 4px 10px; }
.fm-nav-btn:hover { background-color: rgba(0,240,200,0.12); border-color: #00f0c8; }
.fm-nav-btn:disabled { color: rgba(232,234,240,0.25); border-color: rgba(0,240,200,0.07); }
.fm-toolbar-btn { background-color: transparent; border: 1px solid rgba(0,240,200,0.18);
    border-radius: 5px; color: #e8eaf0; padding: 4px 10px; min-height: 0; }
.fm-toolbar-btn:hover { background-color: rgba(0,240,200,0.12); }
.fm-statusbar { background-color: #0e1018; border-top: 1px solid rgba(0,240,200,0.12);
    padding: 5px 14px; }
.fm-status-lbl { font-size: 11px; color: rgba(232,234,240,0.45); }
iconview { background-color: #0a0b0f; }
iconview item { border-radius: 6px; padding: 6px; color: #e8eaf0; font-size: 11px; }
iconview item:selected { background-color: rgba(0,240,200,0.2); color: #e8eaf0; }
iconview item:hover { background-color: rgba(0,240,200,0.08); }
treeview { background-color: #0a0b0f; color: #e8eaf0; font-size: 12px; }
treeview:selected { background-color: rgba(0,240,200,0.2); }
treeview header button { background-color: #0e1018; color: rgba(232,234,240,0.6);
    border-bottom: 1px solid rgba(0,240,200,0.12); font-size: 11px; }
.fm-error { color: #ef4444; font-size: 12px; padding: 20px; }
"""


class FileManagerWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS Files")
        self.set_default_size(1100, 680)
        self.get_style_context().add_class("fm-window")
        self._history: list[str] = []
        self._hist_pos: int = -1
        self._clipboard: Optional[tuple] = None  # ('copy'|'cut', [paths])
        self._show_hidden: bool = False
        self._view_mode: str = "grid"
        self._dir_gen: int = 0  # incremented on each navigate; stale _scan_dir drops result

        self._apply_css()
        self._build_ui()
        self.connect("destroy", Gtk.main_quit)
        self.connect("key-press-event", self._on_key)
        self._navigate(HOME)

    def _apply_css(self):
        p = Gtk.CssProvider()
        p.load_from_data(_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def _build_ui(self):
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # ── Header ──
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        header.get_style_context().add_class("fm-header")

        self._btn_back = Gtk.Button(label="◀")
        self._btn_back.get_style_context().add_class("fm-nav-btn")
        self._btn_back.connect("clicked", lambda _: self._go_back())
        self._btn_fwd = Gtk.Button(label="▶")
        self._btn_fwd.get_style_context().add_class("fm-nav-btn")
        self._btn_fwd.connect("clicked", lambda _: self._go_fwd())
        self._btn_up = Gtk.Button(label="▲")
        self._btn_up.get_style_context().add_class("fm-nav-btn")
        self._btn_up.connect("clicked", lambda _: self._go_up())
        self._btn_home = Gtk.Button(label="⌂")
        self._btn_home.get_style_context().add_class("fm-nav-btn")
        self._btn_home.connect("clicked", lambda _: self._navigate(HOME))

        self._path_entry = Gtk.Entry()
        self._path_entry.get_style_context().add_class("fm-path-entry")
        self._path_entry.set_hexpand(True)
        self._path_entry.connect("activate", self._on_path_activate)

        self._search_entry = Gtk.SearchEntry()
        self._search_entry.set_placeholder_text("Search…")
        self._search_entry.set_size_request(180, -1)
        self._search_entry.connect("search-changed", self._on_search)

        btn_hidden = Gtk.ToggleButton(label="Hidden")
        btn_hidden.get_style_context().add_class("fm-toolbar-btn")
        btn_hidden.connect("toggled", lambda b: self._toggle_hidden(b.get_active()))

        btn_grid = Gtk.Button(label="⊞ Grid")
        btn_grid.get_style_context().add_class("fm-toolbar-btn")
        btn_grid.connect("clicked", lambda _: self._set_view("grid"))
        btn_list = Gtk.Button(label="☰ List")
        btn_list.get_style_context().add_class("fm-toolbar-btn")
        btn_list.connect("clicked", lambda _: self._set_view("list"))

        for w in [self._btn_back, self._btn_fwd, self._btn_up, self._btn_home]:
            header.pack_start(w, False, False, 0)
        header.pack_start(self._path_entry, True, True, 4)
        header.pack_start(self._search_entry, False, False, 0)
        header.pack_start(btn_hidden, False, False, 0)
        header.pack_start(btn_grid, False, False, 0)
        header.pack_start(btn_list, False, False, 0)
        vbox.pack_start(header, False, False, 0)

        # ── Body: sidebar + main ──
        body = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        body.set_position(180)

        sidebar = self._build_sidebar()
        body.pack1(sidebar, resize=False, shrink=False)

        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.NONE)

        # Grid view
        self._store = Gtk.ListStore(str, str, int, str, GdkPixbuf.Pixbuf, str, bool, bool, str)
        self._icon_view = Gtk.IconView(model=self._store)
        self._icon_view.set_text_column(C_NAME)
        self._icon_view.set_pixbuf_column(C_ICON)
        self._icon_view.set_item_width(96)
        self._icon_view.set_selection_mode(Gtk.SelectionMode.MULTIPLE)
        self._icon_view.connect("item-activated", self._on_icon_activate)
        self._icon_view.connect("button-press-event", self._on_icon_press)
        grid_sw = Gtk.ScrolledWindow()
        grid_sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        grid_sw.add(self._icon_view)

        # List view
        self._tree_store = Gtk.TreeModelSort(model=self._store)
        self._tree_view = Gtk.TreeView(model=self._tree_store)
        self._tree_view.set_enable_search(False)
        self._tree_view.set_headers_visible(True)
        self._tree_view.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        self._tree_view.connect("row-activated", self._on_tree_activate)
        self._tree_view.connect("button-press-event", self._on_tree_press)

        for col_id, title, width in [(C_NAME, "Name", 300), (C_SIZE, "Size", 90),
                                     (C_DATE, "Modified", 140)]:
            renderer = Gtk.CellRendererText()
            renderer.set_property("ellipsize", Pango.EllipsizeMode.END)
            col = Gtk.TreeViewColumn(title, renderer, text=col_id)
            col.set_resizable(True)
            col.set_min_width(width)
            col.set_sort_column_id(col_id)
            self._tree_view.append_column(col)

        # Add icon column to list view
        icon_col = Gtk.TreeViewColumn("", Gtk.CellRendererPixbuf(), pixbuf=C_ICON)
        icon_col.set_min_width(28)
        self._tree_view.insert_column(icon_col, 0)

        list_sw = Gtk.ScrolledWindow()
        list_sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        list_sw.add(self._tree_view)

        self._stack.add_named(grid_sw, "grid")
        self._stack.add_named(list_sw, "list")
        self._stack.set_visible_child_name("grid")

        right.pack_start(self._stack, True, True, 0)

        # Status bar
        statusbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        statusbar.get_style_context().add_class("fm-statusbar")
        self._status_lbl = Gtk.Label(label="")
        self._status_lbl.get_style_context().add_class("fm-status-lbl")
        self._status_lbl.set_halign(Gtk.Align.START)
        self._sel_lbl = Gtk.Label(label="")
        self._sel_lbl.get_style_context().add_class("fm-status-lbl")
        self._sel_lbl.set_halign(Gtk.Align.END)
        self._sel_lbl.set_hexpand(True)
        statusbar.pack_start(self._status_lbl, True, True, 0)
        statusbar.pack_end(self._sel_lbl, False, False, 0)
        right.pack_start(statusbar, False, False, 0)

        body.pack2(right, resize=True, shrink=False)
        vbox.pack_start(body, True, True, 0)
        self.add(vbox)

    def _build_sidebar(self) -> Gtk.Widget:
        sidebar_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        sidebar_box.get_style_context().add_class("fm-sidebar")

        sec = Gtk.Label(label="PLACES")
        sec.get_style_context().add_class("fm-sidebar-section")
        sec.set_halign(Gtk.Align.START)
        sidebar_box.pack_start(sec, False, False, 0)

        lb = Gtk.ListBox()
        lb.set_selection_mode(Gtk.SelectionMode.SINGLE)
        lb.connect("row-activated", self._on_bookmark_activate)
        for name, path, icon_name in BOOKMARKS:
            if not os.path.exists(path):
                continue
            row = Gtk.ListBoxRow()
            row._path = path  # type: ignore
            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            hbox.set_margin_start(10)
            hbox.set_margin_top(3)
            hbox.set_margin_bottom(3)
            img = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
            lbl = Gtk.Label(label=name)
            lbl.get_style_context().add_class("fm-sidebar-label")
            lbl.set_halign(Gtk.Align.START)
            hbox.pack_start(img, False, False, 0)
            hbox.pack_start(lbl, True, True, 0)
            row.add(hbox)
            lb.add(row)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.add(lb)
        sidebar_box.pack_start(sw, True, True, 0)
        return sidebar_box

    def _navigate(self, path: str):
        path = os.path.realpath(path)
        if not os.path.isdir(path):
            return
        if self._hist_pos < 0 or self._history[self._hist_pos] != path:
            self._history = self._history[:self._hist_pos + 1]
            self._history.append(path)
            self._hist_pos = len(self._history) - 1
        self._current_path = path
        self._path_entry.set_text(path)
        self._btn_back.set_sensitive(self._hist_pos > 0)
        self._btn_fwd.set_sensitive(self._hist_pos < len(self._history) - 1)
        self._btn_up.set_sensitive(path != "/")
        self._load_directory(path)

    def _on_bookmark_activate(self, lb, row):
        self._navigate(row._path)

    def _load_directory(self, path: str):
        self._store.clear()
        self._dir_gen += 1
        gen = self._dir_gen
        self._status_lbl.set_text(f"Loading {path}\u2026")
        threading.Thread(target=self._scan_dir, args=(path, gen), daemon=True).start()

    def _scan_dir(self, path: str, gen: int):
        """Background thread: scan directory. Does NOT call any GTK code."""
        entries = []
        try:
            with os.scandir(path) as it:
                items = sorted(it, key=lambda e: (not e.is_dir(follow_symlinks=True), e.name.lower()))
            for e in items:
                name = e.name
                if not self._show_hidden and name.startswith("."):
                    continue
                try:
                    st = e.stat(follow_symlinks=True)
                    is_dir = e.is_dir(follow_symlinks=True)
                    size = 0 if is_dir else st.st_size
                    mtime = st.st_mtime
                except OSError:
                    is_dir = False; size = 0; mtime = 0.0
                mime = _get_mime(e.path) if not is_dir else "inode/directory"
                try:
                    date = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
                except Exception:
                    date = ""
                entries.append((name, _fmt_size(size) if not is_dir else "", size,
                                date, e.path, is_dir, name.startswith("."), mime))
        except PermissionError:
            GLib.idle_add(self._status_lbl.set_text, "Permission denied")
            return
        GLib.idle_add(self._populate, path, entries, gen)

    def _populate(self, path: str, entries: list, gen: int):
        if gen != self._dir_gen:
            return  # stale result from a superseded navigation
        self._store.clear()
        for e in entries:
            name, size_s, size_b, date, fpath, is_dir, hidden, mime = e
            icon = _icon_for(is_dir, mime, 48)  # safe: main thread
            self._store.append((name, size_s, size_b, date, icon, fpath, is_dir, hidden, mime))
        n_dirs  = sum(1 for e in entries if e[5])
        n_files = len(entries) - n_dirs
        self._status_lbl.set_text(
            f"{n_dirs} folder{'s' if n_dirs != 1 else ''}  \u00b7  {n_files} file{'s' if n_files != 1 else ''}")

    def _on_path_activate(self, entry):
        self._navigate(entry.get_text())

    def _on_icon_activate(self, _view, path):
        it = self._store.get_iter(path)
        fpath = self._store.get_value(it, C_PATH)
        is_dir = self._store.get_value(it, C_IS_DIR)
        if is_dir:
            self._navigate(fpath)
        else:
            self._open_file(fpath)

    def _on_tree_activate(self, _view, path, _col):
        it = self._tree_store.get_iter(path)
        it2 = self._tree_store.convert_iter_to_child_iter(it)
        fpath = self._store.get_value(it2, C_PATH)
        is_dir = self._store.get_value(it2, C_IS_DIR)
        if is_dir:
            self._navigate(fpath)
        else:
            self._open_file(fpath)

    def _open_file(self, path: str):
        for cmd in [["xdg-open"], ["gio", "open"]]:
            if shutil.which(cmd[0]):
                subprocess.Popen(cmd + [path], start_new_session=True,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
        self._show_error("Cannot open file: xdg-open or gio not installed")

    def _on_icon_press(self, _w, event):
        if event.button == 3:
            paths = self._get_selected_icon_paths()
            self._show_context_menu(event, paths)
            return True
        return False

    def _on_tree_press(self, _w, event):
        if event.button == 3:
            paths = self._get_selected_tree_paths()
            self._show_context_menu(event, paths)
            return True
        return False

    def _get_selected_icon_paths(self) -> list:
        paths = []
        for item_path in self._icon_view.get_selected_items():
            it = self._store.get_iter(item_path)
            paths.append(self._store.get_value(it, C_PATH))
        return paths

    def _get_selected_tree_paths(self) -> list:
        model, rows = self._tree_view.get_selection().get_selected_rows()
        paths = []
        for row in rows:
            it = model.get_iter(row)
            it2 = self._tree_store.convert_iter_to_child_iter(it)
            paths.append(self._store.get_value(it2, C_PATH))
        return paths

    def _get_selected(self) -> list:
        if self._view_mode == "grid":
            return self._get_selected_icon_paths()
        return self._get_selected_tree_paths()

    def _show_context_menu(self, event, paths: list):
        menu = Gtk.Menu()

        def _add(label, cb, sensitive=True):
            item = Gtk.MenuItem(label=label)
            if sensitive:
                item.connect("activate", lambda _: cb())
            item.set_sensitive(sensitive)
            menu.append(item)

        if len(paths) == 1 and os.path.isdir(paths[0]):
            _add("Open Folder", lambda: self._navigate(paths[0]))
        elif len(paths) == 1:
            _add("Open", lambda: self._open_file(paths[0]))

        menu.append(Gtk.SeparatorMenuItem())
        _add("Copy", lambda: self._set_clipboard("copy", paths), bool(paths))
        _add("Cut", lambda: self._set_clipboard("cut", paths), bool(paths))
        _add("Paste", self._paste, self._clipboard is not None)
        menu.append(Gtk.SeparatorMenuItem())
        _add("Rename…", lambda: self._rename(paths[0]), len(paths) == 1)
        _add("Delete", lambda: self._delete(paths), bool(paths))
        menu.append(Gtk.SeparatorMenuItem())
        _add("New Folder…", self._new_folder)
        _add("Open Terminal Here", lambda: self._open_terminal(self._current_path))

        menu.show_all()
        menu.popup_at_pointer(event)

    def _set_clipboard(self, op: str, paths: list):
        self._clipboard = (op, list(paths))

    def _paste(self):
        if not self._clipboard:
            return
        op, paths = self._clipboard
        dest = self._current_path
        threading.Thread(target=self._do_paste, args=(op, paths, dest), daemon=True).start()
        if op == "cut":
            self._clipboard = None

    def _do_paste(self, op: str, paths: list, dest: str):
        for src in paths:
            try:
                name = os.path.basename(src)
                d = os.path.join(dest, name)
                if op == "copy":
                    if os.path.isdir(src):
                        shutil.copytree(src, d)
                    else:
                        shutil.copy2(src, d)
                else:
                    shutil.move(src, d)
            except Exception as exc:
                GLib.idle_add(self._show_error, str(exc))
        GLib.idle_add(self._navigate, dest)

    def _delete(self, paths: list):
        dialog = Gtk.MessageDialog(
            transient_for=self, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Delete {len(paths)} item(s)?",
            secondary_text="This cannot be undone.",
        )
        if dialog.run() == Gtk.ResponseType.YES:
            threading.Thread(target=self._do_delete, args=(paths,), daemon=True).start()
        dialog.destroy()

    def _do_delete(self, paths: list):
        for p in paths:
            try:
                if os.path.isdir(p):
                    shutil.rmtree(p)
                else:
                    os.remove(p)
            except Exception as exc:
                GLib.idle_add(self._show_error, str(exc))
        GLib.idle_add(self._navigate, self._current_path)

    def _rename(self, path: str):
        old_name = os.path.basename(path)
        dialog = Gtk.Dialog(title="Rename", transient_for=self, modal=True)
        dialog.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Rename", Gtk.ResponseType.OK)
        area = dialog.get_content_area()
        area.set_margin_start(18); area.set_margin_end(18)
        area.set_margin_top(14); area.set_margin_bottom(8)
        entry = Gtk.Entry(text=old_name)
        entry.set_size_request(320, -1)
        entry.connect("activate", lambda _: dialog.response(Gtk.ResponseType.OK))
        area.pack_start(entry, False, False, 8)
        dialog.show_all()
        if dialog.run() == Gtk.ResponseType.OK:
            new_name = entry.get_text().strip()
            if new_name and new_name != old_name:
                new_path = os.path.join(os.path.dirname(path), new_name)
                try:
                    os.rename(path, new_path)
                    self._navigate(self._current_path)
                except Exception as exc:
                    self._show_error(str(exc))
        dialog.destroy()

    def _new_folder(self):
        dialog = Gtk.Dialog(title="New Folder", transient_for=self, modal=True)
        dialog.add_buttons("Cancel", Gtk.ResponseType.CANCEL, "Create", Gtk.ResponseType.OK)
        area = dialog.get_content_area()
        area.set_margin_start(18); area.set_margin_end(18)
        area.set_margin_top(14); area.set_margin_bottom(8)
        entry = Gtk.Entry(placeholder_text="Folder name…")
        entry.set_size_request(320, -1)
        entry.connect("activate", lambda _: dialog.response(Gtk.ResponseType.OK))
        area.pack_start(entry, False, False, 8)
        dialog.show_all()
        if dialog.run() == Gtk.ResponseType.OK:
            name = entry.get_text().strip()
            if name:
                try:
                    os.makedirs(os.path.join(self._current_path, name), exist_ok=True)
                    self._navigate(self._current_path)
                except Exception as exc:
                    self._show_error(str(exc))
        dialog.destroy()

    def _open_terminal(self, path: str):
        terminals = [
            ("foot", []),
            ("alacritty", []),
            ("kitty", []),
            ("xfce4-terminal", []),
            ("gnome-terminal", []),
            ("mate-terminal", []),
            ("lxterminal", []),
            ("xterm", []),
        ]
        for term, args in terminals:
            if shutil.which(term):
                subprocess.Popen([term] + args, cwd=path, start_new_session=True)
                return
        self._show_error("Cannot open terminal: no terminal emulator found\nInstall: foot, alacritty, or xterm")

    def _toggle_hidden(self, show: bool):
        self._show_hidden = show
        self._navigate(self._current_path)

    def _set_view(self, mode: str):
        self._view_mode = mode
        self._stack.set_visible_child_name(mode)

    def _go_back(self):
        if self._hist_pos > 0:
            self._hist_pos -= 1
            self._navigate_no_push(self._history[self._hist_pos])

    def _go_fwd(self):
        if self._hist_pos < len(self._history) - 1:
            self._hist_pos += 1
            self._navigate_no_push(self._history[self._hist_pos])

    def _go_up(self):
        parent = os.path.dirname(self._current_path)
        if parent != self._current_path:
            self._navigate(parent)

    def _navigate_no_push(self, path: str):
        self._current_path = path
        self._path_entry.set_text(path)
        self._btn_back.set_sensitive(self._hist_pos > 0)
        self._btn_fwd.set_sensitive(self._hist_pos < len(self._history) - 1)
        self._btn_up.set_sensitive(path != "/")
        self._load_directory(path)

    def _on_search(self, entry):
        query = entry.get_text().strip().lower()
        if not query:
            self._navigate(self._current_path)
            return
        self._dir_gen += 1
        gen = self._dir_gen
        search_path = self._current_path
        threading.Thread(target=self._search_bg,
                         args=(query, search_path, gen), daemon=True).start()

    def _search_bg(self, query: str, path: str, gen: int):
        """Background thread: find matching entries without touching GTK."""
        results = []
        try:
            with os.scandir(path) as it:
                for e in it:
                    if query not in e.name.lower():
                        continue
                    try:
                        st = e.stat(follow_symlinks=True)
                        is_dir = e.is_dir(follow_symlinks=True)
                        size = 0 if is_dir else st.st_size
                        mtime = st.st_mtime
                    except OSError:
                        is_dir = False; size = 0; mtime = 0.0
                    mime = _get_mime(e.path) if not is_dir else "inode/directory"
                    try:
                        date = datetime.datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M")
                    except Exception:
                        date = ""
                    results.append((e.name, _fmt_size(size) if not is_dir else "",
                                    size, date, e.path, is_dir,
                                    e.name.startswith("."), mime))
        except Exception:
            pass
        GLib.idle_add(self._populate_search, results, query, gen)

    def _populate_search(self, results: list, query: str, gen: int):
        if gen != self._dir_gen:
            return
        self._store.clear()
        for e in sorted(results, key=lambda r: (not r[5], r[0].lower())):
            name, size_s, size_b, date, fpath, is_dir, hidden, mime = e
            icon = _icon_for(is_dir, mime, 48)
            self._store.append((name, size_s, size_b, date, icon, fpath, is_dir, hidden, mime))
        self._status_lbl.set_text(f"{len(results)} match(es) for '{query}'")

    def _on_key(self, _w, event):
        ctrl = event.state & Gdk.ModifierType.CONTROL_MASK
        key = event.keyval
        if key == Gdk.KEY_BackSpace:
            self._go_up(); return True
        if ctrl and key == Gdk.KEY_c:
            paths = self._get_selected()
            if paths: self._set_clipboard("copy", paths); return True
        if ctrl and key == Gdk.KEY_x:
            paths = self._get_selected()
            if paths: self._set_clipboard("cut", paths); return True
        if ctrl and key == Gdk.KEY_v:
            self._paste(); return True
        if key == Gdk.KEY_Delete:
            paths = self._get_selected()
            if paths: self._delete(paths); return True
        if key == Gdk.KEY_F2:
            paths = self._get_selected()
            if len(paths) == 1: self._rename(paths[0]); return True
        if ctrl and key == Gdk.KEY_n:
            self._new_folder(); return True
        if key == Gdk.KEY_F5:
            self._navigate(self._current_path); return True
        return False

    def _show_error(self, msg: str):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.ERROR,
                              buttons=Gtk.ButtonsType.OK, text=msg)
        d.run(); d.destroy()


def main():
    if "DISPLAY" not in os.environ and "WAYLAND_DISPLAY" not in os.environ:
        sys.exit(1)
    win = FileManagerWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
