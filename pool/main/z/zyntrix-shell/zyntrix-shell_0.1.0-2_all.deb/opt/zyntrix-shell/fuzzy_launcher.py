#!/usr/bin/env python3
"""
ZyntrixOS Fuzzy Launcher.
Press / from the shell to open. Type to filter installed apps from XDG .desktop
files. Arrow keys select, Enter launches, Esc closes.
"""

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib

import os
import shlex
import subprocess
import threading
from typing import Callable, Optional

import appdb


def prewarm() -> None:
    """Call once at shell startup to warm the app cache in the background."""
    appdb.prewarm()


# ── Widget ────────────────────────────────────────────────────────────────────
class FuzzyLauncher(Gtk.Window):
    """
    Fullscreen app launcher overlay.
    Filters installed apps (from XDG .desktop files) as the user types.
    on_launch is called with a list[str] command when an app is selected.
    """

    def __init__(self, on_launch: Callable[[list], None], transient_for=None):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._on_launch = on_launch

        self.set_title("Launch")
        self.set_decorated(False)
        self.set_default_size(520, 480)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        if transient_for:
            self.set_transient_for(transient_for)
            self.set_modal(True)

        self.get_style_context().add_class("fuzzy-window")

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # ── Search row ──
        search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        search_row.set_margin_start(18)
        search_row.set_margin_end(18)
        search_row.set_margin_top(16)
        search_row.set_margin_bottom(14)

        chevron = Gtk.Label(label="⌕")
        chevron.get_style_context().add_class("fuzzy-prompt")

        self._entry = Gtk.Entry()
        self._entry.set_has_frame(False)
        self._entry.set_hexpand(True)
        self._entry.set_placeholder_text("search installed apps…")
        self._entry.get_style_context().add_class("fuzzy-entry")
        self._entry.connect("changed", self._on_changed)
        self._entry.connect("key-press-event", self._on_entry_key)

        search_row.pack_start(chevron, False, False, 0)
        search_row.pack_start(self._entry, True, True, 0)
        outer.pack_start(search_row, False, False, 0)

        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        outer.pack_start(sep, False, False, 0)

        # ── Results list ──
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_size_request(-1, 360)

        self._listbox = Gtk.ListBox()
        self._listbox.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self._listbox.connect("row-activated", self._on_activated)
        sw.add(self._listbox)
        outer.pack_start(sw, True, True, 0)

        sep2 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        outer.pack_start(sep2, False, False, 0)

        # ── Status line ──
        self._status = Gtk.Label(label="Scanning installed apps…")
        self._status.set_halign(Gtk.Align.START)
        self._status.set_margin_start(18)
        self._status.set_margin_top(7)
        self._status.set_margin_bottom(7)
        self._status.get_style_context().add_class("fuzzy-status")
        outer.pack_start(self._status, False, False, 0)

        self.add(outer)

        self._query = ""

        self.connect("key-press-event", self._on_window_key)
        self.connect("focus-out-event", self._on_focus_out)
        self.connect("show", lambda _: GLib.idle_add(self._entry.grab_focus))

        if appdb.is_ready():
            GLib.idle_add(self._load_all_apps)
        else:
            # main.py skips prewarm on ultralow to protect startup memory, so
            # the launcher starts the scan on demand when the user asks for it.
            appdb.prewarm()
            threading.Thread(target=self._wait_and_load, daemon=True).start()

    # ------------------------------------------------------------------
    def _wait_and_load(self) -> None:
        appdb.wait_ready(timeout=10)
        GLib.idle_add(self._load_all_apps)

    def _load_all_apps(self) -> bool:
        """Create one GTK row per installed app (runs once at startup).
        All subsequent filtering uses GTK's set_filter_func — zero widget
        allocation per keypress regardless of catalogue size."""
        for child in self._listbox.get_children():
            self._listbox.remove(child)

        apps = appdb.get_apps()
        for app in apps:
            row = Gtk.ListBoxRow()
            row._app = app  # type: ignore[attr-defined]
            row.get_style_context().add_class("fuzzy-row")

            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            box.set_margin_start(14)
            box.set_margin_end(14)
            box.set_margin_top(8)
            box.set_margin_bottom(8)

            name_lbl = Gtk.Label(label=app["name"])
            name_lbl.set_halign(Gtk.Align.START)
            name_lbl.get_style_context().add_class("fuzzy-app-name")
            box.pack_start(name_lbl, False, False, 0)

            if app["desc"]:
                desc_lbl = Gtk.Label(label=app["desc"])
                desc_lbl.set_halign(Gtk.Align.START)
                desc_lbl.get_style_context().add_class("fuzzy-app-desc")
                desc_lbl.set_ellipsize(3)
                box.pack_start(desc_lbl, False, False, 0)

            row.add(box)
            self._listbox.add(row)

        self._listbox.set_filter_func(self._filter_row)
        self._listbox.show_all()
        self._update_status()
        GLib.idle_add(self._select_first_visible)
        return False

    def _filter_row(self, row: Gtk.ListBoxRow) -> bool:
        """GTK client-side filter — called by the toolkit, no allocation cost."""
        if not self._query:
            return True
        app = getattr(row, "_app", None)
        if not app:
            return True
        return (self._query in app["name_lc"] or
                self._query in app["desc_lc"])

    def _select_first_visible(self) -> bool:
        for row in self._listbox.get_children():
            if isinstance(row, Gtk.ListBoxRow) and row.get_visible():
                self._listbox.select_row(row)
                break
        return False

    def _update_status(self) -> None:
        total = appdb.app_count()
        if not appdb.is_ready():
            self._status.set_text("Scanning installed apps…")
        elif self._query:
            shown = sum(
                1 for r in self._listbox.get_children()
                if isinstance(r, Gtk.ListBoxRow) and r.get_visible()
            )
            self._status.set_text(f"{shown} of {total} apps")
        else:
            self._status.set_text(f"{total} apps installed")

    def _move_selection(self, delta: int) -> None:
        """Move selection by delta among currently visible rows."""
        visible = [r for r in self._listbox.get_children()
                   if isinstance(r, Gtk.ListBoxRow) and r.get_visible()]
        if not visible:
            return
        sel = self._listbox.get_selected_row()
        try:
            idx = visible.index(sel) if sel in visible else -1
        except ValueError:
            idx = -1
        new_idx = max(0, min(len(visible) - 1, idx + delta))
        self._listbox.select_row(visible[new_idx])

    # ------------------------------------------------------------------
    def _on_changed(self, entry: Gtk.Entry) -> None:
        self._query = entry.get_text().strip().lower()
        self._listbox.invalidate_filter()
        self._update_status()
        GLib.idle_add(self._select_first_visible)

    def _on_focus_out(self, _w, _event) -> bool:
        """Delay destroy by 120 ms to let child widgets (e.g. polkit) take focus
        without accidentally closing the launcher."""
        GLib.timeout_add(120, self._maybe_destroy)
        return False

    def _maybe_destroy(self) -> bool:
        if not self.is_active() and not self.has_toplevel_focus():
            self.destroy()
        return False

    def _on_entry_key(self, _w, event: Gdk.EventKey) -> bool:
        k = event.keyval
        if k == Gdk.KEY_Escape:
            self.destroy()
            return True
        if k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            self._launch_selected()
            return True
        if k == Gdk.KEY_Down:
            self._move_selection(1)
            return True
        if k == Gdk.KEY_Up:
            self._move_selection(-1)
            return True
        return False

    def _on_window_key(self, _w, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self.destroy()
            return True
        return False

    def _on_activated(self, _lb, row: Gtk.ListBoxRow) -> None:
        app = getattr(row, "_app", None)
        if app:
            self._launch_app(app)

    def _launch_selected(self) -> None:
        sel = self._listbox.get_selected_row()
        app = getattr(sel, "_app", None) if sel else None
        if app:
            self._launch_app(app)
        elif self._entry.get_text().strip():
            # Fallback: user typed something not in the list — try running it directly
            raw = self._entry.get_text().strip()
            try:
                cmd = shlex.split(raw)
            except Exception:
                cmd = [raw]
            self._on_launch(cmd)
            self.destroy()

    def _launch_app(self, app: dict) -> None:
        try:
            cmd = shlex.split(app["exec"])
        except Exception:
            cmd = [app["exec"]]
        self._on_launch(cmd)
        self.destroy()
