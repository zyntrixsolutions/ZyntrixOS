#! /usr/bin/python3
"""
ZyntrixOS graphical hard drive installer.
"""

from __future__ import annotations

import os
import signal
import subprocess
import sys
from typing import Optional

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib

SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
if SHELL_DIR not in sys.path:
    sys.path.insert(0, SHELL_DIR)

from installer_disk import InstallConfig, validate_install_config
from installer_engine import InstallEngine
from installer_steps import (
    CompleteStep,
    DiskSelectionStep,
    PartitionStep,
    ProgressStep,
    ReviewStep,
    UserStep,
    WelcomeStep,
    reboot_now,
)

try:
    from tiles import load_config
except Exception:
    load_config = None  # type: ignore

try:
    from notifier import LEVEL_ERROR, LEVEL_INFO, NotificationManager
except Exception:
    LEVEL_ERROR = "error"
    LEVEL_INFO = "info"
    NotificationManager = None  # type: ignore


WINDOW_W = 960
WINDOW_H = 600
INSTALL_LOCK_PATH = "/tmp/zyntrix-installing"


class InstallerWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Install ZyntrixOS")
        self.set_default_size(WINDOW_W, WINDOW_H)
        self.set_size_request(WINDOW_W, WINDOW_H)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_modal(True)
        self.set_keep_above(True)
        self.get_style_context().add_class("installer-window")
        self.connect("destroy", self._on_destroy)
        self.connect("delete-event", self._on_delete_event)

        self._engine: Optional[InstallEngine] = None
        self._inhibit_proc: Optional[subprocess.Popen] = None
        self._current = 0
        self._config: Optional[InstallConfig] = None
        self._notifier = NotificationManager() if NotificationManager else None

        self._apply_css()
        self._build_ui()
        self._show_step(0)

    def _build_ui(self) -> None:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("installer-header")
        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label(label="ZYNTRIXOS INSTALLER")
        title.set_halign(Gtk.Align.START)
        title.get_style_context().add_class("installer-title")
        self._subtitle = Gtk.Label()
        self._subtitle.set_halign(Gtk.Align.START)
        self._subtitle.get_style_context().add_class("installer-subtitle")
        title_box.pack_start(title, False, False, 0)
        title_box.pack_start(self._subtitle, False, False, 0)
        header.pack_start(title_box, True, True, 0)
        self._step_label = Gtk.Label()
        self._step_label.get_style_context().add_class("installer-step-count")
        header.pack_end(self._step_label, False, False, 0)
        root.pack_start(header, False, False, 0)

        self._stack = Gtk.Stack()
        self._stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT_RIGHT)
        self._stack.set_transition_duration(160)

        self.welcome_step = WelcomeStep()
        self.disk_step = DiskSelectionStep()
        self.partition_step = PartitionStep()
        self.user_step = UserStep()
        self.review_step = ReviewStep()
        self.progress_step = ProgressStep()
        self.complete_step = CompleteStep()

        self._steps = [
            self.welcome_step,
            self.disk_step,
            self.partition_step,
            self.user_step,
            self.review_step,
            self.progress_step,
            self.complete_step,
        ]
        for idx, step in enumerate(self._steps):
            step.on_changed = self._update_nav
            self._stack.add_named(step, f"step-{idx}")
        root.pack_start(self._stack, True, True, 0)

        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        footer.get_style_context().add_class("installer-footer")
        self._error = Gtk.Label(label="")
        self._error.set_halign(Gtk.Align.START)
        self._error.set_line_wrap(True)
        self._error.get_style_context().add_class("installer-error")
        footer.pack_start(self._error, True, True, 0)

        self.back_btn = Gtk.Button(label="Back")
        self.back_btn.connect("clicked", self._on_back)
        self.next_btn = Gtk.Button(label="Next")
        self.next_btn.get_style_context().add_class("suggested-action")
        self.next_btn.connect("clicked", self._on_next)
        footer.pack_end(self.next_btn, False, False, 0)
        footer.pack_end(self.back_btn, False, False, 0)
        root.pack_start(footer, False, False, 0)

        self.progress_step.cancel_button.connect("clicked", self._on_cancel_install)
        self.complete_step.reboot_button.connect("clicked", lambda *_: reboot_now())
        self.complete_step.continue_button.connect("clicked", lambda *_: self.destroy())

        self.add(root)

    def _show_step(self, idx: int) -> None:
        self._current = max(0, min(idx, len(self._steps) - 1))
        step = self._steps[self._current]
        if step is self.partition_step:
            self.partition_step.refresh_for_disk(self.disk_step.selected_disk)
        elif step is self.review_step:
            self._config = self._build_config()
            if self._config:
                self.review_step.set_config(self._config)
        elif step is self.welcome_step:
            self.welcome_step.refresh()
        self._stack.set_visible_child_name(f"step-{self._current}")
        self._subtitle.set_text(step.subtitle)
        self._step_label.set_text(f"{self._current + 1} / {len(self._steps)}")
        self._error.set_text("")
        self._update_nav()

    def _update_nav(self) -> None:
        step = self._steps[self._current]
        installing = self._engine is not None and self._engine.is_alive()
        self.back_btn.set_visible(step not in (self.progress_step, self.complete_step))
        self.back_btn.set_sensitive(self._current > 0 and not installing)
        self.next_btn.set_visible(step not in (self.progress_step, self.complete_step))
        if step is self.review_step:
            self.next_btn.set_label("Install")
            self.next_btn.get_style_context().add_class("destructive-action")
        else:
            self.next_btn.set_label("Next")
            self.next_btn.get_style_context().remove_class("destructive-action")

    def _on_back(self, _btn) -> None:
        self._show_step(self._current - 1)

    def _on_next(self, _btn) -> None:
        step = self._steps[self._current]
        ok, message = step.validate()
        if not ok:
            self._error.set_text(message)
            return
        self._error.set_text("")
        if step is self.review_step:
            self._start_install()
        else:
            self._show_step(self._current + 1)

    def _build_config(self) -> Optional[InstallConfig]:
        try:
            config = self.partition_step.build_config()
            return self.user_step.apply_to_config(config)
        except Exception as exc:
            self._error.set_text(str(exc))
            return None

    def _start_install(self) -> None:
        config = self._build_config()
        if not config:
            return
        errors, warnings = validate_install_config(config)
        if errors:
            self._error.set_text("\n".join(errors))
            return
        if not self._confirm_destructive_action(config, warnings):
            return

        self._config = config
        self._show_step(self._steps.index(self.progress_step))
        self._write_install_lock()
        self._inhibit_idle()
        self.progress_step.set_progress(0.0, "Starting installer", "start")
        self.progress_step.append_log("Starting ZyntrixOS installation")
        self._engine = InstallEngine(
            config,
            progress_cb=self._progress_from_thread,
            log_cb=self._log_from_thread,
            complete_cb=self._complete_from_thread,
        )
        self._engine.start()
        self._update_nav()

    def _confirm_destructive_action(self, config: InstallConfig, warnings: list[str]) -> bool:
        text = f"Install ZyntrixOS to {config.disk.path}?"
        details = [
            f"Mode: {config.mode}",
            f"Disk: {config.disk.title}",
            "This action can erase data on the selected target.",
        ]
        details.extend(warnings)
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.CANCEL,
            text=text,
            secondary_text="\n".join(details),
        )
        install_btn = dialog.add_button("Install", Gtk.ResponseType.OK)
        install_btn.get_style_context().add_class("destructive-action")
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.OK

    def _progress_from_thread(self, fraction: float, message: str, phase: str) -> None:
        GLib.idle_add(self.progress_step.set_progress, fraction, message, phase)

    def _log_from_thread(self, line: str) -> None:
        GLib.idle_add(self.progress_step.append_log, line)

    def _complete_from_thread(self, success: bool, message: str) -> None:
        GLib.idle_add(self._on_install_complete, success, message)

    def _on_install_complete(self, success: bool, message: str) -> bool:
        self._release_idle_inhibit()
        self._remove_install_lock()
        self.progress_step.cancel_button.set_sensitive(False)
        self.complete_step.set_result(success, message)
        if self._notifier:
            if success:
                self._notifier.notify("Installation Complete", "ZyntrixOS is ready to reboot.", LEVEL_INFO)
            else:
                self._notifier.notify("Installation Failed", message[:90], LEVEL_ERROR)
        self._engine = None
        self._show_step(self._steps.index(self.complete_step))
        return False

    def _on_cancel_install(self, _btn) -> None:
        if self._engine and self._engine.is_alive():
            self.progress_step.cancel_button.set_sensitive(False)
            self.progress_step.append_log("Cancel requested; waiting for a safe stop.")
            self._engine.cancel()

    def _on_delete_event(self, *_args) -> bool:
        if self._engine and self._engine.is_alive():
            dialog = Gtk.MessageDialog(
                transient_for=self,
                modal=True,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.NONE,
                text="Cancel installation?",
                secondary_text="The installer will stop at the next safe point and unmount the target.",
            )
            dialog.add_button("Keep Installing", Gtk.ResponseType.CANCEL)
            dialog.add_button("Cancel Install", Gtk.ResponseType.OK)
            response = dialog.run()
            dialog.destroy()
            if response == Gtk.ResponseType.OK:
                self._on_cancel_install(None)
            return True
        return False

    def _on_destroy(self, *_args) -> None:
        if self._engine and self._engine.is_alive():
            self._engine.cancel()
        self._release_idle_inhibit()
        self._remove_install_lock()
        Gtk.main_quit()

    def _inhibit_idle(self) -> None:
        if self._inhibit_proc is not None:
            return
        if shutil_which("systemd-inhibit"):
            try:
                self._inhibit_proc = subprocess.Popen(
                    [
                        "systemd-inhibit",
                        "--what=idle:sleep:shutdown",
                        "--why=ZyntrixOS installation in progress",
                        "--mode=block",
                        "sleep",
                        "infinity",
                    ],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
            except Exception:
                self._inhibit_proc = None
        try:
            subprocess.Popen(["xset", "s", "off"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def _release_idle_inhibit(self) -> None:
        proc = self._inhibit_proc
        self._inhibit_proc = None
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:
                proc.terminate()

    def _write_install_lock(self) -> None:
        try:
            with open(INSTALL_LOCK_PATH, "w", encoding="utf-8") as fh:
                fh.write(str(os.getpid()))
        except Exception:
            pass

    def _remove_install_lock(self) -> None:
        try:
            os.remove(INSTALL_LOCK_PATH)
        except FileNotFoundError:
            pass
        except Exception:
            pass

    def _apply_css(self) -> None:
        css_path = os.path.join(SHELL_DIR, "theme.css")
        try:
            with open(css_path, "r", encoding="utf-8") as fh:
                css_template = fh.read()
        except Exception:
            return

        theme = {
            "accent": "#00d4aa",
            "background": "#0a0b0f",
            "surface": "#12141a",
            "text": "#e8eaf0",
        }
        if load_config:
            try:
                _, loaded = load_config()
                for key in ("background", "surface", "text"):
                    if key in loaded:
                        theme[key] = loaded[key]
            except Exception:
                pass

        css = substitute_theme(css_template, theme)
        provider = Gtk.CssProvider()
        provider.load_from_data(css.encode())
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )


def shutil_which(cmd: str) -> Optional[str]:
    for directory in os.environ.get("PATH", "").split(os.pathsep):
        path = os.path.join(directory, cmd)
        if os.access(path, os.X_OK):
            return path
    return None


def substitute_theme(css_template: str, theme: dict) -> str:
    accent = theme.get("accent", "#00d4aa")
    bg = theme.get("background", "#0a0b0f")
    surface = theme.get("surface", "#12141a")
    text = theme.get("text", "#e8eaf0")

    def darken(hex_color: str, factor: float = 0.6) -> str:
        h = hex_color.lstrip("#")
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        return "#{:02x}{:02x}{:02x}".format(
            min(255, int(r * factor)),
            min(255, int(g * factor)),
            min(255, int(b * factor)),
        )

    def alpha(hex_color: str, a: float = 0.18) -> str:
        h = hex_color.lstrip("#")
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        return f"rgba({r},{g},{b},{a})"

    replacements = {
        "@surface-hover": darken(surface, 1.4) if surface.startswith("#") else "#1e2030",
        "@surface": surface,
        "@accent-dim": alpha(accent),
        "@accent": accent,
        "@border": darken(accent, 0.35),
        "@text-dim": darken(text, 0.55),
        "@text": text,
        "@bg": bg,
    }
    css = css_template
    for token, value in sorted(replacements.items(), key=lambda kv: -len(kv[0])):
        css = css.replace(token, value)
    return css


def main() -> None:
    win = InstallerWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
