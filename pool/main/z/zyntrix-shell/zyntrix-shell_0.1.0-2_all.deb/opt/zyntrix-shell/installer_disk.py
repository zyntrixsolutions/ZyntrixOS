#!/usr/bin/env python3
"""
Disk discovery and install planning helpers for the ZyntrixOS GUI installer.

This module is deliberately GTK-free so it can be unit-tested and reused by
the background installation engine.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import os
import re
import shutil
import subprocess
from typing import Optional


GIB = 1024 ** 3
MIB = 1024 ** 2

MIN_TARGET_BYTES = 8 * GIB
MIN_RAM_BYTES = 2 * GIB
EFI_SIZE_BYTES = 512 * MIB
BIOS_GRUB_SIZE_BYTES = 2 * MIB
MIN_ROOT_BYTES = 5 * GIB

MODE_ENTIRE_DISK = "entire_disk"
MODE_ALONGSIDE = "alongside"
MODE_REPLACE = "replace"
MODE_MANUAL = "manual"

FILESYSTEMS = ("ext4", "btrfs", "xfs")

LIVE_MOUNT_PREFIXES = (
    "/live",
    "/run/live",
    "/lib/live",
    "/mnt/live",
)


@dataclass
class Partition:
    name: str
    path: str
    size: int = 0
    fstype: str = ""
    label: str = ""
    uuid: str = ""
    partuuid: str = ""
    mountpoints: list[str] = field(default_factory=list)
    partlabel: str = ""
    flags: list[str] = field(default_factory=list)
    start: Optional[int] = None
    end: Optional[int] = None

    @property
    def display_name(self) -> str:
        bits = [self.path, format_bytes(self.size)]
        if self.fstype:
            bits.append(self.fstype)
        if self.label:
            bits.append(self.label)
        if self.mountpoints:
            bits.append("mounted")
        return " - ".join(bits)

    @property
    def is_mounted(self) -> bool:
        return bool(self.mountpoints)

    @property
    def is_efi(self) -> bool:
        fs = self.fstype.lower()
        flags = {f.lower() for f in self.flags}
        label = (self.label or self.partlabel).lower()
        return fs in ("vfat", "fat32", "fat16") and (
            "esp" in flags or "boot" in flags or "efi" in label
        )

    @property
    def is_swap(self) -> bool:
        return self.fstype.lower() == "swap"

    @property
    def looks_like_zyntrix_root(self) -> bool:
        label = f"{self.label} {self.partlabel}".lower()
        return "zyntrix" in label or "zyntrixos" in label


@dataclass
class FreeSpace:
    start: int
    end: int
    size: int

    @property
    def display_name(self) -> str:
        return f"Free space - {format_bytes(self.size)}"


@dataclass
class Disk:
    name: str
    path: str
    size: int
    model: str = ""
    vendor: str = ""
    transport: str = ""
    removable: bool = False
    rotational: bool = False
    partitions: list[Partition] = field(default_factory=list)
    free_spaces: list[FreeSpace] = field(default_factory=list)

    @property
    def title(self) -> str:
        model = " ".join(x for x in [self.vendor, self.model] if x).strip()
        prefix = f"{self.path} - {format_bytes(self.size)}"
        if model:
            prefix = f"{prefix} - {model}"
        tags = []
        if self.transport:
            tags.append(self.transport.upper())
        if self.removable:
            tags.append("REMOVABLE")
        if tags:
            prefix = f"{prefix} ({', '.join(tags)})"
        return prefix

    @property
    def has_minimum_size(self) -> bool:
        return self.size >= MIN_TARGET_BYTES

    @property
    def largest_free_space(self) -> Optional[FreeSpace]:
        if not self.free_spaces:
            return None
        return max(self.free_spaces, key=lambda item: item.size)

    @property
    def has_live_mount(self) -> bool:
        for part in self.partitions:
            for mount in part.mountpoints:
                if mount == "/" or mount.startswith(LIVE_MOUNT_PREFIXES):
                    return True
        return False


@dataclass
class PlannedPartition:
    role: str
    size: int
    filesystem: str = ""
    mountpoint: str = ""
    label: str = ""
    path: Optional[str] = None
    format: bool = True
    start: Optional[int] = None
    end: Optional[int] = None
    flags: list[str] = field(default_factory=list)

    @property
    def description(self) -> str:
        target = self.path or "new partition"
        fs = self.filesystem or "no filesystem"
        mount = self.mountpoint or self.role
        return f"{mount}: {target}, {format_bytes(self.size)}, {fs}"


@dataclass
class InstallConfig:
    disk: Disk
    mode: str
    filesystem: str = "ext4"
    plan: list[PlannedPartition] = field(default_factory=list)
    root_partition: Optional[str] = None
    efi_partition: Optional[str] = None
    swap_partition: Optional[str] = None
    format_root: bool = True
    format_efi: bool = False
    hostname: str = "zyntrix-pc"
    full_name: str = ""
    username: str = "zyntrix"
    password: str = field(default="", repr=False)
    root_password: str = field(default="", repr=False)
    same_password_for_root: bool = True
    timezone: str = "UTC"
    locale: str = "en_US.UTF-8"
    keyboard: str = "us"
    encryption_enabled: bool = False

    @property
    def boot_mode(self) -> str:
        return "UEFI" if is_uefi_boot() else "BIOS"

    @property
    def target_mountpoint(self) -> str:
        return "/tmp/zyntrix-install"


def format_bytes(value: int) -> str:
    try:
        size = float(value)
    except Exception:
        size = 0.0
    units = ("B", "KB", "MB", "GB", "TB")
    idx = 0
    while size >= 1024 and idx < len(units) - 1:
        size /= 1024
        idx += 1
    if idx <= 1:
        return f"{int(size)} {units[idx]}"
    return f"{size:.1f} {units[idx]}"


def _parse_int(value, default: int = 0) -> int:
    if isinstance(value, int):
        return value
    if value is None:
        return default
    text = str(value).strip()
    if text.endswith("B"):
        text = text[:-1]
    try:
        return int(float(text))
    except ValueError:
        return default


def _as_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in ("1", "true", "yes", "y")


def _clean_mountpoints(item: dict) -> list[str]:
    mountpoints = item.get("mountpoints")
    if mountpoints is None:
        mountpoint = item.get("mountpoint")
        return [mountpoint] if mountpoint else []
    if isinstance(mountpoints, list):
        return [m for m in mountpoints if m]
    return [mountpoints] if mountpoints else []


def _run_json(cmd: list[str]) -> dict:
    out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=10)
    return json.loads(out)


def _read_blkid() -> dict[str, dict[str, str]]:
    if not shutil.which("blkid"):
        return {}
    try:
        out = subprocess.check_output(
            ["blkid", "-o", "export"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        )
    except Exception:
        return {}

    result: dict[str, dict[str, str]] = {}
    current: dict[str, str] = {}
    for line in out.splitlines() + [""]:
        line = line.strip()
        if not line:
            dev = current.get("DEVNAME")
            if dev:
                result[dev] = dict(current)
            current = {}
            continue
        if "=" in line:
            key, value = line.split("=", 1)
            current[key] = value
    return result


def _lsblk_data() -> dict:
    columns = [
        "NAME", "PATH", "TYPE", "SIZE", "MODEL", "VENDOR", "TRAN", "RM",
        "ROTA", "FSTYPE", "LABEL", "UUID", "PARTUUID", "PARTLABEL",
        "MOUNTPOINTS",
    ]
    cmd = ["lsblk", "-J", "-b", "-o", ",".join(columns)]
    try:
        return _run_json(cmd)
    except Exception:
        fallback = [c for c in columns if c != "MOUNTPOINTS"] + ["MOUNTPOINT"]
        return _run_json(["lsblk", "-J", "-b", "-o", ",".join(fallback)])


def discover_disks(include_loop: bool = False) -> list[Disk]:
    """Return block disks with partitions and best-effort free-space ranges."""
    if not shutil.which("lsblk"):
        return []

    try:
        data = _lsblk_data()
    except Exception:
        return []

    blkid = _read_blkid()
    disks: list[Disk] = []

    for item in data.get("blockdevices", []):
        typ = str(item.get("type", "")).lower()
        if typ != "disk" and not (include_loop and typ == "loop"):
            continue

        path = item.get("path") or f"/dev/{item.get('name', '')}"
        disk = Disk(
            name=str(item.get("name") or os.path.basename(path)),
            path=str(path),
            size=_parse_int(item.get("size")),
            model=str(item.get("model") or "").strip(),
            vendor=str(item.get("vendor") or "").strip(),
            transport=str(item.get("tran") or "").strip(),
            removable=_as_bool(item.get("rm")),
            rotational=_as_bool(item.get("rota")),
        )
        disk.partitions = _parse_partitions(item.get("children", []), blkid)
        _augment_parted_metadata(disk)
        disk.free_spaces = discover_free_space(disk.path)
        disks.append(disk)

    disks.sort(key=lambda d: (d.removable, d.path))
    return disks


def _parse_partitions(children: list[dict], blkid: dict[str, dict[str, str]]) -> list[Partition]:
    parts: list[Partition] = []
    for item in children or []:
        typ = str(item.get("type", "")).lower()
        if typ not in ("part", "crypt", "lvm"):
            parts.extend(_parse_partitions(item.get("children", []), blkid))
            continue
        path = item.get("path") or f"/dev/{item.get('name', '')}"
        info = blkid.get(path, {})
        part = Partition(
            name=str(item.get("name") or os.path.basename(path)),
            path=str(path),
            size=_parse_int(item.get("size")),
            fstype=str(item.get("fstype") or info.get("TYPE", "") or ""),
            label=str(item.get("label") or info.get("LABEL", "") or ""),
            uuid=str(item.get("uuid") or info.get("UUID", "") or ""),
            partuuid=str(item.get("partuuid") or info.get("PARTUUID", "") or ""),
            partlabel=str(item.get("partlabel") or info.get("PARTLABEL", "") or ""),
            mountpoints=_clean_mountpoints(item),
        )
        parts.append(part)
        parts.extend(_parse_partitions(item.get("children", []), blkid))
    return parts


def _augment_parted_metadata(disk: Disk) -> None:
    if not shutil.which("parted") or not os.path.exists(disk.path):
        return
    try:
        out = subprocess.check_output(
            ["parted", "-m", disk.path, "unit", "B", "print"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        )
    except Exception:
        return

    by_number = {_partition_number(p.path): p for p in disk.partitions}
    for line in out.splitlines():
        if not line or line.startswith("BYT") or line.startswith(disk.path):
            continue
        fields = line.split(":")
        if len(fields) < 4 or not fields[0].isdigit():
            continue
        part = by_number.get(int(fields[0]))
        if not part:
            continue
        part.start = _parse_int(fields[1])
        part.end = _parse_int(fields[2])
        if len(fields) >= 7 and fields[6]:
            part.flags = [f.strip() for f in fields[6].split(",") if f.strip()]


def discover_free_space(disk_path: str) -> list[FreeSpace]:
    if not shutil.which("parted") or not os.path.exists(disk_path):
        return []
    try:
        out = subprocess.check_output(
            ["parted", "-m", disk_path, "unit", "B", "print", "free"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=10,
        )
    except Exception:
        return []

    spaces: list[FreeSpace] = []
    for line in out.splitlines():
        if not line or line.startswith("BYT") or line.startswith(disk_path):
            continue
        fields = line.split(":")
        if len(fields) < 5 or fields[4].strip().lower() != "free":
            continue
        start = _parse_int(fields[1])
        end = _parse_int(fields[2])
        size = _parse_int(fields[3])
        if size > 16 * MIB:
            spaces.append(FreeSpace(start=start, end=end, size=size))
    return spaces


def is_live_system() -> bool:
    cmdline = ""
    try:
        with open("/proc/cmdline", "r", encoding="utf-8") as fh:
            cmdline = fh.read()
    except Exception:
        pass
    return (
        os.path.exists("/live/aufs")
        or os.path.exists("/run/live/medium")
        or os.path.exists("/lib/live/mount/medium")
        or "boot=live" in cmdline
        or "fromiso" in cmdline
    )


def is_uefi_boot() -> bool:
    return os.path.exists("/sys/firmware/efi")


def live_source_path() -> str:
    for candidate in ("/live/aufs", "/run/live/rootfs/filesystem.squashfs", "/"):
        if os.path.exists(candidate):
            return candidate
    return "/"


def total_ram_bytes() -> int:
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) * 1024
    except Exception:
        pass
    return 0


def battery_status() -> tuple[Optional[int], bool]:
    for base in ("/sys/class/power_supply/BAT0", "/sys/class/power_supply/BAT1"):
        try:
            with open(os.path.join(base, "capacity"), "r", encoding="utf-8") as fh:
                pct = int(fh.read().strip())
            with open(os.path.join(base, "status"), "r", encoding="utf-8") as fh:
                status = fh.read().strip().lower()
            return pct, status in ("charging", "full")
        except Exception:
            continue
    return None, False


def requirements_status(disks: Optional[list[Disk]] = None) -> dict:
    disks = disks if disks is not None else discover_disks()
    pct, charging = battery_status()
    return {
        "live": is_live_system(),
        "uefi": is_uefi_boot(),
        "ram_bytes": total_ram_bytes(),
        "ram_ok": total_ram_bytes() >= MIN_RAM_BYTES,
        "has_target_disk": any(d.size >= MIN_TARGET_BYTES for d in disks),
        "battery_percent": pct,
        "battery_charging": charging,
        "battery_ok": pct is None or charging or pct >= 50,
        "root": os.geteuid() == 0,
    }


def root_parent_disk() -> Optional[str]:
    if not shutil.which("findmnt"):
        return None
    try:
        source = subprocess.check_output(
            ["findmnt", "-n", "-o", "SOURCE", "/"],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
        ).strip()
    except Exception:
        return None
    if not source.startswith("/dev/"):
        return None
    return parent_disk_for_device(source)


def parent_disk_for_device(path: str) -> Optional[str]:
    if not path.startswith("/dev/") or not shutil.which("lsblk"):
        return None
    try:
        pkname = subprocess.check_output(
            ["lsblk", "-n", "-o", "PKNAME", path],
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=5,
        ).strip().splitlines()[0]
        if pkname:
            return f"/dev/{pkname}"
    except Exception:
        pass
    return path if os.path.exists(path) else None


def validate_install_config(config: InstallConfig) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    if not is_live_system():
        errors.append("The installer must be run from the live USB session.")
    if os.geteuid() != 0:
        errors.append("The installer needs administrator privileges.")
    if config.disk.size < MIN_TARGET_BYTES:
        errors.append(f"Target disk is smaller than {format_bytes(MIN_TARGET_BYTES)}.")
    if config.disk.has_live_mount:
        errors.append("The selected disk contains the running live system.")

    root_disk = root_parent_disk()
    if root_disk and os.path.realpath(root_disk) == os.path.realpath(config.disk.path):
        errors.append("The selected disk is the current root filesystem disk.")

    if config.mode == MODE_MANUAL and not config.root_partition:
        errors.append("Choose a root partition for manual installation.")
    if config.filesystem not in FILESYSTEMS:
        errors.append("Unsupported root filesystem.")
    if config.encryption_enabled:
        warnings.append("Disk encryption is shown as a future option and is not enabled yet.")

    pct, charging = battery_status()
    if pct is not None and not charging and pct < 50:
        warnings.append(f"Battery is at {pct} percent and AC power is not connected.")

    return errors, warnings


def estimate_swap_size_bytes(total_disk_size: int) -> int:
    ram = total_ram_bytes() or (2 * GIB)
    desired = min(max(2 * GIB, ram), 8 * GIB)
    if total_disk_size <= 12 * GIB:
        desired = 1 * GIB
    return desired


def find_efi_partition(disk: Disk) -> Optional[Partition]:
    for part in disk.partitions:
        if part.is_efi:
            return part
    return None


def find_swap_partition(disk: Disk) -> Optional[Partition]:
    for part in disk.partitions:
        if part.is_swap:
            return part
    return None


def find_zyntrix_partitions(disk: Disk) -> list[Partition]:
    return [part for part in disk.partitions if part.looks_like_zyntrix_root]


def propose_auto_layout(
    disk: Disk,
    mode: str = MODE_ENTIRE_DISK,
    filesystem: str = "ext4",
) -> list[PlannedPartition]:
    if filesystem not in FILESYSTEMS:
        filesystem = "ext4"
    if mode == MODE_ENTIRE_DISK:
        return _propose_entire_disk(disk, filesystem)
    if mode == MODE_ALONGSIDE:
        return _propose_alongside(disk, filesystem)
    if mode == MODE_REPLACE:
        return _propose_replace(disk, filesystem)
    return []


def _propose_entire_disk(disk: Disk, filesystem: str) -> list[PlannedPartition]:
    if disk.size < MIN_TARGET_BYTES:
        return []
    plan: list[PlannedPartition] = []
    next_num = 1
    reserved = 0

    if is_uefi_boot():
        plan.append(PlannedPartition(
            role="efi",
            path=partition_path(disk.path, next_num),
            size=EFI_SIZE_BYTES,
            filesystem="vfat",
            mountpoint="/boot/efi",
            label="ZYNTRIX_EFI",
            flags=["esp", "boot"],
        ))
        next_num += 1
        reserved += EFI_SIZE_BYTES
    else:
        plan.append(PlannedPartition(
            role="bios_grub",
            path=partition_path(disk.path, next_num),
            size=BIOS_GRUB_SIZE_BYTES,
            filesystem="",
            label="BIOS_GRUB",
            flags=["bios_grub"],
        ))
        next_num += 1
        reserved += BIOS_GRUB_SIZE_BYTES

    swap = estimate_swap_size_bytes(disk.size)
    plan.append(PlannedPartition(
        role="swap",
        path=partition_path(disk.path, next_num),
        size=swap,
        filesystem="swap",
        label="ZYNTRIX_SWAP",
    ))
    next_num += 1
    reserved += swap

    root = max(0, disk.size - reserved - MIB)
    plan.append(PlannedPartition(
        role="root",
        path=partition_path(disk.path, next_num),
        size=root,
        filesystem=filesystem,
        mountpoint="/",
        label="ZYNTRIX_ROOT",
    ))
    return plan


def _propose_alongside(disk: Disk, filesystem: str) -> list[PlannedPartition]:
    free = disk.largest_free_space
    if free is None or free.size < MIN_TARGET_BYTES:
        return []

    start = align_up(free.start + MIB, MIB)
    end = align_down(free.end - MIB, MIB)
    available = max(0, end - start)
    if available < MIN_TARGET_BYTES:
        return []

    plan: list[PlannedPartition] = []
    next_num = next_partition_number(disk)
    cursor = start

    if is_uefi_boot():
        efi = find_efi_partition(disk)
        if efi:
            plan.append(PlannedPartition(
                role="efi",
                path=efi.path,
                size=efi.size,
                filesystem=efi.fstype or "vfat",
                mountpoint="/boot/efi",
                label=efi.label,
                format=False,
            ))
        else:
            plan.append(PlannedPartition(
                role="efi",
                path=partition_path(disk.path, next_num),
                start=cursor,
                end=cursor + EFI_SIZE_BYTES,
                size=EFI_SIZE_BYTES,
                filesystem="vfat",
                mountpoint="/boot/efi",
                label="ZYNTRIX_EFI",
                flags=["esp", "boot"],
            ))
            cursor += EFI_SIZE_BYTES
            next_num += 1

    swap_size = estimate_swap_size_bytes(disk.size)
    plan.append(PlannedPartition(
        role="swap",
        path=partition_path(disk.path, next_num),
        start=cursor,
        end=cursor + swap_size,
        size=swap_size,
        filesystem="swap",
        label="ZYNTRIX_SWAP",
    ))
    cursor += swap_size
    next_num += 1

    root_size = max(0, end - cursor)
    plan.append(PlannedPartition(
        role="root",
        path=partition_path(disk.path, next_num),
        start=cursor,
        end=end,
        size=root_size,
        filesystem=filesystem,
        mountpoint="/",
        label="ZYNTRIX_ROOT",
    ))
    return plan if root_size >= MIN_ROOT_BYTES else []


def _propose_replace(disk: Disk, filesystem: str) -> list[PlannedPartition]:
    roots = find_zyntrix_partitions(disk)
    if not roots:
        return []
    root = max(roots, key=lambda p: p.size)
    plan = [
        PlannedPartition(
            role="root",
            path=root.path,
            size=root.size,
            filesystem=filesystem,
            mountpoint="/",
            label="ZYNTRIX_ROOT",
            format=True,
        )
    ]
    efi = find_efi_partition(disk)
    if efi:
        plan.insert(0, PlannedPartition(
            role="efi",
            path=efi.path,
            size=efi.size,
            filesystem=efi.fstype or "vfat",
            mountpoint="/boot/efi",
            label=efi.label,
            format=False,
        ))
    swap = find_swap_partition(disk)
    if swap:
        plan.append(PlannedPartition(
            role="swap",
            path=swap.path,
            size=swap.size,
            filesystem="swap",
            label=swap.label,
            format=False,
        ))
    return plan


def next_partition_number(disk: Disk) -> int:
    nums = [_partition_number(part.path) for part in disk.partitions]
    nums = [n for n in nums if n > 0]
    return max(nums, default=0) + 1


def _partition_number(path: str) -> int:
    match = re.search(r"(?:p)?(\d+)$", path)
    return int(match.group(1)) if match else 0


def partition_path(disk_path: str, number: int) -> str:
    if re.search(r"\d$", disk_path):
        return f"{disk_path}p{number}"
    return f"{disk_path}{number}"


def align_up(value: int, step: int) -> int:
    return ((value + step - 1) // step) * step


def align_down(value: int, step: int) -> int:
    return (value // step) * step


def launch_gparted() -> bool:
    for cmd in (["gparted"], ["pkexec", "gparted"], ["sudo", "gparted"]):
        if shutil.which(cmd[0]):
            try:
                subprocess.Popen(cmd, start_new_session=True)
                return True
            except Exception:
                continue
    return False


def username_is_valid(username: str) -> bool:
    return bool(re.fullmatch(r"[a-z_][a-z0-9_-]{0,31}", username or ""))


def hostname_is_valid(hostname: str) -> bool:
    if not hostname or len(hostname) > 63:
        return False
    return bool(re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]", hostname) or re.fullmatch(r"[a-zA-Z0-9]", hostname))
