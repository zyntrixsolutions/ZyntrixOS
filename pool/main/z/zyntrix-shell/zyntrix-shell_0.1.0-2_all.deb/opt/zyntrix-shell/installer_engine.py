#!/usr/bin/env python3
"""
Background installation engine for the ZyntrixOS GUI installer.

All destructive work lives here, away from GTK widgets. The UI passes an
InstallConfig and receives progress/log callbacks from this thread.
"""

from __future__ import annotations

import os
import re
import shutil
import signal
import subprocess
import threading
import time
from typing import Callable, Optional

from installer_disk import (
    FILESYSTEMS,
    MIB,
    MODE_ALONGSIDE,
    MODE_ENTIRE_DISK,
    MODE_MANUAL,
    MODE_REPLACE,
    InstallConfig,
    PlannedPartition,
    format_bytes,
    is_uefi_boot,
    live_source_path,
    validate_install_config,
)


ProgressCallback = Callable[[float, str, str], None]
LogCallback = Callable[[str], None]
CompleteCallback = Callable[[bool, str], None]


class InstallCancelled(Exception):
    """Raised when the user cancels at a safe checkpoint."""


class InstallError(Exception):
    """Raised for installer preflight or command failures."""


class InstallEngine(threading.Thread):
    def __init__(
        self,
        config: InstallConfig,
        progress_cb: Optional[ProgressCallback] = None,
        log_cb: Optional[LogCallback] = None,
        complete_cb: Optional[CompleteCallback] = None,
    ):
        super().__init__(daemon=True, name="zyntrix-install-engine")
        self.config = config
        self.progress_cb = progress_cb
        self.log_cb = log_cb
        self.complete_cb = complete_cb
        self.cancel_event = threading.Event()
        self.current_process: Optional[subprocess.Popen] = None
        self.mountpoint = config.target_mountpoint
        self.log_path = "/tmp/zyntrix-installer.log"
        self._mounted: list[str] = []
        self._bind_mounted: list[str] = []
        self._copy_started = False
        self._copy_finished = False

    def cancel(self) -> None:
        self.cancel_event.set()
        proc = self.current_process
        if proc and proc.poll() is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:
                try:
                    proc.terminate()
                except Exception:
                    pass
            try:
                proc.wait(timeout=5)
            except Exception:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass

    def run(self) -> None:
        success = False
        message = ""
        try:
            self._open_log()
            self._install()
            success = True
            message = "Installation completed successfully."
            self._progress(1.0, "Complete", "complete")
            self._log(message)
        except InstallCancelled:
            message = "Installation cancelled."
            self._log(message)
            try:
                self._rollback_partial_install()
            except Exception as exc:
                self._log(f"Rollback warning: {exc}")
        except Exception as exc:
            message = str(exc)
            self._log(f"ERROR: {message}")
            try:
                self._rollback_partial_install()
            except Exception as rollback_exc:
                self._log(f"Rollback warning: {rollback_exc}")
        finally:
            try:
                self._cleanup_mounts()
            finally:
                if self.complete_cb:
                    self.complete_cb(success, message)

    def _install(self) -> None:
        self._progress(0.02, "Running pre-flight checks", "preflight")
        self._preflight()
        self._check_cancel()

        self._progress(0.08, "Preparing target disk", "partition")
        self._prepare_partitions()
        self._check_cancel()

        self._progress(0.18, "Formatting filesystems", "format")
        self._format_partitions()
        self._check_cancel()

        self._progress(0.25, "Mounting target system", "mount")
        self._mount_target()
        self._check_cancel()

        self._progress(0.32, "Copying live system", "copy")
        self._copy_live_system()
        self._check_cancel()

        self._progress(0.78, "Generating fstab", "fstab")
        self._generate_fstab()
        self._check_cancel()

        self._progress(0.84, "Configuring installed system", "configure")
        self._configure_system()
        self._check_cancel()

        self._progress(0.91, "Installing bootloader", "bootloader")
        self._install_grub()
        self._check_cancel()

        self._progress(0.96, "Cleaning live packages", "cleanup")
        self._cleanup_live_artifacts()
        self._check_cancel()

        self._progress(0.98, "Syncing filesystems", "sync")
        self._run(["sync"], check=False)

    def _open_log(self) -> None:
        try:
            with open(self.log_path, "w", encoding="utf-8") as fh:
                fh.write("ZyntrixOS installer log\n")
                fh.write(time.strftime("Started: %Y-%m-%d %H:%M:%S\n\n"))
        except Exception:
            pass

    def _preflight(self) -> None:
        errors, warnings = validate_install_config(self.config)
        for warning in warnings:
            self._log(f"WARNING: {warning}")
        if errors:
            raise InstallError("; ".join(errors))
        if self.config.filesystem not in FILESYSTEMS:
            raise InstallError(f"Unsupported filesystem: {self.config.filesystem}")
        if not self.config.password:
            raise InstallError("User password is empty.")
        self._log(f"Boot mode: {'UEFI' if is_uefi_boot() else 'BIOS'}")
        self._log(f"Target disk: {self.config.disk.path} ({format_bytes(self.config.disk.size)})")
        self._log(f"Install mode: {self.config.mode}")

    def _prepare_partitions(self) -> None:
        mode = self.config.mode
        if mode == MODE_ENTIRE_DISK:
            self._wipe_and_create_full_disk_layout()
        elif mode == MODE_ALONGSIDE:
            self._create_alongside_layout()
        elif mode == MODE_REPLACE:
            self._use_planned_existing_partitions()
        elif mode == MODE_MANUAL:
            self._use_manual_partitions()
        else:
            raise InstallError(f"Unknown installation mode: {mode}")
        self._settle_block_devices()

    def _wipe_and_create_full_disk_layout(self) -> None:
        disk = self.config.disk.path
        if not self.config.plan:
            raise InstallError("No partition plan is available.")
        self._log(f"Creating new GPT partition table on {disk}")
        self._run(["swapoff", "-a"], check=False)
        self._run(["wipefs", "-a", disk])
        self._run(["parted", "-s", disk, "mklabel", "gpt"])

        start_mib = 1
        for part in self.config.plan:
            end_mib = start_mib + max(1, part.size // MIB)
            if part.role == "bios_grub":
                self._run(["parted", "-s", disk, "mkpart", "BIOS_GRUB", f"{start_mib}MiB", f"{end_mib}MiB"])
                self._run(["parted", "-s", disk, "set", str(self._part_number(part)), "bios_grub", "on"])
            elif part.role == "efi":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_EFI", "fat32", f"{start_mib}MiB", f"{end_mib}MiB"])
                self._run(["parted", "-s", disk, "set", str(self._part_number(part)), "esp", "on"])
            elif part.role == "swap":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_SWAP", "linux-swap", f"{start_mib}MiB", f"{end_mib}MiB"])
            elif part.role == "root":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_ROOT", f"{start_mib}MiB", "100%"])
                part.size = max(0, self.config.disk.size - start_mib * MIB)
                break
            start_mib = end_mib

    def _create_alongside_layout(self) -> None:
        disk = self.config.disk.path
        create_parts = [p for p in self.config.plan if p.format and p.start is not None and p.end is not None]
        if not create_parts:
            raise InstallError(
                "No usable free space was found. Open GParted, shrink an existing partition, then refresh."
            )
        for part in create_parts:
            start = f"{part.start}B"
            end = f"{part.end}B"
            if part.role == "efi":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_EFI", "fat32", start, end])
                self._run(["parted", "-s", disk, "set", str(self._part_number(part)), "esp", "on"], check=False)
            elif part.role == "swap":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_SWAP", "linux-swap", start, end])
            elif part.role == "root":
                self._run(["parted", "-s", disk, "mkpart", "ZYNTRIX_ROOT", start, end])

    def _use_planned_existing_partitions(self) -> None:
        if not any(p.role == "root" and p.path for p in self.config.plan):
            raise InstallError("No existing ZyntrixOS root partition was found.")

    def _use_manual_partitions(self) -> None:
        plan: list[PlannedPartition] = []
        if self.config.efi_partition:
            plan.append(PlannedPartition(
                role="efi",
                path=self.config.efi_partition,
                size=0,
                filesystem="vfat",
                mountpoint="/boot/efi",
                format=self.config.format_efi,
            ))
        if self.config.swap_partition:
            plan.append(PlannedPartition(
                role="swap",
                path=self.config.swap_partition,
                size=0,
                filesystem="swap",
                format=False,
            ))
        if not self.config.root_partition:
            raise InstallError("Manual mode requires a root partition.")
        plan.append(PlannedPartition(
            role="root",
            path=self.config.root_partition,
            size=0,
            filesystem=self.config.filesystem,
            mountpoint="/",
            label="ZYNTRIX_ROOT",
            format=self.config.format_root,
        ))
        self.config.plan = plan

    def _format_partitions(self) -> None:
        for part in self.config.plan:
            if not part.path or part.role == "bios_grub":
                continue
            if not part.format and part.role != "swap":
                self._log(f"Keeping existing filesystem on {part.path}")
                continue
            if part.role == "efi":
                if part.format:
                    self._run(["mkfs.vfat", "-F", "32", "-n", part.label or "ZYNTRIX_EFI", part.path])
            elif part.role == "swap":
                if part.format or self.config.mode in (MODE_ENTIRE_DISK, MODE_ALONGSIDE):
                    self._run(["mkswap", "-L", part.label or "ZYNTRIX_SWAP", part.path])
            elif part.role == "root":
                fs = part.filesystem or self.config.filesystem
                if fs == "ext4":
                    self._run(["mkfs.ext4", "-F", "-L", part.label or "ZYNTRIX_ROOT", part.path])
                elif fs == "btrfs":
                    self._run(["mkfs.btrfs", "-f", "-L", part.label or "ZYNTRIX_ROOT", part.path])
                elif fs == "xfs":
                    self._run(["mkfs.xfs", "-f", "-L", part.label or "ZYNTRIX_ROOT", part.path])
                else:
                    raise InstallError(f"Unsupported filesystem: {fs}")

    def _mount_target(self) -> None:
        root = self._plan_part("root")
        if not root or not root.path:
            raise InstallError("Root partition is missing from the plan.")
        os.makedirs(self.mountpoint, exist_ok=True)
        self._run(["mount", root.path, self.mountpoint])
        self._mounted.append(self.mountpoint)

        efi = self._plan_part("efi")
        if efi and efi.path and is_uefi_boot():
            efi_dir = os.path.join(self.mountpoint, "boot", "efi")
            os.makedirs(efi_dir, exist_ok=True)
            self._run(["mount", efi.path, efi_dir])
            self._mounted.append(efi_dir)

    def _copy_live_system(self) -> None:
        source = live_source_path()
        if source != "/" and not os.path.isdir(source):
            source = "/"
        source = source.rstrip("/") + "/"
        self._copy_started = True
        self._log(f"Copy source: {source}")
        cmd = [
            "rsync",
            "-aAXH",
            "--numeric-ids",
            "--info=progress2",
            "--delete",
        ]
        if source == "/":
            cmd.extend([
                "--exclude=/dev/*",
                "--exclude=/proc/*",
                "--exclude=/sys/*",
                "--exclude=/tmp/*",
                "--exclude=/run/*",
                "--exclude=/mnt/*",
                "--exclude=/media/*",
                "--exclude=/live/*",
                "--exclude=/lost+found",
            ])
        cmd.extend([source, self.mountpoint + "/"])
        self._run(cmd, progress_phase="copy", progress_base=0.32, progress_span=0.44)
        self._copy_finished = True

    def _generate_fstab(self) -> None:
        lines = [
            "# /etc/fstab generated by ZyntrixOS installer",
            "proc /proc proc defaults 0 0",
        ]
        for part in self.config.plan:
            if not part.path:
                continue
            uuid = self._blkid_value(part.path, "UUID")
            if not uuid:
                continue
            if part.role == "root":
                fs = part.filesystem or self.config.filesystem
                opts = "defaults,noatime"
                lines.append(f"UUID={uuid} / {fs} {opts} 0 1")
            elif part.role == "efi" and is_uefi_boot():
                lines.append(f"UUID={uuid} /boot/efi vfat umask=0077 0 1")
            elif part.role == "swap":
                lines.append(f"UUID={uuid} none swap sw 0 0")

        fstab_path = os.path.join(self.mountpoint, "etc", "fstab")
        os.makedirs(os.path.dirname(fstab_path), exist_ok=True)
        with open(fstab_path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + "\n")
        self._log("Generated /etc/fstab with UUID entries")

    def _configure_system(self) -> None:
        hostname = self.config.hostname.strip() or "zyntrix-pc"
        self._write_target_file("/etc/hostname", hostname + "\n")
        self._write_target_file(
            "/etc/hosts",
            "127.0.0.1 localhost\n"
            f"127.0.1.1 {hostname}\n"
            "::1 localhost ip6-localhost ip6-loopback\n",
        )

        timezone = self.config.timezone.strip() or "UTC"
        if os.path.exists(os.path.join(self.mountpoint, "usr", "share", "zoneinfo", timezone)):
            self._chroot(["ln", "-sf", f"/usr/share/zoneinfo/{timezone}", "/etc/localtime"], check=False)
        self._write_target_file("/etc/timezone", timezone + "\n")

        self._ensure_chroot_mounts()
        self._create_user()
        self._configure_locale()
        self._configure_keyboard()

    def _create_user(self) -> None:
        username = self.config.username.strip()
        full_name = self.config.full_name.strip()
        groups = "sudo,audio,video,plugdev,netdev,input,tty"
        if not username:
            raise InstallError("Username is empty.")
        if self._chroot_check(["id", username]):
            self._log(f"User {username} already exists; updating groups and password")
            self._chroot(["usermod", "-aG", groups, username], check=False)
        else:
            cmd = [
                "useradd",
                "-m",
                "-k",
                "/etc/skel",
                "-s",
                "/bin/bash",
                "-G",
                groups,
            ]
            if full_name:
                cmd.extend(["-c", full_name])
            cmd.append(username)
            self._chroot(cmd)

        self._chroot_input(["chpasswd"], f"{username}:{self.config.password}\n")
        home = f"/home/{username}"
        self._chroot(["rsync", "-a", "--ignore-existing", "/etc/skel/", f"{home}/"], check=False)
        self._chroot(["chown", "-R", f"{username}:{username}", home], check=False)

        root_password = self.config.password if self.config.same_password_for_root else self.config.root_password
        if root_password:
            self._chroot_input(["chpasswd"], f"root:{root_password}\n")

    def _configure_locale(self) -> None:
        locale = self.config.locale.strip() or "en_US.UTF-8"
        locale_gen = os.path.join(self.mountpoint, "etc", "locale.gen")
        try:
            if os.path.exists(locale_gen):
                text = open(locale_gen, "r", encoding="utf-8").read()
                line = f"{locale} UTF-8"
                if line not in text:
                    text += f"\n{line}\n"
                text = re.sub(rf"^#\s*{re.escape(line)}$", line, text, flags=re.MULTILINE)
                with open(locale_gen, "w", encoding="utf-8") as fh:
                    fh.write(text)
        except Exception as exc:
            self._log(f"Locale file warning: {exc}")
        self._write_target_file("/etc/default/locale", f"LANG={locale}\n")
        self._chroot(["locale-gen"], check=False)
        self._chroot(["update-locale", f"LANG={locale}"], check=False)

    def _configure_keyboard(self) -> None:
        layout = self.config.keyboard.strip() or "us"
        keyboard = (
            'XKBMODEL="pc105"\n'
            f'XKBLAYOUT="{layout}"\n'
            'XKBVARIANT=""\n'
            'XKBOPTIONS=""\n'
            'BACKSPACE="guess"\n'
        )
        self._write_target_file("/etc/default/keyboard", keyboard)

    def _install_grub(self) -> None:
        self._ensure_chroot_mounts()
        if is_uefi_boot():
            efi = self._plan_part("efi")
            if not efi or not efi.path:
                raise InstallError("UEFI boot requires an EFI System Partition.")
            self._chroot([
                "grub-install",
                "--target=x86_64-efi",
                "--efi-directory=/boot/efi",
                "--bootloader-id=ZyntrixOS",
                "--recheck",
            ])
        else:
            self._chroot([
                "grub-install",
                "--target=i386-pc",
                "--recheck",
                self.config.disk.path,
            ])
        self._chroot(["update-initramfs", "-u", "-k", "all"], check=False)
        self._chroot(["update-grub"], check=False)
        self._chroot(["grub-mkconfig", "-o", "/boot/grub/grub.cfg"], check=False)

    def _cleanup_live_artifacts(self) -> None:
        self._ensure_chroot_mounts()
        if self._chroot_check(["sh", "-c", "command -v live-to-installed >/dev/null 2>&1"]):
            self._chroot(["live-to-installed"], check=False)
        self._chroot(["dpkg", "-r", "live-init-antix"], check=False)

        for rel in (
            "/etc/live/config.conf",
            "/etc/live/boot.conf",
            "/usr/local/bin/remaster-live",
        ):
            path = os.path.join(self.mountpoint, rel.lstrip("/"))
            if os.path.exists(path):
                try:
                    os.remove(path)
                except OSError:
                    pass

    def _cleanup_mounts(self) -> None:
        for target in reversed(self._bind_mounted):
            self._run(["umount", "-lf", target], check=False, respect_cancel=False)
        self._bind_mounted.clear()
        for target in reversed(self._mounted):
            self._run(["umount", "-lf", target], check=False, respect_cancel=False)
        self._mounted.clear()
        try:
            os.rmdir(self.mountpoint)
        except OSError:
            pass

    def _rollback_partial_install(self) -> None:
        if not self._copy_started or self._copy_finished:
            return
        if not os.path.ismount(self.mountpoint):
            return
        self._log("Clearing partial copied system from target root")
        for name in os.listdir(self.mountpoint):
            path = os.path.join(self.mountpoint, name)
            if os.path.ismount(path):
                continue
            try:
                if os.path.isdir(path) and not os.path.islink(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
            except Exception as exc:
                self._log(f"Rollback could not remove {path}: {exc}")

    def _ensure_chroot_mounts(self) -> None:
        mounts = [
            ("/dev", "dev"),
            ("/dev/pts", "dev/pts"),
            ("/proc", "proc"),
            ("/sys", "sys"),
            ("/run", "run"),
        ]
        for src, rel in mounts:
            target = os.path.join(self.mountpoint, rel)
            if target in self._bind_mounted:
                continue
            os.makedirs(target, exist_ok=True)
            self._run(["mount", "--bind", src, target], check=False)
            self._bind_mounted.append(target)

    def _settle_block_devices(self) -> None:
        self._run(["partprobe", self.config.disk.path], check=False)
        self._run(["udevadm", "settle"], check=False)
        time.sleep(1)

    def _plan_part(self, role: str) -> Optional[PlannedPartition]:
        for part in self.config.plan:
            if part.role == role:
                return part
        return None

    @staticmethod
    def _part_number(part: PlannedPartition) -> int:
        if not part.path:
            return 0
        match = re.search(r"(?:p)?(\d+)$", part.path)
        return int(match.group(1)) if match else 0

    def _write_target_file(self, relpath: str, content: str) -> None:
        path = os.path.join(self.mountpoint, relpath.lstrip("/"))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(content)

    def _blkid_value(self, path: str, key: str) -> str:
        try:
            return subprocess.check_output(
                ["blkid", "-s", key, "-o", "value", path],
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=10,
            ).strip()
        except Exception:
            return ""

    def _chroot(self, cmd: list[str], check: bool = True) -> subprocess.CompletedProcess:
        return self._run(["chroot", self.mountpoint] + cmd, check=check)

    def _chroot_input(self, cmd: list[str], data: str) -> None:
        self._check_cancel()
        full = ["chroot", self.mountpoint] + cmd
        self._log("$ " + " ".join(full))
        proc = subprocess.Popen(
            full,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            start_new_session=True,
        )
        self.current_process = proc
        out, _ = proc.communicate(data)
        self.current_process = None
        if out:
            for line in out.splitlines():
                self._log(line)
        if proc.returncode != 0:
            raise InstallError(f"Command failed ({proc.returncode}): {' '.join(full)}")

    def _chroot_check(self, cmd: list[str]) -> bool:
        try:
            result = subprocess.run(
                ["chroot", self.mountpoint] + cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
            )
            return result.returncode == 0
        except Exception:
            return False

    def _run(
        self,
        cmd: list[str],
        check: bool = True,
        progress_phase: str = "",
        progress_base: float = 0.0,
        progress_span: float = 0.0,
        respect_cancel: bool = True,
    ) -> subprocess.CompletedProcess:
        if respect_cancel:
            self._check_cancel()
        self._log("$ " + " ".join(cmd))
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                start_new_session=True,
            )
        except FileNotFoundError as exc:
            if check:
                raise InstallError(f"Required command not found: {cmd[0]}") from exc
            self._log(f"Missing optional command: {cmd[0]}")
            return subprocess.CompletedProcess(cmd, 127)

        self.current_process = proc
        output: list[str] = []
        try:
            assert proc.stdout is not None
            for raw in proc.stdout:
                if respect_cancel and self.cancel_event.is_set():
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    except Exception:
                        proc.terminate()
                    raise InstallCancelled()
                line = raw.rstrip("\n")
                output.append(line)
                if line:
                    self._log(line)
                    if progress_phase:
                        fraction = self._parse_rsync_progress(line)
                        if fraction is not None:
                            self._progress(
                                progress_base + fraction * progress_span,
                                f"Copying live system ({int(fraction * 100)}%)",
                                progress_phase,
                            )
            rc = proc.wait()
        finally:
            self.current_process = None

        if rc != 0 and check:
            raise InstallError(f"Command failed ({rc}): {' '.join(cmd)}")
        return subprocess.CompletedProcess(cmd, rc, "\n".join(output))

    @staticmethod
    def _parse_rsync_progress(line: str) -> Optional[float]:
        match = re.search(r"\s(\d{1,3})%\s", line)
        if not match:
            return None
        pct = max(0, min(100, int(match.group(1))))
        return pct / 100.0

    def _check_cancel(self) -> None:
        if self.cancel_event.is_set():
            raise InstallCancelled()

    def _progress(self, fraction: float, message: str, phase: str) -> None:
        if self.progress_cb:
            self.progress_cb(max(0.0, min(1.0, fraction)), message, phase)

    def _log(self, message: str) -> None:
        line = str(message)
        try:
            with open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except Exception:
            pass
        if self.log_cb:
            self.log_cb(line)
