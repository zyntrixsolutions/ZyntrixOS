#!/usr/bin/env python3
"""
GTK3 wizard step widgets for the ZyntrixOS installer.
"""

from __future__ import annotations

import os
import re
import subprocess
from typing import Callable, Optional

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf

from installer_disk import (
    FILESYSTEMS,
    MIN_RAM_BYTES,
    MIN_TARGET_BYTES,
    MODE_ALONGSIDE,
    MODE_ENTIRE_DISK,
    MODE_MANUAL,
    MODE_REPLACE,
    Disk,
    InstallConfig,
    Partition,
    PlannedPartition,
    discover_disks,
    find_efi_partition,
    find_swap_partition,
    find_zyntrix_partitions,
    format_bytes,
    hostname_is_valid,
    is_live_system,
    is_uefi_boot,
    launch_gparted,
    propose_auto_layout,
    requirements_status,
    total_ram_bytes,
    username_is_valid,
)


ACCENT = (0.0, 0.83, 0.67, 1.0)
SURFACE = (0.07, 0.08, 0.11, 1.0)
BORDER = (0.0, 0.35, 0.28, 1.0)
TEXT_DIM = (0.55, 0.58, 0.64, 1.0)
WARNING = (0.96, 0.62, 0.04, 1.0)
ERROR = (0.94, 0.27, 0.27, 1.0)


class BaseStep(Gtk.Box):
    def __init__(self, title: str, subtitle: str = ""):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        self.title = title
        self.subtitle = subtitle
        self.on_changed: Optional[Callable[[], None]] = None
        self.set_margin_start(28)
        self.set_margin_end(28)
        self.set_margin_top(24)
        self.set_margin_bottom(20)

    def validate(self) -> tuple[bool, str]:
        return True, ""

    def refresh(self) -> None:
        pass

    def emit_changed(self) -> None:
        if self.on_changed:
            self.on_changed()

    @staticmethod
    def section_label(text: str) -> Gtk.Label:
        lbl = Gtk.Label()
        lbl.set_markup(f"<b>{GLib.markup_escape_text(text)}</b>")
        lbl.set_halign(Gtk.Align.START)
        lbl.get_style_context().add_class("installer-section-label")
        return lbl

    @staticmethod
    def muted_label(text: str) -> Gtk.Label:
        lbl = Gtk.Label(label=text)
        lbl.set_halign(Gtk.Align.START)
        lbl.set_line_wrap(True)
        lbl.get_style_context().add_class("installer-muted")
        return lbl

    @staticmethod
    def error_label(text: str = "") -> Gtk.Label:
        lbl = Gtk.Label(label=text)
        lbl.set_halign(Gtk.Align.START)
        lbl.set_line_wrap(True)
        lbl.get_style_context().add_class("installer-error")
        return lbl


class RequirementRow(Gtk.Box):
    def __init__(self, label: str, ok: bool, detail: str):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.get_style_context().add_class("installer-requirement")
        icon_name = "emblem-ok-symbolic" if ok else "dialog-warning-symbolic"
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU)
        self.pack_start(icon, False, False, 0)

        text = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label(label=label)
        title.set_halign(Gtk.Align.START)
        title.get_style_context().add_class("installer-body")
        sub = Gtk.Label(label=detail)
        sub.set_halign(Gtk.Align.START)
        sub.set_line_wrap(True)
        sub.get_style_context().add_class("installer-muted")
        text.pack_start(title, False, False, 0)
        text.pack_start(sub, False, False, 0)
        self.pack_start(text, True, True, 0)


class DiskMap(Gtk.DrawingArea):
    def __init__(self):
        super().__init__()
        self.disk: Optional[Disk] = None
        self.set_size_request(-1, 72)
        self.connect("draw", self._draw)

    def set_disk(self, disk: Optional[Disk]) -> None:
        self.disk = disk
        self.queue_draw()

    def _draw(self, _widget, cr) -> bool:
        alloc = self.get_allocation()
        width = max(1, alloc.width)
        height = max(1, alloc.height)
        radius = 6

        cr.set_source_rgba(*SURFACE)
        rounded_rect(cr, 1, 10, width - 2, height - 20, radius)
        cr.fill_preserve()
        cr.set_source_rgba(*BORDER)
        cr.set_line_width(1)
        cr.stroke()

        if not self.disk or self.disk.size <= 0:
            cr.set_source_rgba(*TEXT_DIM)
            cr.move_to(18, height / 2 + 4)
            cr.show_text("No disk selected")
            return False

        x = 4.0
        usable_w = max(1.0, width - 8.0)
        y = 13.0
        h = height - 26.0
        palette = [
            (0.00, 0.83, 0.67, 0.75),
            (0.13, 0.83, 0.93, 0.65),
            (0.96, 0.62, 0.04, 0.65),
            (0.45, 0.31, 0.95, 0.65),
            (0.09, 0.72, 0.48, 0.65),
        ]

        parts = sorted(self.disk.partitions, key=lambda p: p.start if p.start is not None else 0)
        used_width = 0.0
        for idx, part in enumerate(parts):
            part_w = max(3.0, usable_w * (part.size / self.disk.size))
            color = palette[idx % len(palette)]
            cr.set_source_rgba(*color)
            cr.rectangle(x, y, min(part_w, width - x - 4), h)
            cr.fill()
            used_width += part_w
            x += part_w

        free_w = max(0.0, usable_w - used_width)
        if free_w > 2:
            cr.set_source_rgba(0.18, 0.20, 0.25, 1.0)
            cr.rectangle(min(x, width - 4), y, free_w, h)
            cr.fill()
        return False


def rounded_rect(cr, x: float, y: float, w: float, h: float, r: float) -> None:
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -1.5708, 0)
    cr.arc(x + w - r, y + h - r, r, 0, 1.5708)
    cr.arc(x + r, y + h - r, r, 1.5708, 3.14159)
    cr.arc(x + r, y + r, r, 3.14159, 4.71239)
    cr.close_path()


class WelcomeStep(BaseStep):
    def __init__(self):
        super().__init__("Install ZyntrixOS", "Copy the live USB system to an internal drive.")
        hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=18)
        logo = self._logo()
        hero.pack_start(logo, False, False, 0)

        copy = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        title = Gtk.Label(label="Install ZyntrixOS")
        title.set_halign(Gtk.Align.START)
        title.get_style_context().add_class("installer-hero-title")
        body = self.muted_label(
            "The installer will guide disk selection, user setup, bootloader installation, and first boot configuration."
        )
        warning = Gtk.Label(label="This will modify hard drive partitions.")
        warning.set_halign(Gtk.Align.START)
        warning.get_style_context().add_class("installer-warning")
        copy.pack_start(title, False, False, 0)
        copy.pack_start(body, False, False, 0)
        copy.pack_start(warning, False, False, 0)
        hero.pack_start(copy, True, True, 0)
        self.pack_start(hero, False, False, 0)

        self.pack_start(self.section_label("Requirements"), False, False, 0)
        self._req_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.pack_start(self._req_box, False, False, 0)
        self._error = self.error_label()
        self.pack_start(self._error, False, False, 0)
        self.refresh()

    def _logo(self) -> Gtk.Widget:
        candidates = [
            os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "assets", "zyntrix-logo.png"),
            "/usr/share/zyntrix/zyntrix-logo.png",
            "/opt/zyntrix-shell/zyntrix-logo.png",
        ]
        for path in candidates:
            if os.path.exists(path):
                try:
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(path, 96, 96, True)
                    return Gtk.Image.new_from_pixbuf(pb)
                except Exception:
                    continue
        return Gtk.Image.new_from_icon_name("drive-harddisk-symbolic", Gtk.IconSize.DIALOG)

    def refresh(self) -> None:
        for child in list(self._req_box.get_children()):
            self._req_box.remove(child)
        status = requirements_status()
        ram = status["ram_bytes"]
        rows = [
            ("Live USB session", status["live"], "Detected /live/aufs or live boot parameters."),
            ("Administrator access", status["root"], "Required for partitioning and bootloader installation."),
            ("Memory", status["ram_ok"], f"{format_bytes(ram)} detected; {format_bytes(MIN_RAM_BYTES)} recommended."),
            ("Target disk", status["has_target_disk"], f"At least {format_bytes(MIN_TARGET_BYTES)} available on one disk."),
            ("Boot mode", True, "UEFI detected." if status["uefi"] else "BIOS boot detected."),
        ]
        if status["battery_percent"] is not None:
            rows.append((
                "Power",
                status["battery_ok"],
                f"Battery {status['battery_percent']}%; AC connected." if status["battery_charging"]
                else f"Battery {status['battery_percent']}%; connect AC power before installing.",
            ))
        for label, ok, detail in rows:
            self._req_box.pack_start(RequirementRow(label, ok, detail), False, False, 0)
        self._req_box.show_all()
        self._error.set_text("" if status["live"] else "The installer is intended for the live USB session.")

    def validate(self) -> tuple[bool, str]:
        status = requirements_status()
        if not status["live"]:
            return False, "Start ZyntrixOS from the live USB before installing."
        if not status["root"]:
            return False, "Run the installer with administrator privileges."
        if not status["has_target_disk"]:
            return False, f"No disk at least {format_bytes(MIN_TARGET_BYTES)} was found."
        return True, ""


class DiskSelectionStep(BaseStep):
    def __init__(self):
        super().__init__("Select Disk", "Choose where ZyntrixOS will be installed.")
        self.disks: list[Disk] = []
        self.selected_disk: Optional[Disk] = None

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._combo = Gtk.ComboBoxText()
        self._combo.set_hexpand(True)
        self._combo.connect("changed", self._on_combo_changed)
        refresh = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.BUTTON)
        refresh.set_tooltip_text("Refresh disks")
        refresh.connect("clicked", lambda _: self.refresh())
        row.pack_start(self._combo, True, True, 0)
        row.pack_start(refresh, False, False, 0)
        self.pack_start(row, False, False, 0)

        self._details = self.muted_label("")
        self.pack_start(self._details, False, False, 0)
        self._map = DiskMap()
        self.pack_start(self._map, False, False, 0)

        self.pack_start(self.section_label("Partitions"), False, False, 0)
        self._parts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_min_content_height(160)
        scroller.add(self._parts)
        self.pack_start(scroller, True, True, 0)

        self._error = self.error_label()
        self.pack_start(self._error, False, False, 0)
        self.refresh()

    def refresh(self) -> None:
        old_path = self.selected_disk.path if self.selected_disk else ""
        self.disks = discover_disks()
        self._combo.remove_all()
        active_idx = 0
        for idx, disk in enumerate(self.disks):
            self._combo.append_text(disk.title)
            if disk.path == old_path:
                active_idx = idx
        if self.disks:
            self._combo.set_active(active_idx)
        else:
            self.selected_disk = None
            self._render_disk()
        self.emit_changed()

    def _on_combo_changed(self, _combo) -> None:
        idx = self._combo.get_active()
        self.selected_disk = self.disks[idx] if 0 <= idx < len(self.disks) else None
        self._render_disk()
        self.emit_changed()

    def _render_disk(self) -> None:
        disk = self.selected_disk
        self._map.set_disk(disk)
        for child in list(self._parts.get_children()):
            self._parts.remove(child)
        if not disk:
            self._details.set_text("No disks detected.")
            self._error.set_text("Connect or enable a target disk, then refresh.")
            return
        free = disk.largest_free_space
        free_text = f"Largest free space: {format_bytes(free.size)}." if free else "No unallocated space reported."
        safety = " Running live media detected on this disk." if disk.has_live_mount else ""
        self._details.set_text(
            f"{disk.path}, {format_bytes(disk.size)}. {free_text}{safety}"
        )
        self._error.set_text("" if disk.has_minimum_size and not disk.has_live_mount else self._disk_error(disk))
        if not disk.partitions:
            self._parts.pack_start(self.muted_label("No partitions reported."), False, False, 0)
        for part in disk.partitions:
            lbl = Gtk.Label(label=part.display_name)
            lbl.set_halign(Gtk.Align.START)
            lbl.get_style_context().add_class("installer-body")
            self._parts.pack_start(lbl, False, False, 0)
        if disk.free_spaces:
            for free_space in disk.free_spaces:
                lbl = Gtk.Label(label=free_space.display_name)
                lbl.set_halign(Gtk.Align.START)
                lbl.get_style_context().add_class("installer-muted")
                self._parts.pack_start(lbl, False, False, 0)
        self._parts.show_all()

    @staticmethod
    def _disk_error(disk: Disk) -> str:
        if disk.has_live_mount:
            return "This disk appears to contain the running live session."
        if not disk.has_minimum_size:
            return f"Target disk must be at least {format_bytes(MIN_TARGET_BYTES)}."
        return ""

    def validate(self) -> tuple[bool, str]:
        if not self.selected_disk:
            return False, "Select a target disk."
        if self.selected_disk.has_live_mount:
            return False, "Choose a disk that is not the running live USB."
        if not self.selected_disk.has_minimum_size:
            return False, f"The target disk must be at least {format_bytes(MIN_TARGET_BYTES)}."
        return True, ""


class PartitionStep(BaseStep):
    def __init__(self):
        super().__init__("Partitioning", "Choose an installation layout.")
        self.disk: Optional[Disk] = None

        self._mode_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self._entire = Gtk.RadioButton.new_with_label_from_widget(None, "Auto: use entire disk")
        self._alongside = Gtk.RadioButton.new_with_label_from_widget(self._entire, "Install alongside existing OS")
        self._replace = Gtk.RadioButton.new_with_label_from_widget(self._entire, "Replace existing ZyntrixOS")
        self._manual = Gtk.RadioButton.new_with_label_from_widget(self._entire, "Manual: use existing partitions")
        for btn in (self._entire, self._alongside, self._replace, self._manual):
            btn.connect("toggled", lambda *_: self._render_plan())
            self._mode_box.pack_start(btn, False, False, 0)
        self.pack_start(self._mode_box, False, False, 0)

        fs_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        fs_row.pack_start(Gtk.Label(label="Root filesystem:"), False, False, 0)
        self._fs = Gtk.ComboBoxText()
        for fs in FILESYSTEMS:
            self._fs.append_text(fs)
        self._fs.set_active(0)
        self._fs.connect("changed", lambda *_: self._render_plan())
        fs_row.pack_start(self._fs, False, False, 0)
        self._encryption = Gtk.CheckButton(label="Encrypt installation")
        self._encryption.set_sensitive(False)
        self._encryption.set_tooltip_text("Reserved for a future encrypted install flow")
        fs_row.pack_start(self._encryption, False, False, 0)
        self.pack_start(fs_row, False, False, 0)

        manual_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        manual_box.get_style_context().add_class("installer-inline-panel")
        self._root_combo = Gtk.ComboBoxText()
        self._efi_combo = Gtk.ComboBoxText()
        self._swap_combo = Gtk.ComboBoxText()
        self._format_root = Gtk.CheckButton(label="Format root partition")
        self._format_root.set_active(True)
        self._format_efi = Gtk.CheckButton(label="Format EFI partition")
        self._format_efi.set_active(False)
        for label, combo in (
            ("Root partition", self._root_combo),
            ("EFI partition", self._efi_combo),
            ("Swap partition", self._swap_combo),
        ):
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            row.pack_start(Gtk.Label(label=label), False, False, 0)
            combo.set_hexpand(True)
            combo.connect("changed", lambda *_: self.emit_changed())
            row.pack_start(combo, True, True, 0)
            manual_box.pack_start(row, False, False, 0)
        manual_box.pack_start(self._format_root, False, False, 0)
        manual_box.pack_start(self._format_efi, False, False, 0)
        gparted = Gtk.Button(label="Open GParted")
        gparted.connect("clicked", self._on_gparted)
        manual_box.pack_start(gparted, False, False, 0)
        self._manual_box = manual_box
        self.pack_start(manual_box, False, False, 0)

        self.pack_start(self.section_label("Proposed Layout"), False, False, 0)
        self._plan_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        self.pack_start(self._plan_box, True, True, 0)
        self._error = self.error_label()
        self.pack_start(self._error, False, False, 0)

    def refresh_for_disk(self, disk: Optional[Disk]) -> None:
        self.disk = disk
        self._populate_manual_combos()
        self._render_plan()

    def selected_mode(self) -> str:
        if self._alongside.get_active():
            return MODE_ALONGSIDE
        if self._replace.get_active():
            return MODE_REPLACE
        if self._manual.get_active():
            return MODE_MANUAL
        return MODE_ENTIRE_DISK

    def selected_filesystem(self) -> str:
        return self._fs.get_active_text() or "ext4"

    def current_plan(self) -> list[PlannedPartition]:
        if not self.disk:
            return []
        return propose_auto_layout(self.disk, self.selected_mode(), self.selected_filesystem())

    def build_config(self) -> InstallConfig:
        if not self.disk:
            raise ValueError("No disk selected")
        mode = self.selected_mode()
        config = InstallConfig(
            disk=self.disk,
            mode=mode,
            filesystem=self.selected_filesystem(),
            plan=self.current_plan(),
            encryption_enabled=self._encryption.get_active(),
        )
        if mode == MODE_MANUAL:
            config.root_partition = self._combo_path(self._root_combo)
            config.efi_partition = self._combo_path(self._efi_combo)
            config.swap_partition = self._combo_path(self._swap_combo)
            config.format_root = self._format_root.get_active()
            config.format_efi = self._format_efi.get_active()
        elif mode == MODE_REPLACE and config.plan:
            root = next((p for p in config.plan if p.role == "root"), None)
            efi = next((p for p in config.plan if p.role == "efi"), None)
            swap = next((p for p in config.plan if p.role == "swap"), None)
            config.root_partition = root.path if root else None
            config.efi_partition = efi.path if efi else None
            config.swap_partition = swap.path if swap else None
        return config

    def _populate_manual_combos(self) -> None:
        for combo in (self._root_combo, self._efi_combo, self._swap_combo):
            combo.remove_all()
            combo.append_text("None")
            combo.set_active(0)
        if not self.disk:
            return
        for combo, predicate in (
            (self._root_combo, lambda p: p.fstype.lower() in ("ext4", "btrfs", "xfs", "")),
            (self._efi_combo, lambda p: p.is_efi),
            (self._swap_combo, lambda p: p.is_swap),
        ):
            added = 0
            for part in self.disk.partitions:
                if predicate(part):
                    combo.append_text(part.display_name)
                    added += 1
            if added:
                combo.set_active(1 if combo is self._root_combo else 0)

    def _combo_path(self, combo: Gtk.ComboBoxText) -> Optional[str]:
        text = combo.get_active_text()
        if not text or text == "None":
            return None
        return text.split(" - ", 1)[0]

    def _render_plan(self) -> None:
        for child in list(self._plan_box.get_children()):
            self._plan_box.remove(child)

        mode = self.selected_mode()
        self._manual_box.set_visible(mode == MODE_MANUAL)
        if not self.disk:
            self._error.set_text("Select a disk first.")
            return

        plan = [] if mode == MODE_MANUAL else self.current_plan()
        if mode == MODE_MANUAL:
            self._plan_box.pack_start(self.muted_label("Manual mode will use the selected existing partitions."), False, False, 0)
            self._error.set_text("")
        elif plan:
            for part in plan:
                row = Gtk.Label(label=part.description)
                row.set_halign(Gtk.Align.START)
                row.get_style_context().add_class("installer-body")
                self._plan_box.pack_start(row, False, False, 0)
            self._error.set_text("")
        else:
            self._plan_box.pack_start(self.muted_label(self._empty_plan_message(mode)), False, False, 0)
            self._error.set_text(self._empty_plan_message(mode))
        self._plan_box.show_all()
        self.emit_changed()

    def _empty_plan_message(self, mode: str) -> str:
        if mode == MODE_ALONGSIDE:
            return "No unallocated space large enough was found. Use GParted to shrink an existing OS first."
        if mode == MODE_REPLACE:
            return "No existing ZyntrixOS partition label was found on this disk."
        return "The selected disk is too small for the automatic layout."

    def _on_gparted(self, _btn) -> None:
        if not launch_gparted():
            self._error.set_text("GParted could not be launched.")

    def validate(self) -> tuple[bool, str]:
        if not self.disk:
            return False, "Select a disk first."
        mode = self.selected_mode()
        if mode == MODE_MANUAL:
            if not self._combo_path(self._root_combo):
                return False, "Choose a root partition for manual installation."
            return True, ""
        if not self.current_plan():
            return False, self._empty_plan_message(mode)
        if mode in (MODE_ENTIRE_DISK, MODE_ALONGSIDE):
            root = next((p for p in self.current_plan() if p.role == "root"), None)
            if not root or root.size < 5 * 1024 ** 3:
                return False, "The proposed root partition is too small."
        return True, ""


class UserStep(BaseStep):
    def __init__(self):
        super().__init__("User Setup", "Create the first installed-system account.")
        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(12)

        self.hostname = Gtk.Entry(text="zyntrix-pc")
        self.full_name = Gtk.Entry()
        self.username = Gtk.Entry(text="zyntrix")
        self.password = Gtk.Entry()
        self.password.set_visibility(False)
        self.confirm = Gtk.Entry()
        self.confirm.set_visibility(False)
        self.root_same = Gtk.CheckButton(label="Use the same password for root")
        self.root_same.set_active(True)
        self.root_password = Gtk.Entry()
        self.root_password.set_visibility(False)
        self.root_password.set_sensitive(False)
        self.timezone = Gtk.Entry(text=self._default_timezone())
        self.locale = Gtk.Entry(text="en_US.UTF-8")
        self.keyboard = Gtk.Entry(text="us")
        self.strength = Gtk.LevelBar()
        self.strength.set_min_value(0)
        self.strength.set_max_value(4)

        fields = [
            ("Hostname", self.hostname),
            ("Full name", self.full_name),
            ("Username", self.username),
            ("Password", self.password),
            ("Confirm", self.confirm),
            ("Password strength", self.strength),
            ("Timezone", self.timezone),
            ("Locale", self.locale),
            ("Keyboard", self.keyboard),
        ]
        for row, (label, widget) in enumerate(fields):
            lbl = Gtk.Label(label=label)
            lbl.set_halign(Gtk.Align.START)
            grid.attach(lbl, 0, row, 1, 1)
            widget.set_hexpand(True)
            grid.attach(widget, 1, row, 1, 1)

        grid.attach(self.root_same, 1, len(fields), 1, 1)
        root_lbl = Gtk.Label(label="Root password")
        root_lbl.set_halign(Gtk.Align.START)
        grid.attach(root_lbl, 0, len(fields) + 1, 1, 1)
        grid.attach(self.root_password, 1, len(fields) + 1, 1, 1)
        self.pack_start(grid, False, False, 0)

        self._error = self.error_label()
        self.pack_start(self._error, False, False, 0)

        for entry in (
            self.hostname, self.full_name, self.username, self.password,
            self.confirm, self.root_password, self.timezone, self.locale,
            self.keyboard,
        ):
            entry.connect("changed", self._on_changed)
        self.root_same.connect("toggled", self._on_root_same)

    def apply_to_config(self, config: InstallConfig) -> InstallConfig:
        config.hostname = self.hostname.get_text().strip() or "zyntrix-pc"
        config.full_name = self.full_name.get_text().strip()
        config.username = self.username.get_text().strip()
        config.password = self.password.get_text()
        config.same_password_for_root = self.root_same.get_active()
        config.root_password = self.root_password.get_text()
        config.timezone = self.timezone.get_text().strip() or "UTC"
        config.locale = self.locale.get_text().strip() or "en_US.UTF-8"
        config.keyboard = self.keyboard.get_text().strip() or "us"
        return config

    def _on_changed(self, _entry) -> None:
        self.strength.set_value(password_score(self.password.get_text()))
        self.emit_changed()

    def _on_root_same(self, button) -> None:
        self.root_password.set_sensitive(not button.get_active())
        self.emit_changed()

    def validate(self) -> tuple[bool, str]:
        hostname = self.hostname.get_text().strip()
        username = self.username.get_text().strip()
        password = self.password.get_text()
        confirm = self.confirm.get_text()
        if not hostname_is_valid(hostname):
            return False, "Use a valid hostname: letters, numbers, and hyphens only."
        if not username_is_valid(username):
            return False, "Use a lowercase username beginning with a letter or underscore."
        if len(password) < 6:
            return False, "Password must be at least 6 characters."
        if password != confirm:
            return False, "Passwords do not match."
        if not self.root_same.get_active() and len(self.root_password.get_text()) < 6:
            return False, "Root password must be at least 6 characters."
        return True, ""

    @staticmethod
    def _default_timezone() -> str:
        try:
            if os.path.islink("/etc/localtime"):
                target = os.readlink("/etc/localtime")
                marker = "/usr/share/zoneinfo/"
                if marker in target:
                    return target.split(marker, 1)[1]
        except Exception:
            pass
        return "UTC"


def password_score(password: str) -> int:
    score = 0
    if len(password) >= 6:
        score += 1
    if len(password) >= 10:
        score += 1
    if re.search(r"[A-Z]", password) and re.search(r"[a-z]", password):
        score += 1
    if re.search(r"\d", password) or re.search(r"[^A-Za-z0-9]", password):
        score += 1
    return score


class ReviewStep(BaseStep):
    def __init__(self):
        super().__init__("Review", "Confirm the installation plan.")
        self._grid = Gtk.Grid()
        self._grid.set_column_spacing(18)
        self._grid.set_row_spacing(8)
        self.pack_start(self._grid, False, False, 0)
        warning = Gtk.Label(label="Selecting Install will write changes to the target disk.")
        warning.set_halign(Gtk.Align.START)
        warning.get_style_context().add_class("installer-warning")
        self.pack_start(warning, False, False, 0)

    def set_config(self, config: InstallConfig) -> None:
        for child in list(self._grid.get_children()):
            self._grid.remove(child)
        rows = [
            ("Disk", config.disk.title),
            ("Mode", display_mode(config.mode)),
            ("Boot", config.boot_mode),
            ("Filesystem", config.filesystem),
            ("Hostname", config.hostname),
            ("User", config.username),
            ("Timezone", config.timezone),
        ]
        row_idx = 0
        for key, value in rows:
            self._add_row(row_idx, key, value)
            row_idx += 1
        for part in config.plan:
            self._add_row(row_idx, f"Partition: {part.role}", part.description)
            row_idx += 1
        self._grid.show_all()

    def _add_row(self, row: int, key: str, value: str) -> None:
        key_lbl = Gtk.Label(label=key)
        key_lbl.set_halign(Gtk.Align.START)
        key_lbl.get_style_context().add_class("installer-muted")
        val_lbl = Gtk.Label(label=value)
        val_lbl.set_halign(Gtk.Align.START)
        val_lbl.set_line_wrap(True)
        val_lbl.get_style_context().add_class("installer-body")
        self._grid.attach(key_lbl, 0, row, 1, 1)
        self._grid.attach(val_lbl, 1, row, 1, 1)


def display_mode(mode: str) -> str:
    return {
        MODE_ENTIRE_DISK: "Use entire disk",
        MODE_ALONGSIDE: "Install alongside existing OS",
        MODE_REPLACE: "Replace existing ZyntrixOS",
        MODE_MANUAL: "Manual partitions",
    }.get(mode, mode)


class ProgressStep(BaseStep):
    def __init__(self):
        super().__init__("Installing", "ZyntrixOS is being copied and configured.")
        self.progress = Gtk.ProgressBar()
        self.progress.set_show_text(True)
        self.progress.get_style_context().add_class("installer-progress")
        self.pack_start(self.progress, False, False, 0)

        self.status = Gtk.Label(label="Waiting to start")
        self.status.set_halign(Gtk.Align.START)
        self.status.get_style_context().add_class("installer-body")
        self.pack_start(self.status, False, False, 0)

        self.eta = Gtk.Label(label="")
        self.eta.set_halign(Gtk.Align.START)
        self.eta.get_style_context().add_class("installer-muted")
        self.pack_start(self.eta, False, False, 0)

        expander = Gtk.Expander(label="Installation log")
        log_scroll = Gtk.ScrolledWindow()
        log_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        log_scroll.set_min_content_height(260)
        self.log_view = Gtk.TextView()
        self.log_view.set_editable(False)
        self.log_view.set_cursor_visible(False)
        self.log_view.set_monospace(True)
        self.log_view.get_style_context().add_class("installer-log")
        self.log_buffer = self.log_view.get_buffer()
        log_scroll.add(self.log_view)
        expander.add(log_scroll)
        self.pack_start(expander, True, True, 0)

        self.cancel_button = Gtk.Button(label="Cancel")
        self.cancel_button.get_style_context().add_class("destructive-action")
        self.pack_start(self.cancel_button, False, False, 0)

    def set_progress(self, fraction: float, message: str, phase: str) -> None:
        self.progress.set_fraction(fraction)
        self.progress.set_text(f"{int(fraction * 100)}%")
        self.status.set_text(message)
        if phase == "copy":
            self.eta.set_text("Copy speed depends on USB and disk performance.")
        elif fraction >= 1.0:
            self.eta.set_text("Done.")
        else:
            self.eta.set_text("")

    def append_log(self, line: str) -> None:
        end = self.log_buffer.get_end_iter()
        self.log_buffer.insert(end, line + "\n")
        mark = self.log_buffer.create_mark(None, self.log_buffer.get_end_iter(), False)
        self.log_view.scroll_to_mark(mark, 0.0, True, 0.0, 1.0)


class CompleteStep(BaseStep):
    def __init__(self):
        super().__init__("Complete", "Installation finished.")
        self.icon = Gtk.Image.new_from_icon_name("emblem-ok-symbolic", Gtk.IconSize.DIALOG)
        self.pack_start(self.icon, False, False, 0)
        self.title_label = Gtk.Label(label="ZyntrixOS is installed")
        self.title_label.get_style_context().add_class("installer-hero-title")
        self.pack_start(self.title_label, False, False, 0)
        self.body = self.muted_label("")
        self.pack_start(self.body, False, False, 0)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.reboot_button = Gtk.Button(label="Reboot Now")
        self.continue_button = Gtk.Button(label="Continue Using Live")
        actions.pack_start(self.reboot_button, False, False, 0)
        actions.pack_start(self.continue_button, False, False, 0)
        self.pack_start(actions, False, False, 0)

    def set_result(self, success: bool, message: str) -> None:
        if success:
            self.icon.set_from_icon_name("emblem-ok-symbolic", Gtk.IconSize.DIALOG)
            self.title_label.set_text("ZyntrixOS is installed")
            self.body.set_text("Remove the USB drive when the system restarts.")
            self.reboot_button.set_sensitive(True)
        else:
            self.icon.set_from_icon_name("dialog-error-symbolic", Gtk.IconSize.DIALOG)
            self.title_label.set_text("Installation did not complete")
            self.body.set_text(message or "Check the installation log for details.")
            self.reboot_button.set_sensitive(False)


def reboot_now() -> None:
    for cmd in (["systemctl", "reboot"], ["reboot"]):
        try:
            subprocess.Popen(cmd, start_new_session=True)
            return
        except Exception:
            continue
