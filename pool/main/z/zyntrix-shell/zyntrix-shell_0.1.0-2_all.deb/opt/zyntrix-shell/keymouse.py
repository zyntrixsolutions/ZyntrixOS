#!/usr/bin/env python3
"""
ZyntrixOS Keyboard Mouse Daemon  (keymouse.py)

System-wide keyboard-to-mouse bridge via X11 key grabs and xdotool.

Bindings (all global — work regardless of focused window):
  Shift + ←/↑/→/↓         Move cursor        (accelerates when held)
  Shift + Alt              Left click
  Shift + Enter            Right click
  Ctrl  + Alt + ←/↑/→/↓  Drag               (presses LMB, moves, releases LMB on key-up)
  Shift + −                Scroll down        (repeats while held)
  Shift + = / +            Scroll up          (repeats while held)

Start:  python3 keymouse.py &
Stop:   kill $(cat /tmp/keymouse.pid)  or  pkill -f keymouse.py
"""

import os
import signal
import subprocess
import sys
import threading
import time
import logging

logging.basicConfig(
    format="[keymouse] %(levelname)s %(message)s",
    level=logging.INFO,
    stream=sys.stderr,
)
_log = logging.getLogger("keymouse")

try:
    from Xlib import X, display, XK
except ImportError:
    sys.exit(
        "[keymouse] python3-xlib is required.\n"
        "  Install: sudo apt install python3-xlib"
    )

try:
    from Xlib.ext import xtest
except Exception:  # pragma: no cover - depends on X server extension support
    xtest = None

# ── Tuning ────────────────────────────────────────────────────────────────────
BASE_STEP     = 5      # pixels per tick at startup speed
FAST_STEP     = 32     # pixels per tick after ACCEL_DELAY
ACCEL_DELAY   = 0.28   # seconds before fast mode kicks in
TICK_S        = 0.020  # movement loop cadence  (50 Hz)
SCROLL_FIRST  = 0.06   # delay before first scroll repeat
SCROLL_REPEAT = 0.08   # interval between subsequent scroll repeats

SHIFT = X.ShiftMask
CTRL  = X.ControlMask
ALT   = X.Mod1Mask
ACTIVE_MASK = SHIFT | CTRL | ALT

# Lock-key variants to grab (CapsLock + NumLock combinations)
_LOCK_EXTRAS = (0, X.LockMask, X.Mod2Mask, X.LockMask | X.Mod2Mask)

PID_FILE = "/tmp/keymouse.pid"


def _read_ram_kb() -> int:
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1])
    except Exception:
        pass
    return 4 * 1024 * 1024


_RAM_KB = _read_ram_kb()
_LOW_END = (
    os.environ.get("ZYNTRIX_ULTRALOW", "").lower() in ("1", "true", "yes")
    or _RAM_KB <= 3 * 1024 * 1024
)
if _LOW_END:
    TICK_S = 0.033
    SCROLL_REPEAT = 0.11


# ── Pointer helpers ───────────────────────────────────────────────────────────
def _xdo(*args, timeout: float = 0.35) -> None:
    """Fallback xdotool call with a hard timeout.

    Before this optimization, held movement spawned xdotool at 50 Hz.  On a
    Pentium-class CPU that alone can saturate a core.  The normal path below
    uses XTest/XWarpPointer directly and only falls back here if the X server
    does not expose XTest.
    """
    try:
        subprocess.run(
            ["xdotool"] + [str(a) for a in args],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            check=False,
        )
    except Exception:
        pass


class _PointerDriver:
    """Direct X11 pointer driver with xdotool fallback.

    A separate Display connection keeps pointer writes out of the blocking
    key-grab connection used by the main event loop.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._dpy = None
        self._root = None
        self._screen = None
        self._xtest_ok = False
        self._fallback_dx = 0
        self._fallback_dy = 0
        self._fallback_due = 0.0
        self._fallback_interval = 0.05 if _LOW_END else 0.035
        try:
            self._dpy = display.Display()
            self._screen = self._dpy.screen()
            self._root = self._screen.root
            self._xtest_ok = xtest is not None and bool(self._dpy.query_extension("XTEST"))
        except Exception as exc:
            self._dpy = None
            self._root = None
            self._screen = None
            self._xtest_ok = False
            _log.warning("XTest pointer path unavailable, using xdotool: %s", exc)

    def move_relative(self, dx: int, dy: int) -> None:
        if not dx and not dy:
            return
        if not self._dpy or not self._root or not self._screen:
            self._fallback_move(dx, dy)
            return
        try:
            with self._lock:
                ptr = self._root.query_pointer()
                x = max(0, min(self._screen.width_in_pixels - 1, ptr.root_x + dx))
                y = max(0, min(self._screen.height_in_pixels - 1, ptr.root_y + dy))
                self._root.warp_pointer(x, y)
                self._dpy.flush()
        except Exception:
            self._fallback_move(dx, dy)

    def _fallback_move(self, dx: int, dy: int) -> None:
        if not dx and not dy:
            return
        with self._lock:
            self._fallback_dx += dx
            self._fallback_dy += dy
            now = time.monotonic()
            if now < self._fallback_due:
                return
            send_dx = self._fallback_dx
            send_dy = self._fallback_dy
            self._fallback_dx = 0
            self._fallback_dy = 0
            self._fallback_due = now + self._fallback_interval
        _xdo("mousemove_relative", "--", str(send_dx), str(send_dy))

    def click(self, button: int) -> None:
        if self._xtest_ok:
            self.button_down(button)
            self.button_up(button)
        else:
            _xdo("click", str(button))

    def button_down(self, button: int) -> None:
        if not self._xtest_ok:
            _xdo("mousedown", str(button))
            return
        try:
            with self._lock:
                xtest.fake_input(self._dpy, X.ButtonPress, int(button))
                self._dpy.flush()
        except Exception:
            _xdo("mousedown", str(button))

    def button_up(self, button: int) -> None:
        if not self._xtest_ok:
            _xdo("mouseup", str(button))
            return
        try:
            with self._lock:
                xtest.fake_input(self._dpy, X.ButtonRelease, int(button))
                self._dpy.flush()
        except Exception:
            _xdo("mouseup", str(button))


# ── Hold-key state machine ────────────────────────────────────────────────────
class HoldState:
    """
    Tracks currently held keys and drives the background movement/scroll loop.

    Entry format (list so it's mutable in-place):
      [dx, dy, scroll_btn, is_drag, press_time, last_scroll_fire]
    """

    def __init__(self):
        self._held: dict = {}
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)
        self._running = False
        self._drag_active = False
        self._pointer = _PointerDriver()
        # One daemon worker waits on a condition variable when idle.  Before:
        # new 50 Hz loops were spun up for each hold burst.  After: zero wakeups
        # while no keys are held, and no per-frame subprocesses on XTest hosts.
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="keymouse-hold"
        )
        self._thread.start()

    def press(self, kc: int, *, dx: int = 0, dy: int = 0,
              scroll: int = 0, drag: bool = False) -> None:
        start_drag = False
        with self._lock:
            if kc in self._held:
                return  # ignore X11 auto-repeat events
            self._held[kc] = [dx, dy, scroll, drag, time.monotonic(), 0.0]
            if drag and not self._drag_active:
                self._drag_active = True
                start_drag = True
            if not self._running:
                self._running = True
            self._cond.notify()

        if start_drag:
            self._pointer.button_down(1)
        if scroll:
            self._pointer.click(scroll)  # fire immediately on first press

    def release(self, kc: int) -> None:
        end_drag = False
        with self._lock:
            entry = self._held.pop(kc, None)
            if entry and entry[3]:  # was a drag key
                end_drag = not any(e[3] for e in self._held.values())
                if end_drag:
                    self._drag_active = False
            self._cond.notify()
        if end_drag:
            self._pointer.button_up(1)

    def release_all(self) -> None:
        with self._lock:
            had_drag = self._drag_active
            self._held.clear()
            self._drag_active = False
            self._cond.notify()
        if had_drag:
            self._pointer.button_up(1)

    def _loop(self) -> None:
        while True:
            with self._lock:
                while not self._held:
                    self._running = False
                    self._cond.wait()
                self._running = True
                snap = list(self._held.items())

            now = time.monotonic()
            tdx = tdy = 0
            for kc, entry in snap:
                dx, dy, scroll, _, t0, last_fire = entry
                elapsed = now - t0

                if scroll:
                    due = (
                        (last_fire == 0.0 and elapsed > SCROLL_FIRST)
                        or (last_fire > 0.0 and (now - last_fire) > SCROLL_REPEAT)
                    )
                    if due:
                        self._pointer.click(scroll)
                        with self._lock:
                            if kc in self._held:
                                self._held[kc][5] = now
                else:
                    step = FAST_STEP if elapsed > ACCEL_DELAY else BASE_STEP
                    tdx += dx * step
                    tdy += dy * step

            if tdx or tdy:
                self._pointer.move_relative(tdx, tdy)

            with self._lock:
                self._cond.wait(timeout=TICK_S)


# ── X11 setup ─────────────────────────────────────────────────────────────────
def _safe_kc(dpy, sym: str):
    """Return keycode for keysym name, or None if unavailable."""
    kc = dpy.keysym_to_keycode(XK.string_to_keysym(sym))
    return kc if kc else None


def _grab(root, kc: int, modmask: int) -> None:
    """Grab keycode + modifiers across all lock-key variants."""
    for extra in _LOCK_EXTRAS:
        root.grab_key(kc, modmask | extra, True,
                      X.GrabModeAsync, X.GrabModeAsync)


def _ungrab_all(root) -> None:
    """Release all grabs held by this client."""
    root.ungrab_key(0, X.AnyModifier)  # 0 == AnyKey


def _install_grabs(dpy, root) -> dict:
    """(Re-)install all key grabs. Returns keycode map."""
    _ungrab_all(root)

    kc_left  = _safe_kc(dpy, "Left")
    kc_right = _safe_kc(dpy, "Right")
    kc_up    = _safe_kc(dpy, "Up")
    kc_down  = _safe_kc(dpy, "Down")
    kc_alt_l = _safe_kc(dpy, "Alt_L")
    kc_alt_r = _safe_kc(dpy, "Alt_R")
    kc_ret   = _safe_kc(dpy, "Return")
    kc_minus = _safe_kc(dpy, "minus")
    kc_equal = _safe_kc(dpy, "equal")  # =/ + key (Shift+= produces +)

    arrow_dirs: dict = {}
    for kc, d in (
        (kc_left,  (-1,  0)),
        (kc_right, ( 1,  0)),
        (kc_up,    ( 0, -1)),
        (kc_down,  ( 0,  1)),
    ):
        if kc:
            arrow_dirs[kc] = d

    for kc in arrow_dirs:
        _grab(root, kc, SHIFT)
        _grab(root, kc, CTRL | ALT)

    for kc in filter(None, (kc_alt_l, kc_alt_r, kc_ret, kc_minus, kc_equal)):
        _grab(root, kc, SHIFT)

    return {
        "arrow_dirs": arrow_dirs,
        "alt_l":  kc_alt_l,
        "alt_r":  kc_alt_r,
        "return": kc_ret,
        "minus":  kc_minus,
        "equal":  kc_equal,
    }


# ── Main ─────────────────────────────────────────────────────────────────────
def main() -> None:
    try:
        dpy = display.Display()
    except Exception as exc:
        sys.exit(f"[keymouse] Cannot open X display: {exc}")

    root = dpy.screen().root
    hold = HoldState()
    keys = _install_grabs(dpy, root)
    root.change_attributes(event_mask=X.KeyPressMask | X.KeyReleaseMask)
    dpy.sync()

    # Write PID file
    try:
        with open(PID_FILE, "w") as _pf:
            _pf.write(str(os.getpid()))
    except OSError:
        pass

    _log.info(
        "ready — Shift+Arrow=move | Shift+Alt=LClick | Shift+Enter=RClick | "
        "Ctrl+Alt+Arrow=drag | Shift-=scroll↓ | Shift==scroll↑"
    )

    def _shutdown(sig, frame):
        hold.release_all()
        try:
            os.unlink(PID_FILE)
        except OSError:
            pass
        _log.info("stopped")
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    while True:
        try:
            ev = dpy.next_event()
        except Exception:
            break

        # Keyboard layout changed — re-grab
        if ev.type == X.MappingNotify:
            try:
                dpy.refresh_keyboard_mapping(ev)
                keys = _install_grabs(dpy, root)
                dpy.sync()
            except Exception:
                pass
            continue

        if ev.type not in (X.KeyPress, X.KeyRelease):
            continue

        kcode = ev.detail
        mods  = ev.state & ACTIVE_MASK

        if ev.type == X.KeyPress:
            arrow_dirs = keys["arrow_dirs"]

            # ── Shift + Arrow  →  move cursor ─────────────────────────────
            if mods == SHIFT and kcode in arrow_dirs:
                dx, dy = arrow_dirs[kcode]
                hold.press(kcode, dx=dx, dy=dy)

            # ── Shift + Alt  →  left click ─────────────────────────────────
            elif mods == SHIFT and kcode in (keys["alt_l"], keys["alt_r"]):
                _xdo("click", "1")

            # ── Shift + Enter  →  right click ──────────────────────────────
            elif mods == SHIFT and kcode == keys["return"]:
                _xdo("click", "3")

            # ── Ctrl + Alt + Arrow  →  drag ────────────────────────────────
            elif mods == (CTRL | ALT) and kcode in arrow_dirs:
                dx, dy = arrow_dirs[kcode]
                hold.press(kcode, dx=dx, dy=dy, drag=True)

            # ── Shift + −  →  scroll down ──────────────────────────────────
            elif mods == SHIFT and kcode == keys["minus"]:
                hold.press(kcode, scroll=5)

            # ── Shift + = (+)  →  scroll up ────────────────────────────────
            elif mods == SHIFT and kcode == keys["equal"]:
                hold.press(kcode, scroll=4)

        elif ev.type == X.KeyRelease:
            hold.release(kcode)


if __name__ == "__main__":
    main()
