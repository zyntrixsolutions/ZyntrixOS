"""
Subprocess launcher for ZyntrixOS shell.
Spawns tiles, watches for child exit, and calls back to re-show the shell.

launch() tries the tile's primary command then each fallback in order,
returning True if a process was started or False if nothing resolved.
The caller should only iconify the shell when launch() returns True.
"""

from gi.repository import GLib

import os
import subprocess
import threading
import time
import logging
from typing import Callable, Optional

_FAST_FAIL_GRACE_S = 0.3   # seconds to wait before declaring a launch healthy

log = logging.getLogger(__name__)


class Launcher:
    def __init__(
        self,
        on_child_exit: Callable[[], None],
        on_launch_error: Optional[Callable[[str, list], None]] = None,
        on_launched: Optional[Callable[[], None]] = None,
    ):
        """
        on_child_exit  — called on GTK main thread when any child exits.
        on_launch_error— called on GTK main thread when no command resolves.
        on_launched    — called on GTK main thread when a healthy process starts.
        """
        self._on_child_exit = on_child_exit
        self._on_launch_error = on_launch_error
        self._on_launched = on_launched
        self._children: dict[int, subprocess.Popen] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    def launch(self, command: list[str], fallbacks: list = None) -> None:
        """Non-blocking. Tries command + fallbacks in a background thread.
        Calls on_launched() when a healthy process starts, or on_launch_error()
        if nothing works.
        """
        if not command:
            self._schedule_error(command[0] if command else "?", [])
            return
        threading.Thread(
            target=self._launch_bg,
            args=(command, fallbacks or []),
            daemon=True,
            name="launch-bg",
        ).start()

    def _launch_bg(self, command: list[str], fallbacks: list) -> None:
        """Background thread: probe candidates with fast-fail check."""
        candidates = [command] + fallbacks
        tried = []
        for candidate in candidates:
            if not candidate:
                continue
            exe = candidate[0]
            if self._resolve(exe) is None:
                continue
            tried.append(exe)
            proc = self._spawn(candidate)
            if proc is None:
                continue
            # Grace-period: if the app crashes immediately (e.g. foot on X11)
            # its exit code will be non-zero within the grace window.
            time.sleep(_FAST_FAIL_GRACE_S)
            if proc.poll() is not None and proc.returncode != 0:
                log.warning(
                    "Fast-fail pid=%d code=%d cmd=%s — trying next fallback",
                    proc.pid, proc.returncode, candidate,
                )
                with self._lock:
                    self._children.pop(proc.pid, None)
                continue
            log.info("Launched pid=%d  cmd=%s", proc.pid, candidate)
            self._schedule_launched()
            return

        log.warning("No working command for %s (tried %s)", command[0], tried)
        self._schedule_error(command[0], tried)

    def _schedule_launched(self) -> None:
        try:
            GLib.idle_add(self._fire_launched)
        except Exception:
            pass

    def _fire_launched(self) -> bool:
        if self._on_launched:
            self._on_launched()
        return False

    def _schedule_error(self, exe: str, tried: list) -> None:
        try:
            GLib.idle_add(self._fire_error, exe, tried)
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _fire_error(self, exe: str, tried: list) -> bool:
        if self._on_launch_error:
            self._on_launch_error(exe, tried)
        else:
            self._show_not_found_dialog(exe, tried)
        return False  # GLib.idle_add: don't repeat

    # ------------------------------------------------------------------
    def _spawn(self, command: list[str]) -> Optional[subprocess.Popen]:
        try:
            proc = subprocess.Popen(
                command,
                env=os.environ.copy(),
                start_new_session=True,
            )
        except Exception as exc:
            log.error("Popen failed for %s: %s", command, exc)
            return None

        with self._lock:
            self._children[proc.pid] = proc

        threading.Thread(
            target=self._watch,
            args=(proc,),
            daemon=True,
            name=f"watcher-{proc.pid}",
        ).start()
        return proc

    # ------------------------------------------------------------------
    def _watch(self, proc: subprocess.Popen) -> None:
        proc.wait()
        log.info("Child pid=%d exited code=%s", proc.pid, proc.returncode)
        with self._lock:
            # Already removed by fast-fail path — skip callback
            if proc.pid not in self._children:
                return
            self._children.pop(proc.pid, None)
        try:
            GLib.idle_add(self._on_child_exit)
        except Exception:
            pass

    # ------------------------------------------------------------------
    @staticmethod
    def _resolve(exe: str) -> Optional[str]:
        """Return full path if exe is executable, else None."""
        if os.path.isabs(exe):
            return exe if os.path.isfile(exe) else None
        for directory in os.environ.get("PATH", "").split(os.pathsep):
            full = os.path.join(directory, exe)
            if os.access(full, os.X_OK):
                return full
        return None

    # ------------------------------------------------------------------
    @staticmethod
    def _show_not_found_dialog(exe: str, tried: list) -> None:
        tried_str = ", ".join(tried[:5])
        try:
            from gi.repository import Gtk
            dialog = Gtk.MessageDialog(
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.CLOSE,
                text=f"Application not found: {exe}",
                secondary_text=(
                    f"Tried: {tried_str}\n\n"
                    "Install the application or edit\n"
                    "~/.config/zyntrix/config.toml to change the command."
                ),
            )
            dialog.run()
            dialog.destroy()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def terminate_all(self) -> None:
        with self._lock:
            children = list(self._children.values())
        for proc in children:
            try:
                proc.terminate()
            except ProcessLookupError:
                pass
