#!/usr/bin/env python3
"""
ZyntrixOS App Loading Screen.

Fullscreen immersive overlay inspired by Xbox / PlayStation console boot
experiences. Shows while an app warms up, dismissed automatically once
the child process is confirmed healthy.

Visual layers (bottom → top):
  1. Blurred vignette background (solid + radial gradient via Cairo)
  2. Ambient floating particles (Cairo animation, 60 fps)
  3. Arc progress ring (Cairo, fills from 0 → 100 %)
  4. App icon centred in the ring
  5. App name headline + loading sub-text
  6. Thin bottom hint bar

No external dependencies beyond PyGObject + cairo (already present).
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf

import cairo
import math
import os
import random
import time


# ── Tuning constants ─────────────────────────────────────────────────────────
_FPS            = 60
_FRAME_MS       = 1000 // _FPS
_RING_RADIUS    = 90          # px, outer radius of progress ring
_RING_THICK     = 6           # px, stroke width
_ICON_SIZE      = 96          # px, icon inside ring
_PARTICLE_COUNT = 48
_PARTICLE_SPEED = 0.18        # normalised to screen height per second
_MESSAGES       = [
    "LOADING",
    "PREPARING",
    "INITIALISING",
    "STARTING UP",
    "GETTING READY",
]


def _hex_to_rgb(h: str) -> tuple:
    h = h.lstrip("#")
    return tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4))


# ─────────────────────────────────────────────────────────────────────────────
class _Particle:
    """One ambient floating dot."""
    def __init__(self, sw: int, sh: int):
        self.sw, self.sh = sw, sh
        self._reset(initial=True)

    def _reset(self, initial: bool = False):
        self.x = random.random()
        self.y = random.random() if initial else 1.0 + random.random() * 0.1
        self.r = random.uniform(1.0, 3.5)
        self.speed = random.uniform(0.3, 1.0) * _PARTICLE_SPEED
        self.alpha = random.uniform(0.05, 0.25)
        self.drift = random.uniform(-0.06, 0.06)  # horizontal drift

    def step(self, dt: float):
        self.y -= self.speed * dt
        self.x += self.drift * dt * 0.08
        if self.y < -0.05:
            self._reset()

    def draw(self, cr, accent_rgb: tuple):
        cr.set_source_rgba(*accent_rgb, self.alpha)
        cr.arc(self.x * self.sw, self.y * self.sh, self.r, 0, 2 * math.pi)
        cr.fill()


# ─────────────────────────────────────────────────────────────────────────────
class _DrawArea(Gtk.DrawingArea):
    """Cairo canvas — draws everything: bg, particles, ring, icon, text."""

    def __init__(
        self,
        app_name: str,
        app_icon: str,
        accent: str,
        bg: str,
        fps: int = 60,
    ):
        super().__init__()
        self._app_name   = app_name.upper()
        self._accent_rgb = _hex_to_rgb(accent) if accent.startswith("#") else (0.0, 0.8, 0.6)
        self._bg_rgb     = _hex_to_rgb(bg)     if bg.startswith("#")     else (0.05, 0.05, 0.08)

        self._progress   = 0.0    # 0.0 … 1.0
        self._angle_off  = 0.0    # degrees; ring rotates slowly
        self._msg_idx    = 0
        self._msg_timer  = 0.0

        self._icon_pb    = self._load_icon(app_icon)
        self._particles  = []
        self._fps        = fps
        # Before: "low" still meant a 30 fps Cairo loop plus 16 particles.
        # After: fps<=30 is a static indicator with no GLib frame timer, which
        # avoids burning CPU/GPU while an app is starting on 2 GB systems.
        self._static_low = fps <= 30

        # Vignette gradient cache — recreated only when screen geometry changes
        self._vig_grad   = None
        self._vig_key: tuple = ()

        self._last_t     = time.monotonic()
        self._start_t    = self._last_t

        # Initialise particles once we know screen size
        self.connect("realize", self._on_realize)
        self.connect("draw", self._on_draw)

    # ------------------------------------------------------------------
    def _on_realize(self, _w):
        alloc = self.get_allocation()
        sw, sh = alloc.width or 1920, alloc.height or 1080
        if self._static_low:
            self._particles = []
            return
        # Scale particle count by tier (fps proxy): mid=45fps→28, high=60fps→48.
        n = {45: 28}.get(self._fps, _PARTICLE_COUNT)
        self._particles = [_Particle(sw, sh) for _ in range(n)]

    @staticmethod
    def _load_icon(path: str):
        if not path:
            return None
        try:
            return GdkPixbuf.Pixbuf.new_from_file_at_scale(path, _ICON_SIZE, _ICON_SIZE, True)
        except Exception:
            return None

    # ------------------------------------------------------------------
    def tick(self) -> bool:
        """Called every frame from GLib.timeout_add. Drives animation."""
        if self._static_low:
            self._progress = max(self._progress, 0.72)
            self.queue_draw()
            return False

        now = time.monotonic()
        dt  = now - self._last_t
        self._last_t = now
        elapsed = now - self._start_t

        # Progress: fast ramp to 80 % in first 2 s, then slow to 95 %
        if elapsed < 2.0:
            target = 0.80 * (elapsed / 2.0)
        else:
            target = 0.80 + 0.15 * min(1.0, (elapsed - 2.0) / 6.0)
        self._progress = target

        self._angle_off = (elapsed * 18) % 360   # ring rotates 18 °/s

        self._msg_timer += dt
        if self._msg_timer > 1.8:
            self._msg_timer = 0.0
            self._msg_idx = (self._msg_idx + 1) % len(_MESSAGES)

        for p in self._particles:
            p.step(dt)

        self.queue_draw()
        return True  # keep firing

    def complete(self):
        """Called when child app is confirmed ready — fill ring to 100 %."""
        self._progress = 1.0
        self.queue_draw()

    # ------------------------------------------------------------------
    def _on_draw(self, _w, cr):
        alloc = self.get_allocation()
        sw, sh = alloc.width, alloc.height
        cx, cy = sw / 2, sh / 2

        # ── 1. Background gradient ────────────────────────────────────
        cr.set_source_rgb(*self._bg_rgb)
        cr.paint()

        # Subtle radial vignette — cache gradient; recreate only on geometry change
        _r0, _r1 = min(sw, sh) * 0.55, min(sw, sh) * 0.9
        _vk = (cx, cy, _r0, _r1)
        if self._vig_key != _vk:
            self._vig_key = _vk
            self._vig_grad = _radial_gradient(
                cx, cy, _r0, _r1, self._bg_rgb, 0.0, self._bg_rgb, 0.45
            )
        cr.set_source(self._vig_grad)
        cr.paint()

        # ── 2. Particles ──────────────────────────────────────────────
        for p in self._particles:
            p.draw(cr, self._accent_rgb)

        # ── 3. Ring track (dim) ───────────────────────────────────────
        ar, ag, ab = self._accent_rgb
        cr.set_line_width(_RING_THICK)
        cr.set_source_rgba(ar, ag, ab, 0.12)
        cr.arc(cx, cy, _RING_RADIUS, 0, 2 * math.pi)
        cr.stroke()

        # Glow under the filled arc
        cr.set_source_rgba(ar, ag, ab, 0.08)
        cr.set_line_width(_RING_THICK + 10)
        end_angle = -math.pi / 2 + 2 * math.pi * self._progress
        start_rot = -math.pi / 2 if self._static_low else math.radians(self._angle_off - 90)
        cr.arc(cx, cy, _RING_RADIUS, start_rot, start_rot + 2 * math.pi * self._progress)
        cr.stroke()

        # ── 4. Filled arc ─────────────────────────────────────────────
        cr.set_source_rgba(ar, ag, ab, 0.95)
        cr.set_line_width(_RING_THICK)
        cr.arc(cx, cy, _RING_RADIUS, start_rot, start_rot + 2 * math.pi * self._progress)
        cr.stroke()

        # Arc endpoint dot
        if self._progress > 0.02:
            dot_angle = start_rot + 2 * math.pi * self._progress
            dx = cx + _RING_RADIUS * math.cos(dot_angle)
            dy = cy + _RING_RADIUS * math.sin(dot_angle)
            cr.set_source_rgba(ar, ag, ab, 1.0)
            cr.arc(dx, dy, _RING_THICK * 0.9, 0, 2 * math.pi)
            cr.fill()

        # ── 5. Icon ───────────────────────────────────────────────────
        if self._icon_pb:
            Gdk.cairo_set_source_pixbuf(
                cr, self._icon_pb,
                cx - _ICON_SIZE / 2,
                cy - _ICON_SIZE / 2,
            )
            cr.rectangle(cx - _ICON_SIZE / 2, cy - _ICON_SIZE / 2, _ICON_SIZE, _ICON_SIZE)
            cr.fill()
        else:
            # Fallback: accent initial letter
            cr.set_source_rgba(ar, ag, ab, 0.8)
            cr.select_font_face("Sans", 0, 1)
            cr.set_font_size(56)
            letter = self._app_name[:1]
            te = cr.text_extents(letter)
            cr.move_to(cx - te.width / 2 - te.x_bearing,
                       cy - te.height / 2 - te.y_bearing)
            cr.show_text(letter)

        # ── 6. App name ───────────────────────────────────────────────
        cr.set_source_rgba(1, 1, 1, 0.95)
        cr.select_font_face("Sans", 0, 1)
        cr.set_font_size(22)
        te = cr.text_extents(self._app_name)
        cr.move_to(cx - te.width / 2 - te.x_bearing,
                   cy + _RING_RADIUS + 42)
        cr.show_text(self._app_name)

        # ── 7. Sub-message (cycling) ──────────────────────────────────
        msg = _MESSAGES[self._msg_idx]
        cr.set_source_rgba(ar, ag, ab, 0.65)
        cr.select_font_face("Sans", 0, 0)
        cr.set_font_size(11)
        te2 = cr.text_extents(msg)
        cr.move_to(cx - te2.width / 2 - te2.x_bearing,
                   cy + _RING_RADIUS + 68)
        cr.show_text(msg)

        # ── 8. Bottom hint ────────────────────────────────────────────
        hint = "ESC  cancel"
        cr.set_source_rgba(1, 1, 1, 0.18)
        cr.select_font_face("Monospace", 0, 0)
        cr.set_font_size(10)
        te3 = cr.text_extents(hint)
        cr.move_to(cx - te3.width / 2 - te3.x_bearing, sh - 28)
        cr.show_text(hint)


def _radial_gradient(cx, cy, r0, r1, rgb0, a0, rgb1, a1):
    pat = cairo.RadialGradient(cx, cy, r0, cx, cy, r1)
    pat.add_color_stop_rgba(0, *rgb0, a0)
    pat.add_color_stop_rgba(1, *rgb1, a1)
    return pat


# ─────────────────────────────────────────────────────────────────────────────
class LoadScreen(Gtk.Window):
    """Fullscreen immersive loading overlay.

    Usage::

        ls = LoadScreen("Firefox", "/path/to/firefox.png", theme, fps=45)
        ls.show()                   # show immediately
        # … later, when app is alive …
        ls.dismiss()                # fills ring to 100 %, fades out
    """

    def __init__(self, app_name: str, app_icon: str, theme: dict, fps: int = 60):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.set_decorated(False)
        self.fullscreen()
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.get_style_context().add_class("load-screen")

        accent = theme.get("accent", "#00e5cc")
        bg     = theme.get("background", "#0d0f18")

        self._canvas = _DrawArea(app_name, app_icon, accent, bg, fps=fps)
        self._canvas.set_hexpand(True)
        self._canvas.set_vexpand(True)
        self.add(self._canvas)

        self._frame_ms  = max(16, 1000 // max(1, fps))
        self._timer_id  = None
        self._dismissed = False

        self.connect("key-press-event", self._on_key)

    # ------------------------------------------------------------------
    def show(self) -> None:
        self.show_all()
        if self._canvas._static_low:
            self._canvas.tick()
        else:
            self._timer_id = GLib.timeout_add(self._frame_ms, self._canvas.tick)

    def dismiss(self) -> None:
        """Fill ring to 100 % then destroy after a short pause."""
        if self._dismissed:
            return
        self._dismissed = True
        self._canvas.complete()
        GLib.timeout_add(520, self._destroy)

    def _destroy(self) -> bool:
        if self._timer_id is not None:
            GLib.source_remove(self._timer_id)
            self._timer_id = None
        self.destroy()
        return False

    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self._destroy()
            return True
        return False
