#!/usr/bin/env python3
"""Shared GTK host for persistent ZyntrixOS overlays.

This consolidates the always-on taskbar and floating window chrome into a
single interpreter and GTK main loop while preserving the standalone entry
points for manual use.
"""

from __future__ import annotations

import argparse
import signal
from typing import List

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import GLib, Gtk

from style import load_shared_css
from taskbar import Taskbar
from window_chrome import WindowChrome
from window_manager import WindowManagerClient
from window_snapshot import WindowSnapshotStore


class OverlayDaemon:
    def __init__(self, *, taskbar: bool, window_chrome: bool) -> None:
        self._client = WindowManagerClient()
        self._client.ensure_daemon()
        self._snapshot_store = WindowSnapshotStore(client=self._client)
        load_shared_css()

        self._windows: List[Gtk.Window] = []
        self._taskbar = (
            Taskbar(client=self._client, load_css=False, snapshot_store=self._snapshot_store)
            if taskbar
            else None
        )
        self._chrome = (
            WindowChrome(client=self._client, load_css=False, snapshot_store=self._snapshot_store)
            if window_chrome
            else None
        )

        if self._taskbar is not None:
            self._windows.append(self._taskbar)
            self._taskbar.connect("destroy", self._on_window_destroy)
            self._taskbar.show_all()

        if self._chrome is not None:
            self._windows.append(self._chrome)
            self._chrome.connect("destroy", self._on_window_destroy)

        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGTERM, self._on_signal)
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, signal.SIGINT, self._on_signal)

    def run(self) -> int:
        if not self._windows:
            self._snapshot_store.close()
            return 0
        Gtk.main()
        self._snapshot_store.close()
        self._client.close()
        return 0

    def _on_signal(self) -> bool:
        for window in list(self._windows):
            try:
                window.destroy()
            except Exception:
                pass
        self._windows.clear()
        self._snapshot_store.close()
        self._client.close()
        Gtk.main_quit()
        return False

    def _on_window_destroy(self, window: Gtk.Window) -> None:
        self._windows = [item for item in self._windows if item is not window]
        if not self._windows:
            self._snapshot_store.close()
            self._client.close()
            Gtk.main_quit()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the persistent ZyntrixOS overlays")
    parser.add_argument("--taskbar", action="store_true", help="run the taskbar overlay")
    parser.add_argument("--window-chrome", action="store_true", help="run the floating window controls overlay")
    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(argv)
    enable_taskbar = bool(args.taskbar)
    enable_window_chrome = bool(args.window_chrome)
    if not enable_taskbar and not enable_window_chrome:
        enable_taskbar = True
        enable_window_chrome = True
    daemon = OverlayDaemon(taskbar=enable_taskbar, window_chrome=enable_window_chrome)
    return daemon.run()


if __name__ == "__main__":
    raise SystemExit(main())
