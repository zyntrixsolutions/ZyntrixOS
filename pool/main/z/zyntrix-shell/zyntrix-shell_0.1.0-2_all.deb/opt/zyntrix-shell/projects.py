#!/usr/bin/env python3
"""
ZyntrixOS Projects Panel.
GTK3 panel for managing developer projects:
  - List recent projects (from ~/.local/share/zyntrix/projects.json)
  - Show stack, status, last opened
  - Open / New / Remove project actions via zyntrix CLI
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Pango

import os
import sys
import json
import shutil
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore

# ── Paths ──────────────────────────────────────────────────────────────────────
SHELL_DIR      = os.path.dirname(os.path.abspath(__file__))
CLI_PATH       = os.path.join(os.path.dirname(SHELL_DIR), "cli", "zyntrix")
FALLBACK_CLI   = shutil.which("zyntrix") or CLI_PATH
DATA_DIR       = Path.home() / ".local" / "share" / "zyntrix"
PROJECTS_JSON  = DATA_DIR / "projects.json"
TEMPLATES_DIR  = Path(os.path.dirname(SHELL_DIR)) / "templates"

TERMINAL_CANDIDATES = ["foot", "alacritty", "kitty", "xfce4-terminal", "xterm"]

WINDOW_W, WINDOW_H = 1100, 680

STACK_ICONS = {
    "node":    "🟢",
    "python":  "🐍",
    "rust":    "🦀",
    "go":      "🔵",
    "ruby":    "💎",
    "unknown": "📁",
}

STATUS_COLORS = {
    "running": "#00f0c8",
    "idle":    "#888899",
    "error":   "#ff2d78",
}


# ── Helpers ────────────────────────────────────────────────────────────────────
def _find_terminal() -> list:
    for t in TERMINAL_CANDIDATES:
        if shutil.which(t):
            if t in ("foot", "alacritty", "kitty"):
                return [t, "--title", "ZyntrixOS", "--"]
            if t in ("xfce4-terminal",):
                return [t, "--title=ZyntrixOS", "--"]
            return [t, "-title", "ZyntrixOS", "-e"]
    return ["xterm", "-title", "ZyntrixOS", "-e"]


def _run_bg(cmd: list) -> None:
    subprocess.Popen(cmd, start_new_session=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _run_cli(*args) -> subprocess.CompletedProcess:
    cli = FALLBACK_CLI if os.path.exists(FALLBACK_CLI) else "zyntrix"
    return subprocess.run(
        ["python3", cli, *args] if cli.endswith("zyntrix") and not shutil.which("zyntrix") else [cli, *args],
        capture_output=True, text=True, timeout=30,
    )


def _load_projects() -> list[dict]:
    try:
        if PROJECTS_JSON.exists():
            data = json.loads(PROJECTS_JSON.read_text())
            return data.get("projects", [])
    except Exception:
        pass
    return []


def _load_templates() -> list[str]:
    if TEMPLATES_DIR.exists():
        return sorted(d.name for d in TEMPLATES_DIR.iterdir()
                      if d.is_dir() and not d.name.startswith("."))
    return []


def _detect_stack_from_path(path: str) -> str:
    p = Path(path)
    if (p / "package.json").exists():
        return "node"
    if (p / "pyproject.toml").exists() or (p / "requirements.txt").exists():
        return "python"
    if (p / "Cargo.toml").exists():
        return "rust"
    if (p / "go.mod").exists():
        return "go"
    if (p / "Gemfile").exists():
        return "ruby"
    return "unknown"


def _rel_time(iso: str) -> str:
    if not iso:
        return "never"
    try:
        dt = datetime.fromisoformat(iso)
        delta = datetime.now() - dt
        s = int(delta.total_seconds())
        if s < 60:
            return "just now"
        if s < 3600:
            return f"{s // 60}m ago"
        if s < 86400:
            return f"{s // 3600}h ago"
        return f"{s // 86400}d ago"
    except Exception:
        return ""


# ── Main window ────────────────────────────────────────────────────────────────
class ProjectsPanel(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS — Projects")
        self.set_default_size(WINDOW_W, WINDOW_H)
        self.set_name("projects-panel")
        self.get_style_context().add_class("projects-panel")

        self._projects: list[dict] = []
        self._selected: Optional[dict] = None

        self._apply_css()
        self._build_ui()
        self.connect("delete-event", Gtk.main_quit)
        self.connect("key-press-event", self._on_key)
        self.show_all()
        self._load_projects()

    # ── CSS ───────────────────────────────────────────────────────────────────
    def _apply_css(self) -> None:
        css = b"""
        .projects-panel {
            background-color: #0a0b0f;
            color: #e8eaf0;
        }
        .panel-header {
            background-color: #12141a;
            border-bottom: 1px solid #1e2030;
            padding: 12px 20px;
        }
        .panel-title {
            font-family: "JetBrains Mono", monospace;
            font-size: 16px;
            font-weight: bold;
            color: #00f0c8;
        }
        .panel-subtitle {
            font-size: 11px;
            color: #888899;
        }
        .search-entry {
            background-color: #1a1c24;
            color: #e8eaf0;
            border: 1px solid #2a2c3a;
            border-radius: 6px;
            padding: 6px 12px;
            font-family: "JetBrains Mono", monospace;
            font-size: 13px;
        }
        .search-entry:focus {
            border-color: #00f0c8;
        }
        .project-list {
            background-color: #0e101a;
        }
        .project-row {
            background-color: transparent;
            padding: 10px 16px;
            border-bottom: 1px solid #1a1c24;
        }
        .project-row:hover {
            background-color: #12141a;
        }
        .project-row:selected {
            background-color: rgba(0, 240, 200, 0.12);
        }
        .project-name {
            font-family: "JetBrains Mono", monospace;
            font-size: 13px;
            font-weight: bold;
            color: #e8eaf0;
        }
        .project-meta {
            font-size: 11px;
            color: #888899;
        }
        .project-stack-badge {
            font-size: 10px;
            background-color: #1a1c24;
            border-radius: 4px;
            padding: 2px 8px;
            color: #888899;
        }
        .detail-pane {
            background-color: #0e101a;
            border-left: 1px solid #1e2030;
            padding: 24px;
        }
        .detail-title {
            font-family: "JetBrains Mono", monospace;
            font-size: 18px;
            font-weight: bold;
            color: #00f0c8;
        }
        .detail-label {
            font-size: 11px;
            color: #888899;
            text-transform: uppercase;
            margin-top: 14px;
        }
        .detail-value {
            font-family: "JetBrains Mono", monospace;
            font-size: 12px;
            color: #c8cadd;
        }
        .task-row {
            background-color: #12141a;
            border-radius: 4px;
            padding: 6px 10px;
            margin: 2px 0;
            font-family: "JetBrains Mono", monospace;
            font-size: 12px;
            color: #888899;
        }
        .task-name {
            color: #00f0c8;
            font-weight: bold;
        }
        .action-btn {
            background-color: #12141a;
            color: #e8eaf0;
            border: 1px solid #2a2c3a;
            border-radius: 6px;
            padding: 8px 16px;
            font-size: 12px;
        }
        .action-btn:hover {
            background-color: #1e2030;
            border-color: #00f0c8;
        }
        .action-btn-primary {
            background-color: rgba(0,240,200,0.15);
            border-color: #00f0c8;
            color: #00f0c8;
            font-weight: bold;
        }
        .action-btn-primary:hover {
            background-color: rgba(0,240,200,0.25);
        }
        .action-btn-danger:hover {
            border-color: #ff2d78;
            color: #ff2d78;
        }
        .status-dot {
            font-size: 10px;
        }
        .template-item {
            background-color: #12141a;
            border: 1px solid #1e2030;
            border-radius: 6px;
            padding: 8px 14px;
            margin: 3px;
        }
        .template-item:hover {
            border-color: #00f0c8;
        }
        .empty-state {
            color: #888899;
            font-size: 14px;
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )

    # ── UI layout ─────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)

        # Header
        root.pack_start(self._build_header(), False, False, 0)

        # Toast bar (hidden until a message is shown)
        self._toast_lbl = Gtk.Label(label="")
        self._toast_lbl.get_style_context().add_class("panel-subtitle")
        self._toast_lbl.set_halign(Gtk.Align.CENTER)
        self._toast_lbl.set_margin_top(4)
        self._toast_lbl.set_margin_bottom(4)
        self._toast_lbl.set_no_show_all(True)
        root.pack_start(self._toast_lbl, False, False, 0)
        self._toast_timer: Optional[int] = None

        # Body (list + detail pane)
        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(body, True, True, 0)

        # Left: project list
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        left.set_size_request(380, -1)
        body.pack_start(left, False, False, 0)

        # Search box
        search_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        search_box.set_margin_start(12)
        search_box.set_margin_end(12)
        search_box.set_margin_top(12)
        search_box.set_margin_bottom(8)
        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("Search projects…")
        self._search.get_style_context().add_class("search-entry")
        self._search.connect("search-changed", self._on_search)
        search_box.pack_start(self._search, True, True, 0)
        left.pack_start(search_box, False, False, 0)

        # Project list
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._list_box = Gtk.ListBox()
        self._list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self._list_box.get_style_context().add_class("project-list")
        self._list_box.connect("row-selected", self._on_row_selected)
        self._list_box.connect("row-activated", self._on_row_activated)
        scroll.add(self._list_box)
        left.pack_start(scroll, True, True, 0)

        # Bottom action buttons
        left.pack_start(self._build_left_actions(), False, False, 0)

        # Right: detail pane
        self._detail_pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self._detail_pane.get_style_context().add_class("detail-pane")
        body.pack_start(self._detail_pane, True, True, 0)

        self._show_empty_state()

    def _build_header(self) -> Gtk.Widget:
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        header.get_style_context().add_class("panel-header")

        title_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label(label="PROJECTS")
        title.get_style_context().add_class("panel-title")
        title.set_halign(Gtk.Align.START)
        sub = Gtk.Label(label="Open, create, and manage your developer projects")
        sub.get_style_context().add_class("panel-subtitle")
        sub.set_halign(Gtk.Align.START)
        title_box.pack_start(title, False, False, 0)
        title_box.pack_start(sub, False, False, 0)
        header.pack_start(title_box, True, True, 0)

        close_btn = Gtk.Button(label="✕")
        close_btn.get_style_context().add_class("action-btn")
        close_btn.connect("clicked", lambda _: Gtk.main_quit())
        header.pack_end(close_btn, False, False, 0)

        return header

    def _build_left_actions(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_start(12)
        box.set_margin_end(12)
        box.set_margin_top(8)
        box.set_margin_bottom(12)

        new_btn = Gtk.Button(label="+ New Project")
        new_btn.get_style_context().add_class("action-btn")
        new_btn.connect("clicked", self._on_new_project)
        box.pack_start(new_btn, True, True, 0)

        refresh_btn = Gtk.Button(label="⟳")
        refresh_btn.get_style_context().add_class("action-btn")
        refresh_btn.set_tooltip_text("Refresh project list")
        refresh_btn.connect("clicked", lambda _: self._load_projects())
        box.pack_start(refresh_btn, False, False, 0)

        return box

    # ── Project list ──────────────────────────────────────────────────────────
    def _load_projects(self) -> None:
        self._projects = _load_projects()
        self._rebuild_list(self._projects)

    def _rebuild_list(self, projects: list[dict]) -> None:
        for child in self._list_box.get_children():
            self._list_box.remove(child)

        if not projects:
            row = Gtk.ListBoxRow()
            lbl = Gtk.Label(label="No projects yet.\nUse '+ New Project' to get started.")
            lbl.get_style_context().add_class("empty-state")
            lbl.set_line_wrap(True)
            lbl.set_justify(Gtk.Justification.CENTER)
            lbl.set_margin_top(40)
            lbl.set_margin_bottom(40)
            row.add(lbl)
            row.set_activatable(False)
            self._list_box.add(row)
        else:
            for proj in projects:
                self._list_box.add(self._make_project_row(proj))

        self._list_box.show_all()

    def _make_project_row(self, proj: dict) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row._project = proj

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.get_style_context().add_class("project-row")
        box.set_margin_start(4)
        box.set_margin_end(4)

        # Stack icon
        stack = proj.get("stack", "unknown")
        icon_lbl = Gtk.Label(label=STACK_ICONS.get(stack, "📁"))
        icon_lbl.set_size_request(28, 28)
        box.pack_start(icon_lbl, False, False, 0)

        # Name + path
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        name_lbl = Gtk.Label(label=proj.get("name", "?"))
        name_lbl.get_style_context().add_class("project-name")
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        info_box.pack_start(name_lbl, False, False, 0)

        path_lbl = Gtk.Label(label=proj.get("path", ""))
        path_lbl.get_style_context().add_class("project-meta")
        path_lbl.set_halign(Gtk.Align.START)
        path_lbl.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        info_box.pack_start(path_lbl, False, False, 0)

        box.pack_start(info_box, True, True, 0)

        # Status + time (right side)
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        right.set_halign(Gtk.Align.END)

        status = proj.get("status", "idle")
        dot_color = STATUS_COLORS.get(status, "#888899")
        status_lbl = Gtk.Label()
        status_lbl.set_markup(f'<span foreground="{dot_color}">●</span>')
        status_lbl.get_style_context().add_class("status-dot")
        right.pack_start(status_lbl, False, False, 0)

        time_lbl = Gtk.Label(label=_rel_time(proj.get("last_opened", "")))
        time_lbl.get_style_context().add_class("project-meta")
        right.pack_start(time_lbl, False, False, 0)

        box.pack_start(right, False, False, 0)

        row.add(box)
        return row

    def _on_search(self, entry: Gtk.SearchEntry) -> None:
        query = entry.get_text().lower()
        filtered = [
            p for p in self._projects
            if query in p.get("name", "").lower() or query in p.get("path", "").lower()
        ] if query else self._projects
        self._rebuild_list(filtered)

    def _on_row_selected(self, _box, row: Gtk.ListBoxRow) -> None:
        if row is None or not hasattr(row, "_project"):
            return
        self._selected = row._project
        self._show_detail(self._selected)

    def _on_row_activated(self, _box, row: Gtk.ListBoxRow) -> None:
        if row is None or not hasattr(row, "_project"):
            return
        self._open_project(row._project)

    # ── Detail pane ───────────────────────────────────────────────────────────
    def _show_empty_state(self) -> None:
        for c in self._detail_pane.get_children():
            self._detail_pane.remove(c)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)

        lbl = Gtk.Label(label="Select a project\nor create a new one")
        lbl.get_style_context().add_class("empty-state")
        lbl.set_justify(Gtk.Justification.CENTER)
        box.pack_start(lbl, False, False, 0)

        self._detail_pane.pack_start(box, True, True, 0)
        self._detail_pane.show_all()

    def _show_detail(self, proj: dict) -> None:
        for c in self._detail_pane.get_children():
            self._detail_pane.remove(c)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.set_margin_start(8)
        box.set_margin_end(8)

        # Title
        stack = proj.get("stack", "unknown")
        name_lbl = Gtk.Label(label=f"{STACK_ICONS.get(stack, '📁')}  {proj.get('name', '?')}")
        name_lbl.get_style_context().add_class("detail-title")
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.set_margin_bottom(8)
        box.pack_start(name_lbl, False, False, 0)

        # Path
        self._add_detail_row(box, "PATH", proj.get("path", "—"))
        self._add_detail_row(box, "STACK", proj.get("stack", "unknown").upper())
        self._add_detail_row(box, "STATUS", proj.get("status", "idle"))
        self._add_detail_row(box, "LAST OPENED", _rel_time(proj.get("last_opened", "")))

        # zyntrix.toml tasks (if project exists)
        project_path = Path(proj.get("path", ""))
        toml_path = project_path / "zyntrix.toml"
        if toml_path.exists():
            tasks = self._read_tasks(toml_path)
            if tasks:
                sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
                sep.set_margin_top(16)
                sep.set_margin_bottom(8)
                box.pack_start(sep, False, False, 0)

                tasks_lbl = Gtk.Label(label="TASKS")
                tasks_lbl.get_style_context().add_class("detail-label")
                tasks_lbl.set_halign(Gtk.Align.START)
                box.pack_start(tasks_lbl, False, False, 0)

                for task_name, task_cmd in tasks.items():
                    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                    row.get_style_context().add_class("task-row")
                    t_lbl = Gtk.Label(label=task_name)
                    t_lbl.get_style_context().add_class("task-name")
                    t_lbl.set_size_request(100, -1)
                    t_lbl.set_halign(Gtk.Align.START)
                    c_lbl = Gtk.Label(label=task_cmd)
                    c_lbl.get_style_context().add_class("detail-value")
                    c_lbl.set_halign(Gtk.Align.START)
                    c_lbl.set_ellipsize(Pango.EllipsizeMode.END)
                    row.pack_start(t_lbl, False, False, 0)
                    row.pack_start(c_lbl, True, True, 0)
                    box.pack_start(row, False, False, 0)

        scroll.add(box)
        self._detail_pane.pack_start(scroll, True, True, 0)

        # Action buttons
        self._detail_pane.pack_start(self._build_detail_actions(proj), False, False, 0)
        self._detail_pane.show_all()

    def _add_detail_row(self, parent: Gtk.Box, label: str, value: str) -> None:
        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("detail-label")
        lbl.set_halign(Gtk.Align.START)
        parent.pack_start(lbl, False, False, 0)

        val = Gtk.Label(label=value)
        val.get_style_context().add_class("detail-value")
        val.set_halign(Gtk.Align.START)
        val.set_selectable(True)
        val.set_line_wrap(True)
        val.set_line_wrap_mode(Pango.WrapMode.CHAR)
        parent.pack_start(val, False, False, 0)

    def _build_detail_actions(self, proj: dict) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        box.set_margin_start(8)
        box.set_margin_end(8)
        box.set_margin_top(12)
        box.set_margin_bottom(12)

        open_btn = Gtk.Button(label="▶  Open Workspace")
        open_btn.get_style_context().add_class("action-btn")
        open_btn.get_style_context().add_class("action-btn-primary")
        open_btn.connect("clicked", lambda _: self._open_project(proj))
        box.pack_start(open_btn, True, True, 0)

        terminal_btn = Gtk.Button(label="⌘  Terminal")
        terminal_btn.get_style_context().add_class("action-btn")
        terminal_btn.connect("clicked", lambda _: self._open_terminal(proj))
        box.pack_start(terminal_btn, False, False, 0)

        remove_btn = Gtk.Button(label="✕")
        remove_btn.get_style_context().add_class("action-btn")
        remove_btn.get_style_context().add_class("action-btn-danger")
        remove_btn.set_tooltip_text("Remove from list")
        remove_btn.connect("clicked", lambda _: self._remove_project(proj))
        box.pack_start(remove_btn, False, False, 0)

        return box

    @staticmethod
    def _read_tasks(toml_path: Path) -> dict:
        if tomllib is None:
            return {}
        try:
            with open(toml_path, "rb") as fh:
                return tomllib.load(fh).get("tasks", {})
        except Exception:
            return {}

    # ── Actions ───────────────────────────────────────────────────────────────
    def _open_project(self, proj: dict) -> None:
        path = proj.get("path", "")
        if not path:
            return
        info_msg = f"Opening {proj.get('name', path)}…"
        self._show_toast(info_msg)

        def _do_open():
            cli = FALLBACK_CLI
            if os.path.exists(cli):
                cmd = ["python3", cli, "open", path]
            else:
                cmd = ["zyntrix", "open", path]
            subprocess.Popen(cmd, start_new_session=True)

        threading.Thread(target=_do_open, daemon=True).start()

    def _open_terminal(self, proj: dict) -> None:
        path = proj.get("path", str(Path.home()))
        terminal = _find_terminal()
        shell_cmd = ["bash", "--login"]
        if terminal[-1] == "--":
            cmd = terminal + shell_cmd
        else:
            cmd = terminal + shell_cmd
        subprocess.Popen(cmd, cwd=path, start_new_session=True)

    def _remove_project(self, proj: dict) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Remove '{proj.get('name', '?')}' from list?",
            secondary_text="The project directory will NOT be deleted.",
        )
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        try:
            data = json.loads(PROJECTS_JSON.read_text()) if PROJECTS_JSON.exists() else {"projects": []}
            data["projects"] = [p for p in data.get("projects", []) if p.get("path") != proj.get("path")]
            PROJECTS_JSON.write_text(json.dumps(data, indent=2))
        except Exception:
            pass
        self._selected = None
        self._load_projects()
        self._show_empty_state()

    def _on_new_project(self, _btn) -> None:
        dialog = NewProjectDialog(self)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            template = dialog.get_template()
            name = dialog.get_name()
            dialog.destroy()
            if template and name:
                self._create_project(template, name)
        else:
            dialog.destroy()

    def _create_project(self, template: str, name: str) -> None:
        self._show_toast(f"Creating '{name}' from {template}…")

        def _do_create():
            cli = FALLBACK_CLI
            if os.path.exists(cli):
                cmd = ["python3", cli, "new", template, name]
            else:
                cmd = ["zyntrix", "new", template, name]
            r = subprocess.run(cmd, capture_output=True, text=True)
            GLib.idle_add(self._after_create, r.returncode, name)

        threading.Thread(target=_do_create, daemon=True).start()

    def _after_create(self, returncode: int, name: str) -> bool:
        if returncode == 0:
            self._show_toast(f"Created '{name}' → ~/projects/{name}")
            self._load_projects()
        else:
            self._show_toast(f"Failed to create project '{name}'")
        return False

    def _show_toast(self, message: str) -> None:
        self._toast_lbl.set_text(message)
        self._toast_lbl.show()
        if self._toast_timer:
            GLib.source_remove(self._toast_timer)
        self._toast_timer = GLib.timeout_add(3000, self._hide_toast)

    def _hide_toast(self) -> bool:
        self._toast_lbl.hide()
        self._toast_timer = None
        return False

    # ── Keyboard ──────────────────────────────────────────────────────────────
    def _on_key(self, _widget, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            Gtk.main_quit()
            return True
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            if self._selected:
                self._open_project(self._selected)
            return True
        return False


# ── New project dialog ─────────────────────────────────────────────────────────
class NewProjectDialog(Gtk.Dialog):
    def __init__(self, parent: Gtk.Window):
        super().__init__(title="New Project", transient_for=parent, modal=True)
        self.set_default_size(460, 360)
        self.add_buttons(
            "_Cancel", Gtk.ResponseType.CANCEL,
            "_Create", Gtk.ResponseType.OK,
        )

        self._template: str = ""
        self._templates = _load_templates()

        box = self.get_content_area()
        box.set_spacing(12)
        box.set_margin_start(20)
        box.set_margin_end(20)
        box.set_margin_top(16)
        box.set_margin_bottom(8)

        # Project name
        name_lbl = Gtk.Label(label="Project name:")
        name_lbl.set_halign(Gtk.Align.START)
        box.add(name_lbl)
        self._name_entry = Gtk.Entry()
        self._name_entry.set_placeholder_text("my-awesome-project")
        box.add(self._name_entry)

        # Template picker
        tmpl_lbl = Gtk.Label(label="Template:")
        tmpl_lbl.set_halign(Gtk.Align.START)
        tmpl_lbl.set_margin_top(8)
        box.add(tmpl_lbl)

        if self._templates:
            scroll = Gtk.ScrolledWindow()
            scroll.set_min_content_height(160)
            scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            tmpl_list = Gtk.ListBox()
            tmpl_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
            tmpl_list.connect("row-selected", self._on_template_selected)

            for tmpl in self._templates:
                row = Gtk.ListBoxRow()
                row._template_name = tmpl
                lbl = Gtk.Label(label=tmpl)
                lbl.set_halign(Gtk.Align.START)
                lbl.set_margin_start(12)
                lbl.set_margin_top(6)
                lbl.set_margin_bottom(6)
                row.add(lbl)
                tmpl_list.add(row)

            # Select first row by default
            if tmpl_list.get_row_at_index(0):
                tmpl_list.select_row(tmpl_list.get_row_at_index(0))
                self._template = self._templates[0]
                # Prefill name with template
                self._name_entry.set_text(self._templates[0])

            scroll.add(tmpl_list)
            box.add(scroll)
        else:
            box.add(Gtk.Label(label="No templates found in templates/ directory."))

        box.show_all()

    def _on_template_selected(self, _box, row: Gtk.ListBoxRow) -> None:
        if row and hasattr(row, "_template_name"):
            self._template = row._template_name
            if not self._name_entry.get_text() or self._name_entry.get_text() in _load_templates():
                self._name_entry.set_text(self._template)

    def get_template(self) -> str:
        return self._template

    def get_name(self) -> str:
        return self._name_entry.get_text().strip()


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    win = ProjectsPanel()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
