"""
ZyntrixOS recently-used tile tracker.
Persists a launch-count + last-used timestamp to
~/.local/share/zyntrix/recents.json.
Used by main.py to re-sort tiles so frequently-used ones appear first.
"""

import json
import os
import threading
import time
from typing import Optional

_STATE_PATH = os.path.join(
    os.environ.get("XDG_DATA_HOME", os.path.expanduser("~/.local/share")),
    "zyntrix", "recents.json"
)


def _load() -> dict:
    try:
        with open(_STATE_PATH) as fh:
            return json.load(fh)
    except Exception:
        return {}


def _save(data: dict) -> None:
    try:
        os.makedirs(os.path.dirname(_STATE_PATH), exist_ok=True)
        with open(_STATE_PATH, "w") as fh:
            json.dump(data, fh, indent=2)
    except Exception:
        pass


def record_launch(tile_id: str) -> None:
    """Increment launch count and update last-used timestamp.
    Runs in a daemon thread to avoid stalling the GTK main loop."""
    threading.Thread(
        target=_record_launch_bg,
        args=(tile_id,),
        daemon=True,
        name="recents-write",
    ).start()


def _record_launch_bg(tile_id: str) -> None:
    data = _load()
    entry = data.get(tile_id, {"count": 0, "last": 0})
    entry["count"] = entry.get("count", 0) + 1
    entry["last"] = time.time()
    data[tile_id] = entry
    _save(data)


def sort_tiles(tiles: list, max_float: int = 3) -> list:
    """
    Return tiles sorted so the top `max_float` most-recently-used
    tiles appear first; the rest keep their original order.
    """
    data = _load()
    if not data:
        return tiles

    # Score = count * 0.6 + recency_bonus (1.0 for last 24h, 0.5 for last week)
    now = time.time()

    def _score(tile) -> float:
        e = data.get(tile.id)
        if not e:
            return 0.0
        age = now - e.get("last", 0)
        if age < 86400:
            recency = 1.0
        elif age < 604800:
            recency = 0.5
        else:
            recency = 0.1
        return e.get("count", 0) * 0.6 + recency

    scored = [(t, _score(t)) for t in tiles]
    floaters = sorted(
        [(t, s) for t, s in scored if s > 0],
        key=lambda x: x[1],
        reverse=True,
    )[:max_float]
    floater_ids = {t.id for t, _ in floaters}

    result = [t for t, _ in floaters]
    result += [t for t in tiles if t.id not in floater_ids]
    return result


def get_stats() -> dict:
    """Return the raw stats dict (for settings display)."""
    return _load()
