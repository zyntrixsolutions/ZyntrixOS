#!/usr/bin/env python3
"""
ZyntrixOS Settings — GTK3 settings panel.
Writes changes to ~/.config/zyntrix/config.toml.
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")

import os
import re
import sys
import json
import subprocess
import shutil
from gi.repository import Gtk, Gdk, GLib

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore

SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
if SHELL_DIR not in sys.path:
    sys.path.insert(0, SHELL_DIR)
try:
    from tiles import DEFAULT_TILES
except Exception:
    DEFAULT_TILES = []  # type: ignore

ACCENT_PRESETS = [
    ("#00f0c8", "Cyan"),
    ("#7c3aed", "Purple"),
    ("#ff2d78", "Pink"),
    ("#22d3ee", "Sky"),
    ("#f59e0b", "Amber"),
    ("#10b981", "Emerald"),
    ("#f97316", "Orange"),
    ("#ec4899", "Rose"),
]

WINDOW_W, WINDOW_H = 720, 520
CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "zyntrix")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.toml")
VERSION_MANIFEST = "/etc/zyntrix/version.json"
ZYNTRIX_PACKAGES = [
    "zyntrix-shell",
    "zyntrix-cli",
    "zyntrix-config",
    "zyntrix-os-base",
    "zyntrix-update",
]
CHANNELS = ["stable", "beta", "canary"]


# ── Config I/O ────────────────────────────────────────────────────────────────
def _read_config() -> dict:
    """Read config.toml. Returns dict with 'theme' and 'tiles' keys."""
    if tomllib is None or not os.path.exists(CONFIG_FILE):
        return {}
    try:
        with open(CONFIG_FILE, "rb") as fh:
            return tomllib.load(fh)
    except Exception:
        return {}


def _write_config(data: dict) -> None:
    os.makedirs(CONFIG_DIR, exist_ok=True)
    lines = []

    theme = data.get("theme", {})
    if theme:
        lines.append("[theme]")
        for k, v in theme.items():
            if isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            else:
                lines.append(f'{k} = {v}')
        lines.append("")

    tiles = data.get("tiles", [])
    for tile in tiles:
        lines.append("[[tiles]]")
        for k, v in tile.items():
            if isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, bool):
                lines.append(f'{k} = {"true" if v else "false"}')
            elif isinstance(v, list):
                items = ", ".join(f'"{i}"' if isinstance(i, str) else str(i) for i in v)
                lines.append(f'{k} = [{items}]')
            else:
                lines.append(f'{k} = {v}')
        lines.append("")

    with open(CONFIG_FILE, "w") as fh:
        fh.write("\n".join(lines))


# ── Volume helpers ────────────────────────────────────────────────────────────
def _get_volume() -> int:
    for cmd in [
        ["pactl", "get-sink-volume", "@DEFAULT_SINK@"],
        ["amixer", "get", "Master"],
    ]:
        if not shutil.which(cmd[0]):
            continue
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=3)
            m = re.search(r'(\d+)%', out)
            if m:
                return int(m.group(1))
        except Exception:
            pass
    return 50


def _set_volume(vol: int) -> None:
    vol = max(0, min(100, vol))
    for cmd in [
        ["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{vol}%"],
        ["amixer", "set", "Master", f"{vol}%"],
    ]:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, capture_output=True, timeout=3)
                return
            except Exception:
                pass


# ── Display helpers ───────────────────────────────────────────────────────────
def _get_resolutions() -> list[str]:
    try:
        out = subprocess.check_output(["xrandr"], stderr=subprocess.DEVNULL, text=True, timeout=5)
        return sorted(set(re.findall(r'\b(\d{3,4}x\d{3,4})\b', out)), reverse=True)
    except Exception:
        return []


def _set_resolution(res: str) -> None:
    try:
        subprocess.run(["xrandr", "--auto"], capture_output=True, timeout=5)
        subprocess.run(["xrandr", "-s", res], capture_output=True, timeout=5)
    except Exception:
        pass


# ── Update helpers ───────────────────────────────────────────────────────────
def _read_json_file(path: str) -> dict:
    try:
        with open(path, "r") as fh:
            return json.load(fh)
    except Exception:
        return {}


def _cmd_text(cmd: list[str], timeout: int = 4) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=timeout)
    except Exception:
        return ""


def _dpkg_version(package: str) -> str:
    return _cmd_text(["dpkg-query", "-W", "-f=${Version}", package]).strip()


def _apt_policy(package: str) -> dict:
    installed = _dpkg_version(package)
    candidate = ""
    for line in _cmd_text(["apt-cache", "policy", package]).splitlines():
        stripped = line.strip()
        if stripped.startswith("Candidate:"):
            value = stripped.split(":", 1)[1].strip()
            candidate = "" if value == "(none)" else value
            break
    return {"package": package, "installed": installed, "candidate": candidate}


def _candidate_is_update(installed: str, candidate: str) -> bool:
    if not candidate:
        return False
    if not installed:
        return True
    if shutil.which("dpkg"):
        return subprocess.run(
            ["dpkg", "--compare-versions", candidate, "gt", installed],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
    return candidate != installed


# ── Colour swatch button ──────────────────────────────────────────────────────
class SwatchButton(Gtk.ToggleButton):
    def __init__(self, color: str, label: str):
        super().__init__()
        self.color = color
        self.set_size_request(64, 36)
        self.set_tooltip_text(f"{label}\n{color}")

        # Color the button background via inline CSS
        provider = Gtk.CssProvider()
        provider.load_from_data(
            f"button {{ background: {color}; border-radius: 4px; min-width: 60px; min-height: 32px; }}".encode()
        )
        self.get_style_context().add_provider(provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)


# ── Settings window ───────────────────────────────────────────────────────────
class SettingsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS Settings")
        self.set_default_size(WINDOW_W, WINDOW_H)
        self.set_border_width(0)
        self.connect("destroy", Gtk.main_quit)

        self._config = _read_config()
        self._theme = {
            "accent":     "#00f0c8",
            "background": "#0a0b0f",
            "surface":    "#12141a",
            "text":       "#e8eaf0",
            "columns":    4,
            **self._config.get("theme", {}),
        }
        self._apply_css()

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # Header
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        header.set_margin_start(20)
        header.set_margin_end(20)
        header.set_margin_top(16)
        header.set_margin_bottom(12)
        title = Gtk.Label()
        title.set_markup("<b>ZyntrixOS Settings</b>")
        title.set_halign(Gtk.Align.START)
        header.pack_start(title, True, True, 0)
        vbox.pack_start(header, False, False, 0)

        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        vbox.pack_start(sep, False, False, 0)

        # Notebook
        nb = Gtk.Notebook()
        nb.set_tab_pos(Gtk.PositionType.LEFT)
        nb.append_page(self._build_appearance(), Gtk.Label(label="Appearance"))
        nb.append_page(self._build_tiles_page(), Gtk.Label(label="Tiles"))
        nb.append_page(self._build_display_page(), Gtk.Label(label="Display"))
        nb.append_page(self._build_audio_page(), Gtk.Label(label="Audio"))
        nb.append_page(self._build_updates_page(), Gtk.Label(label="Updates"))
        nb.append_page(self._build_system_page(), Gtk.Label(label="System"))
        vbox.pack_start(nb, True, True, 0)

        # Footer buttons
        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_box.set_margin_start(16)
        btn_box.set_margin_end(16)
        btn_box.set_margin_top(12)
        btn_box.set_margin_bottom(12)

        btn_cancel = Gtk.Button(label="Cancel")
        btn_cancel.connect("clicked", lambda _: self.destroy())

        btn_save = Gtk.Button(label="Save & Restart Shell")
        btn_save.get_style_context().add_class("suggested-action")
        btn_save.connect("clicked", self._on_save)

        btn_box.pack_end(btn_save, False, False, 0)
        btn_box.pack_end(btn_cancel, False, False, 0)
        vbox.pack_start(btn_box, False, False, 0)

        self.add(vbox)

    # ── CSS ───────────────────────────────────────────────────────────────────
    def _apply_css(self) -> None:
        """Load theme.css with the same token substitution as main.py."""
        theme_css = os.path.join(SHELL_DIR, "theme.css")
        try:
            with open(theme_css, "r") as fh:
                css_template = fh.read()
        except Exception:
            return

        accent = self._theme.get("accent", "#00f0c8")
        bg     = self._theme.get("background", "#0a0b0f")
        surface = self._theme.get("surface", "#12141a")
        text   = self._theme.get("text", "#e8eaf0")

        def _darken(hex_color: str, factor: float = 0.6) -> str:
            h = hex_color.lstrip("#")
            r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
            return "#{:02x}{:02x}{:02x}".format(
                min(255, int(r * factor)),
                min(255, int(g * factor)),
                min(255, int(b * factor)),
            )

        def _alpha(hex_color: str, a: float = 0.18) -> str:
            h = hex_color.lstrip("#")
            r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
            return f"rgba({r},{g},{b},{a})"

        replacements = {
            "@surface-hover": _darken(surface, 1.4) if surface.startswith("#") else "#1e2030",
            "@surface":       surface,
            "@accent-dim":    _alpha(accent),
            "@accent":        accent,
            "@border":        _darken(accent, 0.35),
            "@text-dim":      _darken(text, 0.55),
            "@text":          text,
            "@bg":            bg,
        }
        css = css_template
        for token, value in sorted(replacements.items(), key=lambda kv: -len(kv[0])):
            css = css.replace(token, value)

        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(css.encode())
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(), provider,
                Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
            )
        except Exception:
            pass

    # ── Appearance tab ────────────────────────────────────────────────────────
    def _build_appearance(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)

        # Accent colour
        page.pack_start(self._section_label("Accent Colour"), False, False, 0)

        swatch_box = Gtk.FlowBox()
        swatch_box.set_max_children_per_line(8)
        swatch_box.set_selection_mode(Gtk.SelectionMode.NONE)
        swatch_box.set_column_spacing(8)
        swatch_box.set_row_spacing(8)

        self._swatch_group: list[SwatchButton] = []
        current_accent = self._theme["accent"].lower()

        for color, name in ACCENT_PRESETS:
            btn = SwatchButton(color, name)
            if color.lower() == current_accent:
                btn.set_active(True)
            btn.connect("toggled", self._on_swatch_toggled, color)
            swatch_box.add(btn)
            self._swatch_group.append(btn)

        page.pack_start(swatch_box, False, False, 0)

        # Custom hex
        hex_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hex_box.pack_start(Gtk.Label(label="Custom hex:"), False, False, 0)
        self._accent_entry = Gtk.Entry()
        self._accent_entry.set_text(self._theme["accent"])
        self._accent_entry.set_max_length(7)
        self._accent_entry.set_size_request(100, -1)
        hex_box.pack_start(self._accent_entry, False, False, 0)
        page.pack_start(hex_box, False, False, 0)

        page.pack_start(self._section_label("Grid Columns"), False, False, 0)

        col_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        col_box.pack_start(Gtk.Label(label="Columns:"), False, False, 0)
        self._col_spin = Gtk.SpinButton.new_with_range(2, 6, 1)
        self._col_spin.set_value(int(self._theme.get("columns", 4)))
        col_box.pack_start(self._col_spin, False, False, 0)
        page.pack_start(col_box, False, False, 0)

        page.pack_start(self._section_label("Wallpaper"), False, False, 0)

        wp_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._wp_entry = Gtk.Entry()
        self._wp_entry.set_placeholder_text("Path to image or hex colour…")
        self._wp_entry.set_text(self._theme.get("wallpaper", ""))
        self._wp_entry.set_hexpand(True)

        wp_btn = Gtk.Button(label="Browse…")
        wp_btn.connect("clicked", self._on_wp_browse)
        wp_clear = Gtk.Button(label="Clear")
        wp_clear.connect("clicked", lambda _: self._wp_entry.set_text(""))

        wp_box.pack_start(self._wp_entry, True, True, 0)
        wp_box.pack_start(wp_btn, False, False, 0)
        wp_box.pack_start(wp_clear, False, False, 0)
        page.pack_start(wp_box, False, False, 0)

        return page

    def _on_wp_browse(self, _btn) -> None:
        dialog = Gtk.FileChooserDialog(
            title="Choose Wallpaper",
            transient_for=self,
            action=Gtk.FileChooserAction.OPEN,
        )
        dialog.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                           "Open", Gtk.ResponseType.OK)
        f = Gtk.FileFilter()
        f.set_name("Images")
        f.add_mime_type("image/png")
        f.add_mime_type("image/jpeg")
        f.add_mime_type("image/webp")
        dialog.add_filter(f)
        if dialog.run() == Gtk.ResponseType.OK:
            self._wp_entry.set_text(dialog.get_filename())
        dialog.destroy()

    def _on_swatch_toggled(self, btn: SwatchButton, color: str) -> None:
        if btn.get_active():
            for other in self._swatch_group:
                if other is not btn:
                    other.set_active(False)
            self._accent_entry.set_text(color)
            self._theme["accent"] = color

    # ── Tiles tab ─────────────────────────────────────────────────────────────
    def _build_tiles_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)

        page.pack_start(self._section_label("Enabled Tiles"), False, False, 0)
        hint = Gtk.Label(label="Disabled tiles are hidden from the launcher. Changes take effect on restart.")
        hint.set_line_wrap(True)
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)

        self._tile_switches: dict[str, Gtk.Switch] = {}
        config_tiles = {t.get("id"): t for t in self._config.get("tiles", [])}

        for tile in DEFAULT_TILES:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.set_margin_top(4)

            icon = Gtk.Image.new_from_icon_name(tile.icon or "application-x-executable", Gtk.IconSize.MENU)
            row.pack_start(icon, False, False, 0)

            lbl = Gtk.Label(label=f"{tile.label} — {tile.subtitle}")
            lbl.set_halign(Gtk.Align.START)
            row.pack_start(lbl, True, True, 0)

            sw = Gtk.Switch()
            ct = config_tiles.get(tile.id)
            sw.set_active(ct.get("enabled", True) if ct else tile.enabled)
            row.pack_end(sw, False, False, 0)

            self._tile_switches[tile.id] = sw
            page.pack_start(row, False, False, 0)

        return page

    # ── Display tab ───────────────────────────────────────────────────────────
    def _build_display_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)

        page.pack_start(self._section_label("Resolution"), False, False, 0)

        resolutions = _get_resolutions()
        combo = Gtk.ComboBoxText()
        for r in resolutions:
            combo.append_text(r)
        if resolutions:
            combo.set_active(0)

        apply_btn = Gtk.Button(label="Apply")
        apply_btn.connect("clicked", lambda _: _set_resolution(combo.get_active_text() or ""))

        res_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        res_box.pack_start(combo, False, False, 0)
        res_box.pack_start(apply_btn, False, False, 0)
        page.pack_start(res_box, False, False, 0)

        if not resolutions:
            page.pack_start(Gtk.Label(label="xrandr not available or no display."), False, False, 0)

        return page

    # ── Audio tab ────────────────────────────────────────────────────────────
    def _build_audio_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)

        page.pack_start(self._section_label("Master Volume"), False, False, 0)

        vol = _get_volume()
        self._vol_scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self._vol_scale.set_value(vol)
        self._vol_scale.set_hexpand(True)
        self._vol_scale.set_digits(0)
        self._vol_scale.connect("value-changed", lambda s: _set_volume(int(s.get_value())))

        vol_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        vol_box.pack_start(Gtk.Label(label="Volume:"), False, False, 0)
        vol_box.pack_start(self._vol_scale, True, True, 0)
        page.pack_start(vol_box, False, False, 0)

        return page

    # ── Updates tab ─────────────────────────────────────────────────────────
    def _build_updates_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)
        page.set_margin_bottom(16)

        manifest = _read_json_file(VERSION_MANIFEST)
        channel = manifest.get("channel", "stable")

        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        top.pack_start(Gtk.Label(label="Channel:"), False, False, 0)
        self._update_channel_combo = Gtk.ComboBoxText()
        for item in CHANNELS:
            self._update_channel_combo.append_text(item)
        self._update_channel_combo.set_active(CHANNELS.index(channel) if channel in CHANNELS else 0)
        top.pack_start(self._update_channel_combo, False, False, 0)

        apply_channel = Gtk.Button(label="Apply Channel")
        apply_channel.connect("clicked", self._on_update_channel_apply)
        top.pack_start(apply_channel, False, False, 0)
        page.pack_start(top, False, False, 0)

        self._updates_last_check = Gtk.Label()
        self._updates_last_check.set_halign(Gtk.Align.START)
        page.pack_start(self._updates_last_check, False, False, 0)

        self._updates_store = Gtk.ListStore(str, str, str, str)
        tree = Gtk.TreeView(model=self._updates_store)
        tree.set_headers_visible(True)
        for idx, title in enumerate(["Package", "Installed", "Candidate", "Status"]):
            renderer = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(title, renderer, text=idx)
            col.set_resizable(True)
            tree.append_column(col)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        scroll.add(tree)
        page.pack_start(scroll, True, True, 0)

        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        check_btn = Gtk.Button(label="Check for Updates")
        check_btn.connect("clicked", self._on_update_check)
        install_btn = Gtk.Button(label="Install Updates")
        install_btn.get_style_context().add_class("suggested-action")
        install_btn.connect("clicked", self._on_update_install)
        changelog_btn = Gtk.Button(label="View Changelogs")
        changelog_btn.connect("clicked", self._on_update_changelogs)
        rollback_btn = Gtk.Button(label="Rollback")
        rollback_btn.connect("clicked", self._on_update_rollback)
        refresh_btn = Gtk.Button(label="Refresh")
        refresh_btn.connect("clicked", lambda _: self._refresh_updates_view())

        for btn in [check_btn, install_btn, changelog_btn, rollback_btn, refresh_btn]:
            buttons.pack_start(btn, False, False, 0)
        page.pack_start(buttons, False, False, 0)

        self._refresh_updates_view()
        return page

    def _refresh_updates_view(self) -> None:
        if not hasattr(self, "_updates_store"):
            return
        manifest = _read_json_file(VERSION_MANIFEST)
        channel = manifest.get("channel", "stable")
        if hasattr(self, "_update_channel_combo") and channel in CHANNELS:
            self._update_channel_combo.set_active(CHANNELS.index(channel))
        last = manifest.get("last_check") or "never"
        self._updates_last_check.set_text(f"Last check: {last}")
        self._updates_store.clear()
        installed_manifest = manifest.get("installed", {})
        for package in ZYNTRIX_PACKAGES:
            policy = _apt_policy(package)
            installed = policy.get("installed") or installed_manifest.get(package, "")
            candidate = policy.get("candidate", "")
            status = "Update available" if _candidate_is_update(installed, candidate) else "Current"
            if not installed:
                status = "Not installed"
            self._updates_store.append([package, installed or "—", candidate or "—", status])

    def _run_update_terminal(self, command: str) -> None:
        subprocess.Popen(
            self._terminal_cmd() + ["bash", "-lc", command],
            start_new_session=True,
        )

    def _on_update_check(self, _btn) -> None:
        self._run_update_terminal(
            "zyntrix update check; code=$?; echo; zyntrix update list; echo; "
            "read -r -p 'Press Enter to close...'; exit $code"
        )
        GLib.timeout_add_seconds(3, lambda: (self._refresh_updates_view(), False)[1])

    def _on_update_install(self, _btn) -> None:
        self._run_update_terminal(
            "zyntrix update install; code=$?; echo; read -r -p 'Press Enter to close...'; exit $code"
        )
        GLib.timeout_add_seconds(5, lambda: (self._refresh_updates_view(), False)[1])

    def _on_update_changelogs(self, _btn) -> None:
        self._run_update_terminal(
            "zyntrix update list --changelog; echo; read -r -p 'Press Enter to close...'"
        )

    def _on_update_rollback(self, _btn) -> None:
        self._run_update_terminal(
            "zyntrix update rollback; code=$?; echo; read -r -p 'Press Enter to close...'; exit $code"
        )
        GLib.timeout_add_seconds(5, lambda: (self._refresh_updates_view(), False)[1])

    def _on_update_channel_apply(self, _btn) -> None:
        channel = self._update_channel_combo.get_active_text() or "stable"
        self._run_update_terminal(
            f"zyntrix channel {channel}; code=$?; echo; read -r -p 'Press Enter to close...'; exit $code"
        )
        GLib.timeout_add_seconds(3, lambda: (self._refresh_updates_view(), False)[1])

    # ── System tab ────────────────────────────────────────────────────────────
    def _build_system_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        page.set_margin_start(24)
        page.set_margin_end(24)
        page.set_margin_top(20)

        page.pack_start(self._section_label("Power"), False, False, 0)
        pwr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for label, cmd in [("Shutdown", ["systemctl", "poweroff"]), ("Reboot", ["systemctl", "reboot"]),
                           ("Suspend", ["systemctl", "suspend"])]:
            btn = Gtk.Button(label=label)
            btn.connect("clicked", lambda _, c=cmd: self._power_action(c))
            pwr.pack_start(btn, False, False, 0)
        page.pack_start(pwr, False, False, 0)

        page.pack_start(self._section_label("Config File"), False, False, 0)
        cfg_label = Gtk.Label(label=CONFIG_FILE)
        cfg_label.set_halign(Gtk.Align.START)
        cfg_label.set_selectable(True)
        page.pack_start(cfg_label, False, False, 0)

        open_btn = Gtk.Button(label="Open config.toml in editor")
        open_btn.connect("clicked", lambda _: subprocess.Popen(
            self._editor_cmd() + [CONFIG_FILE], start_new_session=True
        ))
        page.pack_start(open_btn, False, False, 0)

        return page

    def _power_action(self, cmd: list) -> None:
        action = cmd[-1]  # e.g. "poweroff", "reboot", "suspend"
        if shutil.which(cmd[0]):
            subprocess.Popen(cmd)
            return
        # Fallbacks for missing systemctl
        fallbacks = {
            "poweroff": [["sudo", "poweroff"], ["sudo", "shutdown", "-h", "now"]],
            "reboot":   [["sudo", "reboot"], ["sudo", "shutdown", "-r", "now"]],
            "suspend":  [["sudo", "pm-suspend"], ["sudo", "pm-suspend-hybrid"]],
        }
        for fb in fallbacks.get(action, []):
            if shutil.which(fb[0]):
                subprocess.Popen(fb)
                return
        # Last resort: show error dialog
        try:
            d = Gtk.MessageDialog(
                transient_for=self, modal=True,
                message_type=Gtk.MessageType.ERROR,
                buttons=Gtk.ButtonsType.OK,
                text=f"Cannot {action}: systemctl not found",
            )
            d.run(); d.destroy()
        except Exception:
            pass

    @staticmethod
    def _terminal_cmd() -> list:
        terminals = [
            ("foot", ["-e"]),
            ("alacritty", ["-e"]),
            ("kitty", ["-e"]),
            ("xfce4-terminal", ["--"]),
            ("gnome-terminal", ["--"]),
            ("mate-terminal", ["--"]),
            ("lxterminal", ["-e"]),
            ("xterm", ["-e"]),
        ]
        for term, args in terminals:
            if shutil.which(term):
                return [term] + args
        # Return xterm as ultimate fallback even if not found (will fail visibly)
        return ["xterm", "-e"]

    @staticmethod
    def _editor_cmd() -> list:
        editors = ["codium", "code", "vscodium", "geany", "gedit", "mousepad", "xed", "leafpad", "nano", "vim", "vi"]
        for e in editors:
            if shutil.which(e):
                return [e]
        return ["xterm", "-e", "nano"]

    # ── Helpers ───────────────────────────────────────────────────────────────
    @staticmethod
    def _section_label(text: str) -> Gtk.Label:
        lbl = Gtk.Label()
        lbl.set_markup(f"<b>{GLib.markup_escape_text(text)}</b>")
        lbl.set_halign(Gtk.Align.START)
        lbl.set_margin_top(4)
        return lbl

    # ── Save ──────────────────────────────────────────────────────────────────
    def _on_save(self, _btn) -> None:
        accent = self._accent_entry.get_text().strip() or self._theme["accent"]
        self._theme["accent"] = accent
        self._theme["columns"] = int(self._col_spin.get_value())
        wp = self._wp_entry.get_text().strip()
        if wp:
            self._theme["wallpaper"] = wp
        else:
            self._theme.pop("wallpaper", None)

        tiles_out = []
        for tile in DEFAULT_TILES:
            enabled = self._tile_switches.get(tile.id, None)
            tiles_out.append({
                "id": tile.id,
                "label": tile.label,
                "subtitle": tile.subtitle,
                "icon": tile.icon,
                "command": tile.command,
                "enabled": enabled.get_active() if enabled else True,
                "live_only": getattr(tile, "live_only", False),
            })

        _write_config({"theme": self._theme, "tiles": tiles_out})

        dialog = Gtk.MessageDialog(
            transient_for=self,
            modal=True,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text="Settings saved.",
            secondary_text="Restart ZyntrixOS Shell to apply changes.",
        )
        dialog.run()
        dialog.destroy()
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    win = SettingsWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
