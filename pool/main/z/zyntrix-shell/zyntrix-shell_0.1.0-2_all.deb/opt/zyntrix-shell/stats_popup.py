#!/usr/bin/env python3
"""
ZyntrixOS Stats Popup — live performance overlay.
Spawn via keybind (Super+grave). Re-spawning toggles it off.
Closes on Escape or focus-out.
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib

import glob
import os
import signal
import sys
import time
from typing import Optional

_temp_path: Optional[str] = None  # cached thermal sysfs path after first discovery

PIDFILE   = "/tmp/zyntrix-stats.pid"
UPDATE_MS = 1000
WIN_W     = 390
WIN_H     = 540


# ── System reads ──────────────────────────────────────────────────────────────

def _cpu_times() -> dict:
    try:
        result = {}
        with open("/proc/stat") as f:
            for line in f:
                if not line.startswith("cpu"):
                    continue
                parts = line.split()
                result[parts[0]] = list(map(int, parts[1:8]))
        return result
    except Exception:
        return {}


def _calc_pct(prev: dict, curr: dict) -> dict:
    out = {}
    for key in curr:
        if key not in prev:
            continue
        p, c = prev[key], curr[key]
        idle_p = p[3] + (p[4] if len(p) > 4 else 0)
        idle_c = c[3] + (c[4] if len(c) > 4 else 0)
        total  = sum(c) - sum(p)
        idle   = idle_c - idle_p
        out[key] = 0.0 if total == 0 else max(0.0, min(100.0, 100.0 * (total - idle) / total))
    return out


def _mem() -> tuple:
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k.strip()] = int(v.strip().split()[0])
        total = info["MemTotal"]
        avail = info.get("MemAvailable", info.get("MemFree", 0))
        used  = total - avail
        return used // 1024, total // 1024, int(100 * used / total) if total else 0
    except Exception:
        return 0, 0, 0


def _net_bytes() -> tuple:
    try:
        rx = tx = 0
        with open("/proc/net/dev") as f:
            for line in f.readlines()[2:]:
                parts = line.split()
                if parts[0].rstrip(":") == "lo":
                    continue
                rx += int(parts[1])
                tx += int(parts[9])
        return rx, tx
    except Exception:
        return 0, 0


def _disk_bytes() -> tuple:
    try:
        rb = wb = 0
        with open("/proc/diskstats") as f:
            for line in f:
                p = line.split()
                dev = p[2]
                if not any(dev.startswith(x) for x in ("sd", "hd", "nvme", "vd", "mmcblk")):
                    continue
                if dev[-1].isdigit() and not any(dev.startswith(x) for x in ("nvme", "mmcblk")):
                    continue
                rb += int(p[5]) * 512
                wb += int(p[9]) * 512
        return rb, wb
    except Exception:
        return 0, 0


def _temp() -> float | None:
    global _temp_path
    if _temp_path:
        try:
            return int(open(_temp_path).read().strip()) / 1000.0
        except Exception:
            _temp_path = None  # path disappeared — re-discover next call
    for path in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            val = int(open(path).read().strip()) / 1000.0
            _temp_path = path
            return val
        except Exception:
            pass
    for path in glob.glob("/sys/class/hwmon/hwmon*/temp1_input"):
        try:
            val = int(open(path).read().strip()) / 1000.0
            _temp_path = path
            return val
        except Exception:
            pass
    return None


def _uptime() -> str:
    try:
        s = float(open("/proc/uptime").read().split()[0])
        h = int(s // 3600)
        m = int((s % 3600) // 60)
        return f"{h}h {m:02d}m" if h else f"{m}m {int(s % 60):02d}s"
    except Exception:
        return "?"


def _proc_count() -> int:
    try:
        with os.scandir("/proc") as it:
            return sum(1 for e in it if e.name.isdigit())
    except Exception:
        return 0


def _fmt_rate(bps: float) -> str:
    if bps < 1024:
        return f"{bps:.0f} B/s"
    if bps < 1024 * 1024:
        return f"{bps / 1024:.1f} KB/s"
    return f"{bps / 1024 / 1024:.1f} MB/s"


# ── UI ────────────────────────────────────────────────────────────────────────

class StatsPopup(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS Stats")
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_keep_above(True)
        self.set_default_size(WIN_W, WIN_H)
        self.set_resizable(False)
        self.get_style_context().add_class("stats-window")

        screen = Gdk.Screen.get_default()
        sw = screen.get_width() if screen else 1920
        self.move(sw - WIN_W - 14, 14)

        self.connect("focus-out-event", lambda *_: self._close())
        self.connect("key-press-event", self._on_key)

        self._prev_cpu  = _cpu_times()
        self._prev_net  = _net_bytes()
        self._prev_disk = _disk_bytes()
        self._prev_t    = time.monotonic()

        self._core_bars: list = []
        self._core_vals: list = []

        self._build_ui()
        self._update()
        GLib.timeout_add(UPDATE_MS, self._update)

    # ── Build ─────────────────────────────────────────────────────────────────

    def _build_ui(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.set_margin_start(22)
        outer.set_margin_end(22)
        outer.set_margin_top(18)
        outer.set_margin_bottom(16)

        # ── Header ──
        hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        title = Gtk.Label(label="SYSTEM MONITOR")
        title.get_style_context().add_class("stats-header")
        title.set_halign(Gtk.Align.START)
        title.set_hexpand(True)

        self._uptime_lbl = Gtk.Label(label="")
        self._uptime_lbl.get_style_context().add_class("stats-meta")

        close_btn = Gtk.Button(label="✕")
        close_btn.set_relief(Gtk.ReliefStyle.NONE)
        close_btn.get_style_context().add_class("stats-close-btn")
        close_btn.connect("clicked", lambda _: self._close())

        hdr.pack_start(title, True, True, 0)
        hdr.pack_start(self._uptime_lbl, False, False, 10)
        hdr.pack_end(close_btn, False, False, 0)
        outer.pack_start(hdr, False, False, 0)

        sep = Gtk.Separator()
        sep.set_margin_top(12)
        sep.set_margin_bottom(14)
        outer.pack_start(sep, False, False, 0)

        # ── CPU section ──
        outer.pack_start(self._section_label("CPU"), False, False, 0)
        self._cpu_bar, self._cpu_val = self._add_bar_row("Total", outer)
        self._cores_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        outer.pack_start(self._cores_box, False, False, 0)

        self._temp_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._temp_row.set_margin_top(4)
        self._temp_row.set_margin_bottom(6)
        tl = Gtk.Label(label="Temp")
        tl.get_style_context().add_class("stats-row-label")
        tl.set_width_chars(10)
        tl.set_halign(Gtk.Align.START)
        self._temp_val = Gtk.Label(label="—")
        self._temp_val.get_style_context().add_class("stats-row-value")
        self._temp_row.pack_start(tl, False, False, 0)
        self._temp_row.pack_start(self._temp_val, False, False, 0)
        outer.pack_start(self._temp_row, False, False, 0)

        outer.pack_start(self._gap(), False, False, 0)

        # ── Memory section ──
        outer.pack_start(self._section_label("MEMORY"), False, False, 0)
        self._ram_bar, self._ram_val = self._add_bar_row("RAM", outer)
        self._ram_detail = Gtk.Label(label="")
        self._ram_detail.get_style_context().add_class("stats-meta")
        self._ram_detail.set_halign(Gtk.Align.END)
        self._ram_detail.set_margin_bottom(6)
        outer.pack_start(self._ram_detail, False, False, 0)
        outer.pack_start(self._gap(), False, False, 0)

        # ── Network section ──
        outer.pack_start(self._section_label("NETWORK"), False, False, 0)
        net_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        net_row.set_margin_bottom(8)
        self._net_rx = self._add_card("↓ Download", "—", net_row)
        self._net_tx = self._add_card("↑ Upload", "—", net_row)
        outer.pack_start(net_row, False, False, 0)
        outer.pack_start(self._gap(), False, False, 0)

        # ── Disk section ──
        outer.pack_start(self._section_label("DISK I/O"), False, False, 0)
        disk_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        disk_row.set_margin_bottom(8)
        self._disk_r = self._add_card("▶ Read", "—", disk_row)
        self._disk_w = self._add_card("◀ Write", "—", disk_row)
        outer.pack_start(disk_row, False, False, 0)
        outer.pack_start(self._gap(), False, False, 0)

        # ── Processes row ──
        proc_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        pl = Gtk.Label(label="Processes")
        pl.get_style_context().add_class("stats-row-label")
        pl.set_hexpand(True)
        pl.set_halign(Gtk.Align.START)
        self._proc_val = Gtk.Label(label="—")
        self._proc_val.get_style_context().add_class("stats-row-value")
        proc_row.pack_start(pl, True, True, 0)
        proc_row.pack_end(self._proc_val, False, False, 0)
        outer.pack_start(proc_row, False, False, 0)

        # ── Footer hint ──
        hint = Gtk.Label(label="Super+`  toggle   ·   Esc  close")
        hint.get_style_context().add_class("stats-hint")
        hint.set_margin_top(16)
        outer.pack_end(hint, False, False, 0)

        self.add(outer)

    def _section_label(self, text: str) -> Gtk.Label:
        lbl = Gtk.Label(label=text)
        lbl.get_style_context().add_class("stats-section")
        lbl.set_halign(Gtk.Align.START)
        lbl.set_margin_bottom(7)
        return lbl

    def _gap(self) -> Gtk.Box:
        b = Gtk.Box()
        b.set_size_request(-1, 8)
        return b

    def _add_bar_row(self, label: str, parent: Gtk.Box):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.set_margin_bottom(5)

        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("stats-row-label")
        lbl.set_width_chars(10)
        lbl.set_halign(Gtk.Align.START)

        bar = Gtk.ProgressBar()
        bar.get_style_context().add_class("stats-bar")
        bar.set_hexpand(True)

        val = Gtk.Label(label="0%")
        val.get_style_context().add_class("stats-row-value")
        val.set_width_chars(5)
        val.set_halign(Gtk.Align.END)

        row.pack_start(lbl, False, False, 0)
        row.pack_start(bar, True, True, 0)
        row.pack_end(val, False, False, 0)
        parent.pack_start(row, False, False, 0)
        return bar, val

    def _add_card(self, label: str, value: str, parent: Gtk.Box) -> Gtk.Label:
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        card.get_style_context().add_class("stats-card")
        card.set_hexpand(True)

        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("stats-card-label")
        lbl.set_halign(Gtk.Align.CENTER)

        val = Gtk.Label(label=value)
        val.get_style_context().add_class("stats-card-value")
        val.set_halign(Gtk.Align.CENTER)

        card.pack_start(lbl, False, False, 0)
        card.pack_start(val, False, False, 0)
        parent.pack_start(card, True, True, 0)
        return val

    # ── Update ────────────────────────────────────────────────────────────────

    def _update(self) -> bool:
        now = time.monotonic()
        dt  = max(now - self._prev_t, 0.001)
        self._prev_t = now

        # CPU
        curr_cpu = _cpu_times()
        pcts = _calc_pct(self._prev_cpu, curr_cpu)
        self._prev_cpu = curr_cpu

        self._set_bar(self._cpu_bar, self._cpu_val, pcts.get("cpu", 0.0))

        cores = sorted(k for k in pcts if k.startswith("cpu") and k != "cpu")
        if len(cores) != len(self._core_bars):
            self._rebuild_cores(cores, pcts)
        else:
            for i, key in enumerate(cores):
                self._set_bar(self._core_bars[i], self._core_vals[i], pcts.get(key, 0.0))

        # Temp
        t = _temp()
        if t is not None:
            self._temp_val.set_text(f"{t:.0f} °C")
            ctx = self._temp_val.get_style_context()
            for c in ("temp-hot", "temp-warm"):
                ctx.remove_class(c)
            if t >= 85:
                ctx.add_class("temp-hot")
            elif t >= 70:
                ctx.add_class("temp-warm")
        else:
            self._temp_row.hide()

        # Memory
        used, total, pct = _mem()
        self._set_bar(self._ram_bar, self._ram_val, float(pct))
        self._ram_detail.set_text(f"{used:,} MB  /  {total:,} MB")

        # Network
        curr_net = _net_bytes()
        rx_r = max((curr_net[0] - self._prev_net[0]) / dt, 0)
        tx_r = max((curr_net[1] - self._prev_net[1]) / dt, 0)
        self._prev_net = curr_net
        self._net_rx.set_text(_fmt_rate(rx_r))
        self._net_tx.set_text(_fmt_rate(tx_r))

        # Disk
        curr_disk = _disk_bytes()
        r_r = max((curr_disk[0] - self._prev_disk[0]) / dt, 0)
        w_r = max((curr_disk[1] - self._prev_disk[1]) / dt, 0)
        self._prev_disk = curr_disk
        self._disk_r.set_text(_fmt_rate(r_r))
        self._disk_w.set_text(_fmt_rate(w_r))

        # Misc
        self._proc_val.set_text(str(_proc_count()))
        self._uptime_lbl.set_text(f"up {_uptime()}")

        return True

    def _set_bar(self, bar: Gtk.ProgressBar, val: Gtk.Label, pct: float):
        bar.set_fraction(pct / 100.0)
        val.set_text(f"{pct:.0f}%")
        ctx = bar.get_style_context()
        ctx.remove_class("bar-warn")
        ctx.remove_class("bar-crit")
        if pct >= 85:
            ctx.add_class("bar-crit")
        elif pct >= 60:
            ctx.add_class("bar-warn")

    def _rebuild_cores(self, cores: list, pcts: dict):
        for ch in self._cores_box.get_children():
            self._cores_box.remove(ch)
        self._core_bars.clear()
        self._core_vals.clear()

        for key in cores:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            row.set_margin_bottom(3)

            lbl = Gtk.Label(label=key.replace("cpu", "Core "))
            lbl.get_style_context().add_class("stats-core-label")
            lbl.set_width_chars(8)
            lbl.set_halign(Gtk.Align.START)

            bar = Gtk.ProgressBar()
            bar.get_style_context().add_class("stats-bar")
            bar.get_style_context().add_class("stats-bar-sm")
            bar.set_hexpand(True)

            val = Gtk.Label(label="0%")
            val.get_style_context().add_class("stats-core-val")
            val.set_width_chars(4)
            val.set_halign(Gtk.Align.END)

            pct = pcts.get(key, 0.0)
            bar.set_fraction(pct / 100.0)
            val.set_text(f"{pct:.0f}%")

            row.pack_start(lbl, False, False, 0)
            row.pack_start(bar, True, True, 0)
            row.pack_end(val, False, False, 0)
            self._cores_box.pack_start(row, False, False, 0)
            self._core_bars.append(bar)
            self._core_vals.append(val)

        self._cores_box.show_all()

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self._close()
            return True
        return False

    def _close(self):
        try:
            os.unlink(PIDFILE)
        except Exception:
            pass
        Gtk.main_quit()


# ── CSS ───────────────────────────────────────────────────────────────────────

_CSS = b"""
window.stats-window {
    background-color: rgba(10, 11, 15, 0.97);
    border: 1px solid rgba(0, 240, 200, 0.35);
    border-radius: 12px;
}
.stats-header {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 3px;
    color: #00f0c8;
}
.stats-section {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 2px;
    color: rgba(0, 240, 200, 0.55);
}
.stats-row-label {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 11px;
    color: rgba(232, 234, 240, 0.55);
}
.stats-row-value {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 12px;
    font-weight: 700;
    color: #e8eaf0;
}
.stats-core-label {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    color: rgba(232, 234, 240, 0.4);
}
.stats-core-val {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    color: rgba(232, 234, 240, 0.6);
}
.stats-meta {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    color: rgba(232, 234, 240, 0.38);
}
.stats-hint {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    letter-spacing: 1px;
    color: rgba(232, 234, 240, 0.28);
}
.stats-close-btn {
    font-size: 11px;
    color: rgba(232, 234, 240, 0.35);
    padding: 0 4px;
    background: transparent;
    border: none;
    box-shadow: none;
    min-height: 0;
    min-width: 0;
}
.stats-close-btn:hover { color: #ef4444; }
.stats-card {
    background-color: rgba(18, 20, 26, 0.85);
    border: 1px solid rgba(0, 240, 200, 0.1);
    border-radius: 7px;
    padding: 10px 8px;
    margin: 2px;
}
.stats-card-label {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 10px;
    letter-spacing: 1px;
    color: rgba(232, 234, 240, 0.45);
}
.stats-card-value {
    font-family: "JetBrains Mono", "Fira Mono", monospace;
    font-size: 14px;
    font-weight: 700;
    color: #e8eaf0;
    margin-top: 2px;
}
.stats-bar trough {
    background-color: rgba(18, 20, 26, 0.95);
    border-radius: 3px;
    min-height: 7px;
    border: none;
}
.stats-bar progress {
    background-color: #00f0c8;
    border-radius: 3px;
    min-height: 7px;
}
.stats-bar-sm trough  { min-height: 4px; border-radius: 2px; }
.stats-bar-sm progress { min-height: 4px; border-radius: 2px; }
.bar-warn progress { background-color: #f59e0b; }
.bar-crit progress { background-color: #ef4444; }
.temp-warm { color: #f59e0b; }
.temp-hot  { color: #ef4444; }
separator  { background-color: rgba(0, 240, 200, 0.12); min-height: 1px; }
"""


# ── Entry ─────────────────────────────────────────────────────────────────────

def main():
    if "DISPLAY" not in os.environ and "WAYLAND_DISPLAY" not in os.environ:
        sys.exit(1)

    # Toggle: kill existing instance if running
    try:
        with open(PIDFILE) as f:
            old = int(f.read().strip())
        os.kill(old, signal.SIGTERM)
        try:
            os.unlink(PIDFILE)
        except Exception:
            pass
        sys.exit(0)
    except (FileNotFoundError, ProcessLookupError, ValueError, PermissionError):
        pass

    try:
        with open(PIDFILE, "w") as f:
            f.write(str(os.getpid()))
    except Exception:
        pass

    provider = Gtk.CssProvider()
    provider.load_from_data(_CSS)
    screen = Gdk.Screen.get_default()
    Gtk.StyleContext.add_provider_for_screen(
        screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )

    win = StatsPopup()

    def _on_destroy(_w):
        try:
            os.unlink(PIDFILE)
        except Exception:
            pass
        Gtk.main_quit()

    win.connect("destroy", _on_destroy)
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
