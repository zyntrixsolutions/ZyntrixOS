#!/usr/bin/env python3
"""
ZyntrixOS Store.

Unified app manager for ZyntrixOS. Browse a curated catalogue of
ready-to-use applications and install from four sources without
leaving the window:

    * APT     — Debian packages (primary)
    * Flatpak — Flathub (sandboxed GUI apps)
    * Snap    — snapcraft.io (when snapd is running)
    * AppImage— single-file apps from user-provided URLs

Design:
    * No terminal handoff — every install/remove runs inside the store
      window with a live log, spinner, and result badge. The user stays
      in one place.
    * pkexec is used for root-requiring operations; the polkit agent
      started by hlwm autostart will prompt. No sudo-in-terminal.
    * The curated catalogue lives in shell/catalog.json so non-devs can
      extend it without touching Python.
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")

import json
import os
import shutil
import subprocess
import threading
from typing import Callable, Optional

# Probed once at startup — backends don't appear/disappear during a session
_HAS_SNAP: bool = shutil.which("snap") is not None
_HAS_FLATPAK: bool = shutil.which("flatpak") is not None
# Limit concurrent dpkg/flatpak/snap probes to avoid thrashing at card load
_CHECK_SEM = threading.Semaphore(6)

from gi.repository import Gtk, GLib, GdkPixbuf, Gdk, Pango


SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
CATALOG_PATH = os.path.join(SHELL_DIR, "catalog.json")
WINDOW_W, WINDOW_H = 1100, 720


# ═════════════════════════════════════════════════════════════════════════════
# Backend helpers
# ═════════════════════════════════════════════════════════════════════════════


# ── Installed-state probes ──────────────────────────────────────────────────
def is_apt_installed(pkg: str) -> bool:
    try:
        r = subprocess.run(
            ["dpkg-query", "-W", "--showformat=${Status}", pkg],
            capture_output=True, text=True, timeout=5,
        )
        return "install ok installed" in r.stdout
    except Exception:
        return False


def is_snap_installed(pkg: str) -> bool:
    try:
        r = subprocess.run(
            ["snap", "list", pkg],
            capture_output=True, text=True, timeout=5,
        )
        return r.returncode == 0 and pkg in r.stdout
    except Exception:
        return False


def is_flatpak_installed(app_id: str) -> bool:
    try:
        r = subprocess.run(
            ["flatpak", "info", app_id],
            capture_output=True, text=True, timeout=5,
        )
        return r.returncode == 0
    except Exception:
        return False


# ── Installed lists ─────────────────────────────────────────────────────────
def list_apt_installed() -> list[dict]:
    apps: list[dict] = []
    try:
        out = subprocess.check_output(
            ["dpkg-query", "-W",
             "--showformat=${Package}\t${Status}\t${Version}\n"],
            stderr=subprocess.DEVNULL, text=True, timeout=10,
        )
        for line in out.splitlines():
            parts = line.split("\t")
            if len(parts) >= 3 and "installed" in parts[1]:
                apps.append({
                    "source": "apt",
                    "name": parts[0],
                    "id": parts[0],
                    "version": parts[2],
                    "description": "",
                })
    except Exception:
        pass
    return apps


def list_flatpak_installed() -> list[dict]:
    if not _HAS_FLATPAK:
        return []
    try:
        out = subprocess.check_output(
            ["flatpak", "list", "--app",
             "--columns=application,name,version"],
            stderr=subprocess.DEVNULL, text=True, timeout=10,
        )
        apps = []
        for line in out.splitlines():
            parts = line.split("\t")
            if len(parts) >= 2:
                apps.append({
                    "source": "flatpak",
                    "id": parts[0],
                    "name": parts[1] or parts[0],
                    "version": parts[2] if len(parts) > 2 else "",
                    "description": "",
                })
        return apps
    except Exception:
        return []


def list_snap_installed() -> list[dict]:
    if not _HAS_SNAP:
        return []
    try:
        out = subprocess.check_output(
            ["snap", "list", "--unicode=never"],
            stderr=subprocess.DEVNULL, text=True, timeout=10,
        )
        apps = []
        for line in out.splitlines()[1:]:
            parts = line.split()
            if parts:
                apps.append({
                    "source": "snap",
                    "id": parts[0],
                    "name": parts[0],
                    "version": parts[1] if len(parts) > 1 else "",
                    "description": "",
                })
        return apps
    except Exception:
        return []


# ── Search ──────────────────────────────────────────────────────────────────
def search_apt(query: str) -> list[dict]:
    if not query:
        return []
    try:
        out = subprocess.check_output(
            ["apt-cache", "search", "--names-only", query],
            stderr=subprocess.DEVNULL, text=True, timeout=12,
        )
        results = []
        for line in out.splitlines()[:80]:
            if " - " in line:
                name, desc = line.split(" - ", 1)
                results.append({
                    "source": "apt",
                    "name": name.strip(),
                    "id": name.strip(),
                    "version": "",
                    "description": desc.strip(),
                })
        return results
    except Exception:
        return []


def search_flatpak(query: str) -> list[dict]:
    if not _HAS_FLATPAK or not query:
        return []
    try:
        out = subprocess.check_output(
            ["flatpak", "search", "--columns=application,name,description",
             query],
            stderr=subprocess.DEVNULL, text=True, timeout=15,
        )
        results = []
        for line in out.splitlines():
            parts = line.split("\t")
            if len(parts) >= 2 and parts[0] and parts[0] != "Application ID":
                results.append({
                    "source": "flatpak",
                    "id": parts[0],
                    "name": parts[1] or parts[0],
                    "version": "",
                    "description": parts[2] if len(parts) > 2 else "",
                })
        return results[:80]
    except Exception:
        return []


def search_snap(query: str) -> list[dict]:
    if not _HAS_SNAP or not query:
        return []
    try:
        out = subprocess.check_output(
            ["snap", "find", "--narrow", query],
            stderr=subprocess.DEVNULL, text=True, timeout=15,
        )
        results = []
        for line in out.splitlines()[1:]:
            parts = line.split(maxsplit=4)
            if len(parts) >= 2:
                results.append({
                    "source": "snap",
                    "id": parts[0],
                    "name": parts[0],
                    "version": parts[1],
                    "description": parts[4] if len(parts) > 4 else "",
                })
        return results[:80]
    except Exception:
        return []


# ── Install / remove dispatch ───────────────────────────────────────────────
def install_cmd(app: dict) -> list[str]:
    src = app["source"]
    ident = app["id"]
    if src == "apt":
        return ["pkexec", "apt-get", "install", "-y", ident]
    if src == "flatpak":
        # User-level install avoids pkexec entirely.
        return ["flatpak", "install", "-y", "--user", "flathub", ident]
    if src == "snap":
        return ["pkexec", "snap", "install", ident]
    if src == "appimage":
        # Download URL + chmod+x into ~/.local/bin. Handled by download helper.
        return []
    raise ValueError(f"unknown source: {src}")


def remove_cmd(app: dict) -> list[str]:
    src = app["source"]
    ident = app["id"]
    if src == "apt":
        return ["pkexec", "apt-get", "purge", "-y", ident]
    if src == "flatpak":
        return ["flatpak", "uninstall", "-y", "--user", ident]
    if src == "snap":
        return ["pkexec", "snap", "remove", ident]
    if src == "appimage":
        return []
    raise ValueError(f"unknown source: {src}")


# ═════════════════════════════════════════════════════════════════════════════
# Curated catalogue
# ═════════════════════════════════════════════════════════════════════════════
_FALLBACK_CATALOG: list[dict] = [
    # category, name, description, installs (list of dicts tried in order)
    {"category": "Browsers", "name": "Firefox", "icon": "firefox-esr",
     "description": "Mozilla Firefox ESR web browser.",
     "installs": [{"source": "apt", "id": "firefox-esr"}]},
    {"category": "Browsers", "name": "Chromium", "icon": "chromium",
     "description": "Open-source Chromium browser.",
     "installs": [{"source": "apt", "id": "chromium"},
                  {"source": "flatpak", "id": "org.chromium.Chromium"}]},
    {"category": "Browsers", "name": "Brave", "icon": "brave-browser",
     "description": "Privacy-focused browser built on Chromium.",
     "installs": [{"source": "flatpak", "id": "com.brave.Browser"}]},
    {"category": "Browsers", "name": "LibreWolf", "icon": "web-browser",
     "description": "Hardened, tracker-free Firefox fork.",
     "installs": [{"source": "flatpak", "id": "io.gitlab.librewolf-community"}]},

    {"category": "Editors", "name": "VSCodium", "icon": "code",
     "description": "Telemetry-free build of VS Code.",
     "installs": [{"source": "apt", "id": "codium"}]},
    {"category": "Editors", "name": "Neovim", "icon": "utilities-terminal",
     "description": "Hyperextensible Vim-based editor.",
     "installs": [{"source": "apt", "id": "neovim"}]},
    {"category": "Editors", "name": "Sublime Text", "icon": "accessories-text-editor",
     "description": "Fast multi-language code editor.",
     "installs": [{"source": "flatpak", "id": "com.sublimetext.three"}]},
    {"category": "Editors", "name": "Geany", "icon": "geany",
     "description": "Lightweight IDE.",
     "installs": [{"source": "apt", "id": "geany"}]},

    {"category": "Terminals", "name": "Foot", "icon": "utilities-terminal",
     "description": "Fast Wayland-first terminal (also works on X11).",
     "installs": [{"source": "apt", "id": "foot"}]},
    {"category": "Terminals", "name": "Alacritty", "icon": "utilities-terminal",
     "description": "GPU-accelerated terminal.",
     "installs": [{"source": "apt", "id": "alacritty"}]},
    {"category": "Terminals", "name": "Kitty", "icon": "utilities-terminal",
     "description": "Fast, featureful terminal.",
     "installs": [{"source": "apt", "id": "kitty"}]},
    {"category": "Terminals", "name": "tmux", "icon": "utilities-terminal",
     "description": "Terminal multiplexer.",
     "installs": [{"source": "apt", "id": "tmux"}]},

    {"category": "Dev", "name": "Git", "icon": "vcs-normal",
     "description": "Distributed version control.",
     "installs": [{"source": "apt", "id": "git"}]},
    {"category": "Dev", "name": "Docker", "icon": "applications-development",
     "description": "Container runtime (docker.io).",
     "installs": [{"source": "apt", "id": "docker.io"}]},
    {"category": "Dev", "name": "Node.js", "icon": "applications-development",
     "description": "JavaScript runtime.",
     "installs": [{"source": "apt", "id": "nodejs"}]},
    {"category": "Dev", "name": "Python venv", "icon": "applications-development",
     "description": "Create isolated Python environments.",
     "installs": [{"source": "apt", "id": "python3-venv"}]},
    {"category": "Dev", "name": "Postman", "icon": "applications-development",
     "description": "API client.",
     "installs": [{"source": "flatpak", "id": "com.getpostman.Postman"}]},

    {"category": "AI", "name": "Ollama", "icon": "applications-science",
     "description": "Local LLM runner (installs via official script).",
     "installs": [{"source": "script",
                   "url": "https://ollama.com/install.sh"}]},

    {"category": "Media", "name": "VLC", "icon": "vlc",
     "description": "Plays every audio and video format.",
     "installs": [{"source": "apt", "id": "vlc"},
                  {"source": "flatpak", "id": "org.videolan.VLC"}]},
    {"category": "Media", "name": "mpv", "icon": "mpv",
     "description": "Minimalist video player.",
     "installs": [{"source": "apt", "id": "mpv"}]},
    {"category": "Media", "name": "OBS Studio", "icon": "com.obsproject.Studio",
     "description": "Live streaming and screen recording.",
     "installs": [{"source": "flatpak", "id": "com.obsproject.Studio"}]},
    {"category": "Media", "name": "Spotify", "icon": "spotify",
     "description": "Music streaming.",
     "installs": [{"source": "flatpak", "id": "com.spotify.Client"}]},

    {"category": "Chat", "name": "Signal", "icon": "signal-desktop",
     "description": "Encrypted messenger.",
     "installs": [{"source": "flatpak", "id": "org.signal.Signal"}]},
    {"category": "Chat", "name": "Telegram", "icon": "telegram",
     "description": "Cross-device messenger.",
     "installs": [{"source": "flatpak", "id": "org.telegram.desktop"}]},
    {"category": "Chat", "name": "Discord", "icon": "discord",
     "description": "Voice and text chat.",
     "installs": [{"source": "flatpak", "id": "com.discordapp.Discord"}]},
    {"category": "Chat", "name": "Element", "icon": "element",
     "description": "Matrix client.",
     "installs": [{"source": "flatpak", "id": "im.riot.Riot"}]},

    {"category": "Office", "name": "LibreOffice", "icon": "libreoffice-main",
     "description": "Full office suite.",
     "installs": [{"source": "flatpak", "id": "org.libreoffice.LibreOffice"}]},
    {"category": "Office", "name": "Obsidian", "icon": "obsidian",
     "description": "Markdown knowledge base.",
     "installs": [{"source": "flatpak", "id": "md.obsidian.Obsidian"}]},
    {"category": "Office", "name": "Zathura PDF", "icon": "application-pdf",
     "description": "Keyboard-driven PDF viewer.",
     "installs": [{"source": "apt", "id": "zathura"}]},

    {"category": "Graphics", "name": "GIMP", "icon": "gimp",
     "description": "Image editor.",
     "installs": [{"source": "flatpak", "id": "org.gimp.GIMP"},
                  {"source": "apt", "id": "gimp"}]},
    {"category": "Graphics", "name": "Inkscape", "icon": "inkscape",
     "description": "Vector graphics.",
     "installs": [{"source": "flatpak", "id": "org.inkscape.Inkscape"}]},
    {"category": "Graphics", "name": "Krita", "icon": "krita",
     "description": "Digital painting.",
     "installs": [{"source": "flatpak", "id": "org.kde.krita"}]},

    {"category": "System", "name": "htop", "icon": "utilities-system-monitor",
     "description": "Interactive process viewer.",
     "installs": [{"source": "apt", "id": "htop"}]},
    {"category": "System", "name": "btop", "icon": "utilities-system-monitor",
     "description": "Modern resource monitor.",
     "installs": [{"source": "apt", "id": "btop"}]},
    {"category": "System", "name": "Flatpak runtime", "icon": "system-software-install",
     "description": "Install Flatpak support + Flathub remote.",
     "installs": [{"source": "meta", "id": "flatpak-setup"}]},
    {"category": "System", "name": "Snap runtime", "icon": "system-software-install",
     "description": "Install snapd.",
     "installs": [{"source": "apt", "id": "snapd"}]},
]


def load_catalog() -> list[dict]:
    """Read shell/catalog.json; fall back to the built-in list if missing."""
    try:
        with open(CATALOG_PATH) as fh:
            data = json.load(fh)
            if isinstance(data, list):
                return data
    except Exception:
        pass
    return _FALLBACK_CATALOG


# ═════════════════════════════════════════════════════════════════════════════
# Job runner — streams stdout/stderr into the GUI
# ═════════════════════════════════════════════════════════════════════════════
class Job:
    """A single install/remove/download operation with a live log callback."""

    def __init__(
        self,
        label: str,
        argv: list[str],
        on_line: Callable[[str], None],
        on_done: Callable[[int], None],
    ):
        self.label = label
        self.argv = argv
        self._on_line = on_line
        self._on_done = on_done
        self._thread: Optional[threading.Thread] = None
        self._proc: Optional[subprocess.Popen] = None

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _emit(self, line: str) -> None:
        GLib.idle_add(self._on_line, line.rstrip())

    def _run(self) -> None:
        self._emit(f"$ {' '.join(self.argv)}")
        try:
            self._proc = subprocess.Popen(
                self.argv,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
            )
        except Exception as exc:
            self._emit(f"[error] spawn failed: {exc}")
            GLib.idle_add(self._on_done, 127)
            return

        assert self._proc.stdout is not None
        for line in self._proc.stdout:
            self._emit(line)
        self._proc.wait()
        self._emit(f"\n[exit {self._proc.returncode}]")
        GLib.idle_add(self._on_done, self._proc.returncode or 0)


def _is_installed_entry(entry: dict) -> bool:
    """Check whether any install descriptor in an entry is currently installed.
    Avoids constructing an AppCard widget just for the installed-state probe."""
    for inst in entry.get("installs", []):
        src, ident = inst["source"], inst.get("id", "")
        if src == "apt" and is_apt_installed(ident):
            return True
        if src == "flatpak" and is_flatpak_installed(ident):
            return True
        if src == "snap" and is_snap_installed(ident):
            return True
    return False


# ═════════════════════════════════════════════════════════════════════════════
# Widgets
# ═════════════════════════════════════════════════════════════════════════════
class AppCard(Gtk.Box):
    """Single catalogue entry card."""

    def __init__(self, entry: dict, on_action: Callable[[dict, dict, str], None]):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        self.entry = entry
        self._on_action = on_action
        self.get_style_context().add_class("store-card")
        self.set_margin_top(6)
        self.set_margin_bottom(6)
        self.set_margin_start(12)
        self.set_margin_end(12)

        # Icon
        icon = Gtk.Image()
        icon.set_from_icon_name(entry.get("icon", "application-x-executable"),
                                Gtk.IconSize.DIALOG)
        icon.set_pixel_size(48)
        icon.set_margin_start(12)
        icon.set_margin_top(12)
        icon.set_margin_bottom(12)
        self.pack_start(icon, False, False, 0)

        # Text
        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info.set_margin_top(10)
        info.set_margin_bottom(10)
        name = Gtk.Label()
        name.set_markup(f"<b>{GLib.markup_escape_text(entry['name'])}</b>  "
                        f"<span alpha='70%'>{GLib.markup_escape_text(entry.get('category',''))}</span>")
        name.set_halign(Gtk.Align.START)
        info.pack_start(name, False, False, 0)

        desc = Gtk.Label(label=entry.get("description", ""))
        desc.set_halign(Gtk.Align.START)
        desc.set_ellipsize(Pango.EllipsizeMode.END)
        desc.set_line_wrap(False)
        desc.get_style_context().add_class("store-card-desc")
        info.pack_start(desc, False, False, 0)

        # Source badges
        badges = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        for inst in entry.get("installs", []):
            b = Gtk.Label(label=inst["source"].upper())
            b.get_style_context().add_class("store-source-badge")
            b.get_style_context().add_class(f"store-source-{inst['source']}")
            badges.pack_start(b, False, False, 0)
        info.pack_start(badges, False, False, 0)

        self.pack_start(info, True, True, 0)

        # Action button
        self._status = Gtk.Label(label="")
        self._status.get_style_context().add_class("store-card-status")
        self._status.set_halign(Gtk.Align.END)
        self.pack_start(self._status, False, False, 0)

        self._btn = Gtk.Button(label="Install")
        self._btn.get_style_context().add_class("suggested-action")
        self._btn.set_valign(Gtk.Align.CENTER)
        self._btn.set_margin_end(12)
        self._btn.connect("clicked", self._on_click)
        self.pack_start(self._btn, False, False, 0)

        self._installed: Optional[dict] = None
        self._refresh_installed()

    # ------------------------------------------------------------------
    def _first_available(self) -> Optional[dict]:
        """Pick the first install descriptor whose backend is usable now."""
        for inst in self.entry.get("installs", []):
            src = inst["source"]
            if src == "apt":
                return inst
            if src == "flatpak" and _HAS_FLATPAK:
                return inst
            if src == "snap" and _HAS_SNAP:
                return inst
            if src == "script":
                return inst
            if src == "meta":
                return inst
        installs = self.entry.get("installs", [])
        return installs[0] if installs else None

    def _is_installed(self) -> Optional[dict]:
        for inst in self.entry.get("installs", []):
            src = inst["source"]
            ident = inst.get("id", "")  # script/appimage entries have no 'id'
            if not ident:
                continue
            if src == "apt" and is_apt_installed(ident):
                return inst
            if src == "flatpak" and is_flatpak_installed(ident):
                return inst
            if src == "snap" and is_snap_installed(ident):
                return inst
        return None

    def _refresh_installed(self) -> None:
        """Show a placeholder immediately then probe installed state off-thread."""
        inst = self._first_available()
        if inst is None:
            self._btn.set_label("—")
            self._btn.set_sensitive(False)
            self._status.set_text("unavailable")
        else:
            self._btn.set_label("\u2026")  # ellipsis while checking
            self._btn.set_sensitive(False)
            self._status.set_text("")
        threading.Thread(target=self._check_installed_bg, daemon=True,
                         name="card-check").start()

    def _check_installed_bg(self) -> None:
        with _CHECK_SEM:
            found = self._is_installed()
        GLib.idle_add(self._apply_installed, found)

    def _apply_installed(self, found: Optional[dict]) -> bool:
        if found:
            self._installed = found
            self._btn.set_label("Remove")
            self._btn.set_sensitive(True)
            self._status.set_text(f"\u2713 installed via {found['source']}")
        else:
            self._installed = None
            inst = self._first_available()
            if inst is None:
                self._btn.set_label("—")
                self._btn.set_sensitive(False)
                self._status.set_text("unavailable")
            else:
                self._btn.set_label(f"Install \u00b7 {inst['source']}")
                self._btn.set_sensitive(True)
                self._status.set_text("")
        return False

    def _on_click(self, _b) -> None:
        if self._installed:
            self._on_action(self.entry, self._installed, "remove")
        else:
            inst = self._first_available()
            if inst:
                self._on_action(self.entry, inst, "install")

    def after_job(self) -> None:
        self._refresh_installed()


# ═════════════════════════════════════════════════════════════════════════════
# Main window
# ═════════════════════════════════════════════════════════════════════════════
class StoreWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS Store")
        self.set_default_size(WINDOW_W, WINDOW_H)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.get_style_context().add_class("store-window")

        self._catalog = load_catalog()
        self._current_card: Optional[AppCard] = None

        self._apply_css()

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # Header
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.get_style_context().add_class("store-header")
        header.set_margin_start(18)
        header.set_margin_end(18)
        header.set_margin_top(14)
        header.set_margin_bottom(10)

        title = Gtk.Label()
        title.set_markup("<b>ZYNTRIX STORE</b>")
        title.get_style_context().add_class("store-title")
        title.set_halign(Gtk.Align.START)
        header.pack_start(title, False, False, 0)

        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("Search catalogue + APT + Flatpak + Snap…")
        self._search.set_size_request(420, -1)
        self._search.connect("search-changed", lambda _e: self._schedule_refresh())
        header.pack_end(self._search, False, False, 0)

        root.pack_start(header, False, False, 0)
        root.pack_start(Gtk.Separator(), False, False, 0)

        # Main body: side categories + list
        body = Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL)
        body.set_position(200)

        self._category_list = Gtk.ListBox()
        self._category_list.get_style_context().add_class("store-categories")
        self._category_list.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self._category_list.connect("row-selected",
                                    lambda *_: self._schedule_refresh())
        cat_sw = Gtk.ScrolledWindow()
        cat_sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        cat_sw.add(self._category_list)
        body.pack1(cat_sw, resize=False, shrink=False)

        # Right side: card list + bottom log pane
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        self._card_list = Gtk.ListBox()
        self._card_list.set_selection_mode(Gtk.SelectionMode.NONE)
        card_sw = Gtk.ScrolledWindow()
        card_sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        card_sw.set_vexpand(True)
        card_sw.add(self._card_list)
        right.pack_start(card_sw, True, True, 0)

        # Bottom log pane (hidden until a job starts)
        self._log_frame = Gtk.Frame()
        self._log_frame.set_margin_start(12)
        self._log_frame.set_margin_end(12)
        self._log_frame.set_margin_top(8)
        self._log_frame.set_margin_bottom(8)
        self._log_frame.get_style_context().add_class("store-log-frame")
        self._log_frame.set_no_show_all(True)

        log_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        log_header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        log_header.set_margin_start(10)
        log_header.set_margin_end(10)
        log_header.set_margin_top(6)
        log_header.set_margin_bottom(6)
        self._spinner = Gtk.Spinner()
        self._job_label = Gtk.Label(label="")
        self._job_label.set_halign(Gtk.Align.START)
        self._job_label.set_hexpand(True)
        log_header.pack_start(self._spinner, False, False, 0)
        log_header.pack_start(self._job_label, True, True, 0)

        close_log = Gtk.Button(label="Hide log")
        close_log.connect("clicked", lambda _b: self._log_frame.hide())
        log_header.pack_end(close_log, False, False, 0)
        log_vbox.pack_start(log_header, False, False, 0)

        self._log_view = Gtk.TextView()
        self._log_view.set_editable(False)
        self._log_view.set_monospace(True)
        self._log_view.set_cursor_visible(False)
        self._log_view.get_style_context().add_class("store-log")
        log_sw = Gtk.ScrolledWindow()
        log_sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        log_sw.set_size_request(-1, 180)
        log_sw.add(self._log_view)
        log_vbox.pack_start(log_sw, True, True, 0)

        self._log_frame.add(log_vbox)
        right.pack_start(self._log_frame, False, False, 0)

        body.pack2(right, resize=True, shrink=False)
        root.pack_start(body, True, True, 0)

        # Footer: always-on hint + status
        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        footer.set_margin_start(18)
        footer.set_margin_end(18)
        footer.set_margin_top(6)
        footer.set_margin_bottom(8)

        self._status_lbl = Gtk.Label(label="")
        self._status_lbl.set_halign(Gtk.Align.START)
        self._status_lbl.set_hexpand(True)
        footer.pack_start(self._status_lbl, True, True, 0)

        hint = Gtk.Label()
        hint.set_markup(
            "<b>↑↓</b> Navigate  <b>/</b> Search  <b>Enter</b> Install  <b>Esc</b> Close"
        )
        hint.get_style_context().add_class("store-hint")
        footer.pack_end(hint, False, False, 0)

        root.pack_start(Gtk.Separator(), False, False, 0)
        root.pack_start(footer, False, False, 0)

        self.add(root)

        self._populate_categories()
        GLib.idle_add(self._refresh_list)

        self.connect("key-press-event", self._on_key)
        self.connect("destroy", Gtk.main_quit)

    # ------------------------------------------------------------------
    def _apply_css(self) -> None:
        theme_css = os.path.join(SHELL_DIR, "theme.css")
        # The main shell theme already loaded its own CSS when opened as a
        # subprocess — but when run standalone we still want a dark look.
        try:
            with open(theme_css, "rb") as fh:
                base = fh.read()
        except Exception:
            return
        # Substitute the @tokens with defaults so this window looks okay
        # when launched as a separate process.
        subs = {
            b"@bg": b"#0a0b0f",
            b"@surface-hover": b"#1e2030",
            b"@surface": b"#12141a",
            b"@accent-dim": b"rgba(0,240,200,0.18)",
            b"@accent": b"#00f0c8",
            b"@border": b"#0a5f4f",
            b"@text-dim": b"#7a7f8a",
            b"@text": b"#e8eaf0",
        }
        css = base
        for k, v in subs.items():
            css = css.replace(k, v)
        provider = Gtk.CssProvider()
        try:
            provider.load_from_data(css)
            Gtk.StyleContext.add_provider_for_screen(
                Gdk.Screen.get_default(),
                provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _populate_categories(self) -> None:
        cats = ["All", "Installed"] + sorted({
            e.get("category", "Other") for e in self._catalog
        })
        for name in cats:
            row = Gtk.ListBoxRow()
            row._name = name  # type: ignore[attr-defined]
            lbl = Gtk.Label(label=name)
            lbl.set_halign(Gtk.Align.START)
            lbl.set_margin_start(14)
            lbl.set_margin_end(14)
            lbl.set_margin_top(8)
            lbl.set_margin_bottom(8)
            row.add(lbl)
            self._category_list.add(row)
        self._category_list.show_all()
        first = self._category_list.get_row_at_index(0)
        if first:
            self._category_list.select_row(first)

    def _current_category(self) -> str:
        row = self._category_list.get_selected_row()
        return getattr(row, "_name", "All") if row else "All"

    # ------------------------------------------------------------------
    def _schedule_refresh(self) -> None:
        # Debounce typing
        if getattr(self, "_refresh_src", None):
            GLib.source_remove(self._refresh_src)
        self._refresh_src = GLib.timeout_add(180, self._refresh_list_tick)

    def _refresh_list_tick(self) -> bool:
        self._refresh_src = None
        self._refresh_list()
        return False

    def _refresh_list(self) -> None:
        for c in self._card_list.get_children():
            self._card_list.remove(c)

        query = self._search.get_text().strip().lower()
        category = self._current_category()

        # Build candidate list (no subprocess calls here)
        entries: list[dict] = []
        for e in self._catalog:
            if category == "All":
                pass
            elif category == "Installed":
                pass  # checked in background below
            elif e.get("category") != category:
                continue
            if query and query not in (
                e["name"].lower() + " " + e.get("description", "").lower()
            ):
                continue
            entries.append(e)

        if category == "Installed":
            # Run subprocess checks off the main thread
            self._status_lbl.set_text("Checking installed apps…")
            candidates = list(entries)

            def _check_bg():
                found = [e for e in candidates if _is_installed_entry(e)]
                GLib.idle_add(self._populate_entries, found, query)

            threading.Thread(target=_check_bg, daemon=True,
                             name="store-installed").start()
            return

        # For APT / Flatpak / Snap also merge live search results as ad-hoc cards.
        if query and category in ("All",):
            entries += self._adhoc_from_search(query)

        self._populate_entries(entries, query)

    def _populate_entries(self, entries: list, query: str) -> bool:
        for c in self._card_list.get_children():
            self._card_list.remove(c)
        for e in entries[:200]:
            card = AppCard(e, self._run_action)
            row = Gtk.ListBoxRow()
            row.add(card)
            self._card_list.add(row)
        self._card_list.show_all()
        self._status_lbl.set_text(
            f"{len(entries)} app{'s' if len(entries) != 1 else ''}"
            + (f" matching “{query}”" if query else "")
        )
        return False

    def _adhoc_from_search(self, query: str) -> list[dict]:
        """Wrap raw apt/flatpak/snap search results as one-off cards."""
        out: list[dict] = []
        for r in search_apt(query)[:20]:
            out.append({
                "category": "APT search",
                "name": r["name"],
                "description": r["description"],
                "icon": "application-x-executable",
                "installs": [{"source": "apt", "id": r["id"]}],
            })
        if _HAS_FLATPAK:
            for r in search_flatpak(query)[:20]:
                out.append({
                    "category": "Flatpak search",
                    "name": r["name"],
                    "description": r["description"],
                    "icon": "application-x-executable",
                    "installs": [{"source": "flatpak", "id": r["id"]}],
                })
        if _HAS_SNAP:
            for r in search_snap(query)[:20]:
                out.append({
                    "category": "Snap search",
                    "name": r["name"],
                    "description": r["description"],
                    "icon": "application-x-executable",
                    "installs": [{"source": "snap", "id": r["id"]}],
                })
        return out

    # ------------------------------------------------------------------
    def _run_action(self, entry: dict, inst: dict, op: str) -> None:
        src = inst["source"]
        if src == "meta" and inst["id"] == "flatpak-setup":
            argv = ["pkexec", "bash", "-c",
                    "apt-get install -y flatpak && flatpak remote-add "
                    "--if-not-exists flathub "
                    "https://flathub.org/repo/flathub.flatpakrepo"]
            label = "Enable Flatpak + add Flathub"
        elif src == "script":
            url = inst.get("url", "")
            if not url:
                self._log("[error] script entry has no url")
                return
            argv = ["bash", "-c", f"curl -fsSL {url} | sh"]
            label = f"Run install script: {url}"
        elif op == "install":
            argv = install_cmd({"source": src, "id": inst["id"]})
            label = f"Install {entry['name']} via {src}"
        else:
            argv = remove_cmd({"source": src, "id": inst["id"]})
            label = f"Remove {entry['name']} via {src}"

        self._start_job(label, argv, entry)

    def _start_job(self, label: str, argv: list[str], entry: dict) -> None:
        self._log_frame.show()
        self._spinner.start()
        self._job_label.set_text(label)
        self._clear_log()
        self._log(f"• {label}")

        def on_line(line: str) -> None:
            self._log(line)

        def on_done(code: int) -> None:
            self._spinner.stop()
            suffix = "OK" if code == 0 else f"failed (exit {code})"
            self._job_label.set_text(f"{label} — {suffix}")
            self._refresh_list()  # re-check installed states

        Job(label, argv, on_line, on_done).start()

    def _log(self, line: str) -> None:
        buf = self._log_view.get_buffer()
        end = buf.get_end_iter()
        buf.insert(end, line + "\n")
        self._log_view.scroll_to_iter(buf.get_end_iter(), 0.0, False, 0.0, 0.0)

    def _clear_log(self) -> None:
        buf = self._log_view.get_buffer()
        buf.delete(buf.get_start_iter(), buf.get_end_iter())

    # ------------------------------------------------------------------
    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        k = event.keyval
        if k == Gdk.KEY_Escape:
            self.destroy()
            return True
        if k == Gdk.KEY_slash:
            self._search.grab_focus()
            return True
        return False


# ═════════════════════════════════════════════════════════════════════════════
def main() -> None:
    win = StoreWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
