#!/usr/bin/env python3
"""Shared GTK CSS loader for standalone Zyntrix windows."""

from __future__ import annotations

import os

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gtk

from tiles import load_config


CSS_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "theme.css")


def _darken(hex_color: str, factor: float = 0.6) -> str:
    h = (hex_color or "#000000").lstrip("#")
    if len(h) != 6:
        return hex_color or "#000000"
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return "#{:02x}{:02x}{:02x}".format(
        min(255, int(r * factor)),
        min(255, int(g * factor)),
        min(255, int(b * factor)),
    )


def _alpha(hex_color: str, alpha: float = 0.18) -> str:
    h = (hex_color or "#000000").lstrip("#")
    if len(h) != 6:
        return "rgba(0,0,0,0.18)"
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{alpha})"


def _build_css(theme: dict) -> bytes:
    with open(CSS_PATH, "r", encoding="utf-8") as handle:
        css = handle.read()
    replacements = {
        "@bg": theme["background"],
        "@surface-hover": _darken(theme["surface"], 1.4),
        "@surface": theme["surface"],
        "@accent-dim": _alpha(theme["accent"]),
        "@accent": theme["accent"],
        "@border": _darken(theme["accent"], 0.35),
        "@text-dim": _darken(theme["text"], 0.55),
        "@text": theme["text"],
    }
    for token, value in sorted(replacements.items(), key=lambda item: -len(item[0])):
        css = css.replace(token, value)
    return css.encode("utf-8")


def load_shared_css() -> None:
    _, theme = load_config()
    provider = Gtk.CssProvider()
    provider.load_from_data(_build_css(theme))
    screen = Gdk.Screen.get_default()
    if screen is None:
        return
    Gtk.StyleContext.add_provider_for_screen(
        screen,
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
    )
