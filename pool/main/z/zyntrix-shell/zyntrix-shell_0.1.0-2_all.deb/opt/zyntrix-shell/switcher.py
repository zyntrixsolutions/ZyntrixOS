#!/usr/bin/env python3
"""
ZyntrixOS Window Switcher.

A centered overlay listing all currently mapped top-level X11 windows,
reachable with Super+Tab / Alt+Tab from both the shell and any running
app (the latter via herbstluftwm keybinds that call:
    zyntrix-shell --switcher
). Arrow / Tab keys cycle, Enter activates, Esc cancels.

Design choices:
  * Pure wmctrl — no EWMH python deps, matches antiX base.
  * Shows window title + WM_CLASS badge so duplicates are distinguishable.
  * Falls back to the ZyntrixOS launcher if no other window exists.
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib

import os
import shlex
import shutil
import subprocess
import threading
import time
from typing import Callable, Optional

import appdb
import wm_control

# ── Module-level window-list cache ───────────────────────────────────────────
# Amortises the wmctrl startup cost across successive Alt+Tab presses.
# TTL is short (0.8 s) so the list reflects windows that open/close quickly.
# A lock guards the shared variables against concurrent background threads.
_win_cache:    list[dict] = []
_win_cache_ts: float      = 0.0
_WIN_CACHE_TTL: float     = 0.8
_win_cache_lock = threading.Lock()


def _get_cached_windows() -> list[dict]:
    """Return all windows (incl. shell) from cache, refreshing if stale."""
    global _win_cache, _win_cache_ts
    now = time.monotonic()
    with _win_cache_lock:
        if _win_cache and now - _win_cache_ts < _WIN_CACHE_TTL:
            return list(_win_cache)
    fresh = list_windows(include_shell=True)
    with _win_cache_lock:
        _win_cache    = fresh
        _win_cache_ts = now
    return fresh


def _invalidate_win_cache() -> None:
    global _win_cache_ts
    with _win_cache_lock:
        _win_cache_ts = 0.0

_WMCTRL: str = shutil.which("wmctrl") or ""
_HAS_HLWM: bool = bool(shutil.which("herbstclient"))

_SHELL_MARKERS = ("zyntrix-shell", "zyntrixos")


# ─────────────────────────────────────────────────────────────────────────────
def list_windows(include_shell: bool = False) -> list[dict]:
    """Return a list of top-level windows as dicts.

    Each entry: {wid, desktop, wclass, host, title}.
    Requires wmctrl; returns [] if unavailable.
    """
    if not _WMCTRL:
        return []
    try:
        out = subprocess.check_output(
            [_WMCTRL, "-lx"], text=True, timeout=2,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return []

    results: list[dict] = []
    for line in out.splitlines():
        # Format: <wid> <desktop> <wclass> <host> <title...>
        parts = line.split(None, 4)
        if len(parts) < 5:
            continue
        wid, desktop, wclass, host, title = parts
        low = (wclass + " " + title).lower()
        if not include_shell and any(m in low for m in _SHELL_MARKERS):
            continue
        results.append({
            "wid": wid,
            "desktop": desktop,
            "wclass": wclass,
            "host": host,
            "title": title or wclass,
        })
    return results


def activate_window(wid: str) -> None:
    """Raise + focus the given window id."""
    wm_control.activate_window(wid)


def _window_badge(wclass: str) -> str:
    """Return a readable app label from wmctrl's instance.class WM_CLASS."""
    parts = [p for p in (wclass or "").split(".") if p]
    raw = parts[-1] if parts else (wclass or "Window")
    raw = raw.replace("_", " ").replace("-", " ").strip()
    words = [
        word if word.isupper() else word[:1].upper() + word[1:].lower()
        for word in raw.split()
    ]
    return " ".join(words) or "Window"


def _is_hex_id(text: str) -> bool:
    """Check if text looks like a hex window ID (0x...)."""
    if not text:
        return False
    return text.strip().lower().startswith("0x") and len(text) >= 8


def _display_title(w: dict) -> str:
    """Return a user-friendly window title, avoiding hex IDs."""
    title = w.get("title", "")
    wclass = w.get("wclass", "")
    
    # If title is usable and not a hex ID, use it
    if title and not _is_hex_id(title) and len(title.strip()) > 0:
        return title
    
    # Fall back to window class name
    if wclass:
        badge = _window_badge(wclass)
        if badge and badge != "Window":
            return badge
    
    # Last resort
    return "Unknown Window"


# ─────────────────────────────────────────────────────────────────────────────
class WindowSwitcher(Gtk.Window):
    """Modal overlay: switch open windows and search+launch installed apps.

    The window skeleton is built synchronously so it appears on screen
    instantly; the wmctrl list fetch runs on a background thread and
    populates the list via GLib.idle_add once ready.
    """

    def __init__(
        self,
        on_close: Optional[Callable[[], None]] = None,
        transient_for: Optional[Gtk.Window] = None,
    ):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._on_close = on_close

        self.set_title("Windows")
        self.set_decorated(False)
        self.set_default_size(580, 500)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        if transient_for:
            self.set_transient_for(transient_for)
            self.set_modal(True)
        self.get_style_context().add_class("switcher-window")

        # Prewarm app database if not already ready
        appdb.prewarm()

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)

        # ── Header ──
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        header.set_margin_start(18)
        header.set_margin_end(18)
        header.set_margin_top(14)
        header.set_margin_bottom(10)

        title = Gtk.Label(label="WINDOWS")
        title.get_style_context().add_class("switcher-title")
        title.set_halign(Gtk.Align.START)

        self._count = Gtk.Label(label="scanning…")
        self._count.get_style_context().add_class("switcher-count")
        self._count.set_halign(Gtk.Align.END)
        self._count.set_hexpand(True)

        header.pack_start(title, False, False, 0)
        header.pack_start(self._count, True, True, 0)
        outer.pack_start(header, False, False, 0)

        sep0 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        outer.pack_start(sep0, False, False, 0)

        # ── Search entry ──
        search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        search_row.set_margin_start(18)
        search_row.set_margin_end(18)
        search_row.set_margin_top(10)
        search_row.set_margin_bottom(10)

        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("filter windows or search apps…")
        self._search.set_hexpand(True)
        self._search.get_style_context().add_class("switcher-search")
        self._search.connect("search-changed", self._on_search_changed)
        self._search.connect("key-press-event", self._on_search_key)
        search_row.pack_start(self._search, True, True, 0)
        outer.pack_start(search_row, False, False, 0)

        sep1 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        outer.pack_start(sep1, False, False, 0)

        # ── List ──
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_size_request(-1, 340)

        self._listbox = Gtk.ListBox()
        self._listbox.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self._listbox.connect("row-activated", self._on_row_activated)
        sw.add(self._listbox)
        outer.pack_start(sw, True, True, 0)

        # ── Footer hint ──
        sep2 = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        outer.pack_start(sep2, False, False, 0)

        hint = Gtk.Label(
            label=(
                "Tab/↓ Next   Enter Focus   Esc Cancel   "
                "Del Close   Ctrl+F Fullscreen   Ctrl+S Split   "
                "Ctrl+H Split↓   Type to filter / search apps"
            )
        )
        hint.get_style_context().add_class("switcher-hint")
        hint.set_margin_start(18)
        hint.set_margin_end(18)
        hint.set_margin_top(10)
        hint.set_margin_bottom(12)
        hint.set_halign(Gtk.Align.CENTER)
        outer.pack_start(hint, False, False, 0)

        self.add(outer)

        self.connect("key-press-event", self._on_key)
        self.connect("focus-out-event", self._on_focus_out)
        # Track when a row activation is in progress so focus-out doesn't
        # dismiss the window before the row-activated signal fires.
        self._activating: bool = False

        # Auto-focus search entry so typing immediately filters
        self.connect("show", lambda _: GLib.idle_add(self._search.grab_focus))

        # Fetch the window list off-thread so the overlay appears instantly
        # even on hardware where wmctrl takes 300+ ms to enumerate windows.
        threading.Thread(
            target=self._fetch_and_populate, daemon=True, name="switcher-list"
        ).start()

    # ------------------------------------------------------------------
    def _fetch_and_populate(self) -> None:
        """Background thread: get window list then push to GTK main thread."""
        windows = _get_cached_windows()
        GLib.idle_add(self._populate, "", windows)

    def _on_search_changed(self, entry: Gtk.SearchEntry) -> None:
        self._populate(entry.get_text().strip())

    def _on_search_key(self, _w, event: Gdk.EventKey) -> bool:
        k = event.keyval
        if k == Gdk.KEY_Escape:
            self._dismiss()
            return True
        if k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            row = self._listbox.get_selected_row()
            if row is not None:
                self._activate_row(row)
            return True
        if k == Gdk.KEY_Down:
            self._move(1)
            return True
        if k == Gdk.KEY_Up:
            self._move(-1)
            return True
        if k == Gdk.KEY_Tab:
            self._move(1)
            return True
        return False

    def _populate(self, query: str = "", _all_windows: list = None) -> None:
        for child in self._listbox.get_children():
            self._listbox.remove(child)

        if _all_windows is None:
            _all_windows = _get_cached_windows()
        windows = [
            w for w in _all_windows
            if not any(m in (w["wclass"]+w["title"]).lower() for m in _SHELL_MARKERS)
        ]
        q = query.lower()

        # Filter windows by query (title or class)
        if q:
            windows = [w for w in windows
                       if q in w["title"].lower() or q in w["wclass"].lower()]

        self._count.set_text(
            f"{len(windows)} open" if windows else ("no matches" if q else "no other windows")
        )

        if windows:
            for w in windows:
                self._listbox.add(self._make_win_row(w))
        elif not q:
            empty = Gtk.Label(
                label="No other windows open.\nType to search and launch an app."
            )
            empty.get_style_context().add_class("switcher-empty")
            empty.set_margin_top(28)
            empty.set_margin_bottom(12)
            row = Gtk.ListBoxRow()
            row.set_activatable(False)
            row.set_selectable(False)
            row.add(empty)
            self._listbox.add(row)

        # App search section (only when query is non-empty)
        if q:
            apps = appdb.search(q, limit=20)
            if apps:
                # Section header
                hdr_row = Gtk.ListBoxRow()
                hdr_row.set_activatable(False)
                hdr_row.set_selectable(False)
                hdr_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
                hdr_lbl = Gtk.Label(label="───  APPS  ")
                hdr_lbl.get_style_context().add_class("switcher-section-hdr")
                hdr_lbl.set_margin_start(18)
                hdr_lbl.set_margin_top(10)
                hdr_lbl.set_margin_bottom(6)
                hdr_lbl.set_halign(Gtk.Align.START)
                hdr_box.pack_start(hdr_lbl, False, False, 0)
                hdr_row.add(hdr_box)
                self._listbox.add(hdr_row)

                for app in apps:
                    self._listbox.add(self._make_app_row(app))

        self._listbox.show_all()

        # Select first selectable row
        for row in self._listbox.get_children():
            if isinstance(row, Gtk.ListBoxRow) and row.get_activatable():
                self._listbox.select_row(row)
                break

    def _make_win_row(self, w: dict) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row._win = w  # type: ignore[attr-defined]
        row.get_style_context().add_class("switcher-row")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        badge = Gtk.Label(label=_window_badge(w["wclass"])[:14].upper())
        badge.get_style_context().add_class("switcher-badge")
        badge.set_size_request(92, -1)
        badge.set_halign(Gtk.Align.START)

        title = Gtk.Label(label=_display_title(w))
        title.set_halign(Gtk.Align.START)
        title.set_ellipsize(3)
        title.set_hexpand(True)
        title.get_style_context().add_class("switcher-row-title")

        box.pack_start(badge, False, False, 0)
        box.pack_start(title, True, True, 0)
        row.add(box)
        return row

    def _make_app_row(self, app: dict) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row._app = app  # type: ignore[attr-defined]
        row.get_style_context().add_class("switcher-row")
        row.get_style_context().add_class("switcher-app-row")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(8)
        box.set_margin_bottom(8)

        badge = Gtk.Label(label="APP")
        badge.get_style_context().add_class("switcher-badge")
        badge.get_style_context().add_class("switcher-app-badge")
        badge.set_size_request(92, -1)
        badge.set_halign(Gtk.Align.START)

        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info_box.set_hexpand(True)

        name_lbl = Gtk.Label(label=app["name"])
        name_lbl.set_halign(Gtk.Align.START)
        name_lbl.set_ellipsize(3)
        name_lbl.get_style_context().add_class("switcher-row-title")
        info_box.pack_start(name_lbl, False, False, 0)

        if app.get("desc"):
            desc_lbl = Gtk.Label(label=app["desc"])
            desc_lbl.set_halign(Gtk.Align.START)
            desc_lbl.set_ellipsize(3)
            desc_lbl.get_style_context().add_class("switcher-app-desc")
            info_box.pack_start(desc_lbl, False, False, 0)

        box.pack_start(badge, False, False, 0)
        box.pack_start(info_box, True, True, 0)
        row.add(box)
        return row

    # ------------------------------------------------------------------
    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        k = event.keyval
        mods = event.state
        ctrl  = bool(mods & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(mods & Gdk.ModifierType.SHIFT_MASK)

        if k == Gdk.KEY_Escape:
            self._dismiss()
            return True
        if k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            row = self._listbox.get_selected_row()
            if row is not None:
                self._activate_row(row)
            return True
        if k == Gdk.KEY_Tab:
            self._move(1 if not shift else -1)
            return True
        if k == Gdk.KEY_ISO_Left_Tab:
            self._move(-1)
            return True
        if k == Gdk.KEY_Down:
            self._move(1)
            return True
        if k == Gdk.KEY_Up:
            self._move(-1)
            return True
        if k == Gdk.KEY_Delete:
            row = self._listbox.get_selected_row()
            if row and hasattr(row, "_win"):
                self._close_selected()
            return True
        # Ctrl+key WM shortcuts — require modifier so they never block typing
        if ctrl:
            if k == Gdk.KEY_f:
                self._wm_action_selected("fullscreen", "toggle")
                return True
            if k == Gdk.KEY_s:
                self._wm_action_selected("smart-split", "right")
                return True
            if k == Gdk.KEY_h:
                self._wm_action_selected("smart-split", "bottom")
                return True
            if k == Gdk.KEY_Delete or k == Gdk.KEY_w:
                row = self._listbox.get_selected_row()
                if row and hasattr(row, "_win"):
                    self._close_selected()
                return True
        # Printable characters always route to search entry so typing works
        # regardless of which child widget currently holds focus.
        if not ctrl and (
            (Gdk.KEY_a <= k <= Gdk.KEY_z)
            or (Gdk.KEY_A <= k <= Gdk.KEY_Z)
            or (Gdk.KEY_0 <= k <= Gdk.KEY_9)
            or k == Gdk.KEY_space
            or k == Gdk.KEY_BackSpace
        ):
            if k == Gdk.KEY_BackSpace:
                cur = self._search.get_text()
                if cur:
                    self._search.set_text(cur[:-1])
                    self._search.set_position(-1)
            else:
                char = chr(k) if k < 256 else ""
                if char:
                    self._search.set_text(self._search.get_text() + char)
                    self._search.set_position(-1)
            self._search.grab_focus()
            return True
        return False

    def _move(self, delta: int) -> None:
        rows = [r for r in self._listbox.get_children()
                if isinstance(r, Gtk.ListBoxRow) and r.get_activatable()
                and (hasattr(r, "_win") or hasattr(r, "_app"))]
        if not rows:
            return
        sel = self._listbox.get_selected_row()
        try:
            idx = rows.index(sel) if sel in rows else 0
        except ValueError:
            idx = 0
        idx = (idx + delta) % len(rows)
        self._listbox.select_row(rows[idx])
        rows[idx].grab_focus()

    def _on_row_activated(self, _lb, row: Gtk.ListBoxRow) -> None:
        self._activating = True
        self._activate_row(row)

    def _activate_row(self, row: Gtk.ListBoxRow) -> None:
        w = getattr(row, "_win", None)
        if w:
            self._hide_for_activation()
            activate_window(w["wid"])
            self._dismiss()
            return

        app = getattr(row, "_app", None)
        if app:
            try:
                cmd = shlex.split(app["exec"])
            except Exception:
                cmd = [app["exec"]]
            subprocess.Popen(cmd, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._dismiss()
            return

        self._dismiss()

    def _wm_action_selected(self, *hlwm_args: str) -> None:
        """Activate selected window then run a herbstclient command against it.

        The split/fullscreen command must execute *after* the WM has actually
        moved focus to the target window, otherwise it acts on the wrong frame.
        We activate first, dismiss the overlay, then run the hlwm command on a
        background thread that polls for focus confirmation before issuing it.
        """
        row = self._listbox.get_selected_row()
        w = getattr(row, "_win", None) if row else None
        target_wid = w["wid"] if w else None
        if target_wid:
            self._hide_for_activation()
            activate_window(target_wid)
        _invalidate_win_cache()
        self._dismiss()
        if target_wid and _HAS_HLWM and hlwm_args:
            threading.Thread(
                target=self._run_hlwm_after_focus,
                args=(target_wid, list(hlwm_args)),
                daemon=False,
                name="hlwm-action",
            ).start()

    def _run_hlwm_after_focus(self, target_wid: str, hlwm_args: list) -> None:
        """Background thread: wait up to 300 ms for the WM to focus the target
        window, then issue the herbstclient command."""
        for _ in range(3):
            time.sleep(0.1)
            try:
                focused = subprocess.check_output(
                    ["herbstclient", "get_attr", "clients.focus.winid"],
                    text=True, timeout=1, stderr=subprocess.DEVNULL,
                ).strip().lower()
                # wmctrl uses e.g. "0x01400003"; hlwm uses "0x1400003"
                # — normalise both to int for comparison.
                if focused and int(focused, 16) == int(target_wid, 16):
                    break
            except Exception:
                break
        if hlwm_args and hlwm_args[0] == "smart-split":
            wm_control.smart_split(hlwm_args[1] if len(hlwm_args) > 1 else "right")
            return
        try:
            subprocess.Popen(
                ["herbstclient"] + hlwm_args,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass

    def _hide_for_activation(self) -> None:
        """Unmap the overlay before asking the WM to focus another client."""
        try:
            self.hide()
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)
        except Exception:
            pass

    def _close_selected(self) -> None:
        row = self._listbox.get_selected_row()
        w = getattr(row, "_win", None) if row else None
        if not w or not _WMCTRL:
            return
        subprocess.Popen(
            [_WMCTRL, "-ic", w["wid"]], start_new_session=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        _invalidate_win_cache()
        GLib.timeout_add(250, self._refresh_once)

    def _refresh_once(self) -> bool:
        q = self._search.get_text().strip() if hasattr(self, "_search") else ""
        self._populate(q)
        return False

    def _on_focus_out(self, _w, _event) -> bool:
        """Only dismiss if focus has truly left the entire switcher hierarchy.

        80 ms was too short — a row click briefly moves focus to the row
        widget before row-activated fires, triggering a spurious dismiss.
        150 ms gives the row-activated signal time to complete.
        """
        if not self._activating:
            GLib.timeout_add(150, self._check_focus_dismiss)
        return False

    def _check_focus_dismiss(self) -> bool:
        # Don't dismiss if we're still handling a row activation
        if self._activating:
            return False
        try:
            visible = self.get_visible()
        except Exception:
            visible = False
        if not visible:
            return False
        if not self.is_active() and not self.has_toplevel_focus():
            self._dismiss()
        return False

    def _dismiss(self) -> None:
        if self._on_close:
            try:
                self._on_close()
            except Exception:
                pass
        self.destroy()


# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    """Standalone entry so hlwm / Alt+Tab can spawn the switcher without
    going through the full shell window."""
    # If no other window is open besides the shell, just raise the shell.
    wins = list_windows(include_shell=False)
    if not wins:
        # Try to raise the shell; otherwise spawn it.
        if shutil.which("zyntrix-toggle-launcher"):
            subprocess.Popen(
                ["zyntrix-toggle-launcher"], start_new_session=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
            return

    win = WindowSwitcher(on_close=Gtk.main_quit)
    win.show_all()
    GLib.idle_add(win.grab_focus)
    Gtk.main()


if __name__ == "__main__":
    main()
