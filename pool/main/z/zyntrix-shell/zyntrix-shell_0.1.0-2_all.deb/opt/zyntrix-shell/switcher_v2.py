#!/usr/bin/env python3
"""Enhanced event-driven window switcher for ZyntrixOS."""

from __future__ import annotations

import shlex
from pathlib import Path
from typing import Optional

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk

import appdb
from style import load_shared_css
from window_manager import WindowManagerClient, WindowState, _slugify
from window_snapshot import WindowSnapshotStore


class WindowSwitcherV2(Gtk.Window):
    def __init__(
        self,
        *,
        overview: bool = False,
        on_close=None,
        transient_for: Optional[Gtk.Window] = None,
    ) -> None:
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._overview = overview
        self._on_close = on_close
        self._transient_parent = transient_for
        self._client = WindowManagerClient()
        self._client.ensure_daemon()
        self._snapshot_store = WindowSnapshotStore(client=self._client, refresh_delay_ms=90)
        load_shared_css()
        self._all_windows: list[WindowState] = []
        self._window_rows: dict[str, Gtk.ListBoxRow] = {}
        self._section_rows: dict[str, Gtk.ListBoxRow] = {}
        self._app_section_row: Optional[Gtk.ListBoxRow] = None
        self._app_rows: list[Gtk.ListBoxRow] = []
        self._empty_row: Optional[Gtk.ListBoxRow] = None
        self._activating = False

        self.set_title("Overview" if overview else "Windows")
        self.set_decorated(False)
        self.set_default_size(920 if overview else 760, 640 if overview else 560)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        if transient_for:
            self.set_transient_for(transient_for)
            self.set_modal(True)
        self.get_style_context().add_class("switcher-window")
        self.get_style_context().add_class("switcher-v2-window")

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(outer)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        header.set_margin_start(18)
        header.set_margin_end(18)
        header.set_margin_top(14)
        header.set_margin_bottom(10)

        title = Gtk.Label(label="OVERVIEW" if overview else "WINDOWS")
        title.get_style_context().add_class("switcher-title")
        title.set_halign(Gtk.Align.START)

        self._count = Gtk.Label(label="0 open")
        self._count.get_style_context().add_class("switcher-count")
        self._count.set_hexpand(True)
        self._count.set_halign(Gtk.Align.END)

        header.pack_start(title, False, False, 0)
        header.pack_start(self._count, True, True, 0)
        outer.pack_start(header, False, False, 0)
        outer.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        search_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        search_row.set_margin_start(18)
        search_row.set_margin_end(18)
        search_row.set_margin_top(10)
        search_row.set_margin_bottom(10)

        self._search = Gtk.SearchEntry()
        self._search.set_placeholder_text("Search windows or apps...")
        self._search.get_style_context().add_class("switcher-search")
        self._search.set_hexpand(True)
        self._search.connect("search-changed", self._on_search_changed)
        self._search.connect("key-press-event", self._on_search_key)
        search_row.pack_start(self._search, True, True, 0)
        outer.pack_start(search_row, False, False, 0)
        outer.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        actions.set_margin_start(18)
        actions.set_margin_end(18)
        actions.set_margin_top(10)
        actions.set_margin_bottom(8)
        for label, cb in (
            ("Show Desktop", self._on_show_desktop),
            ("Minimize All", self._on_minimize_all),
            ("Close All", self._on_close_all),
        ):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("switcher-action-btn")
            btn.connect("clicked", cb)
            actions.pack_start(btn, False, False, 0)
        outer.pack_start(actions, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroller.set_hexpand(True)
        scroller.set_vexpand(True)

        self._listbox = Gtk.ListBox()
        self._listbox.set_selection_mode(Gtk.SelectionMode.BROWSE)
        self._listbox.connect("row-activated", self._on_row_activated)
        scroller.add(self._listbox)
        outer.pack_start(scroller, True, True, 0)

        outer.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 0)
        hint = Gtk.Label(
            label=(
                "[1-9] Focus  [-] Minimize  [u] Undock  [r] Redock  [x] Close  "
                "[Shift+1-9] Move to workspace"
            )
        )
        hint.get_style_context().add_class("switcher-hint")
        hint.set_margin_start(18)
        hint.set_margin_end(18)
        hint.set_margin_top(10)
        hint.set_margin_bottom(12)
        outer.pack_start(hint, False, False, 0)

        self.connect("key-press-event", self._on_key)
        self.connect("focus-out-event", self._on_focus_out)
        self.connect("show", self._on_show)
        self.connect("destroy", self._on_destroy)

        appdb.prewarm()
        self._snapshot_store.subscribe(self._on_snapshot_changed)

    # ------------------------------------------------------------------
    @staticmethod
    def _window_matches(state: WindowState, query: str) -> bool:
        if not query:
            return True
        return (
            query in state.title.lower()
            or query in state.wclass.lower()
            or query in state.label.lower()
            or query in state.app_id.lower()
        )

    def _windows(self) -> list[WindowState]:
        query = self._search.get_text().strip().lower() if hasattr(self, "_search") else ""
        return [state for state in self._all_windows if self._window_matches(state, query)]

    def _clear_listbox(self) -> None:
        for child in self._listbox.get_children():
            self._listbox.remove(child)
        self._window_rows = {}
        self._section_rows = {}
        self._app_rows = []
        self._app_section_row = None
        self._empty_row = None

    def _on_snapshot_changed(self, store: WindowSnapshotStore) -> None:
        self._all_windows = store.states
        self._rebuild_window_rows()
        self._refresh_query_view()

    def _rebuild_window_rows(self) -> None:
        self._clear_listbox()

        grouped = {
            "ACTIVE": [state for state in self._all_windows if state.state not in ("floating", "minimized")],
            "FLOATING": [state for state in self._all_windows if state.state == "floating"],
            "MINIMIZED": [state for state in self._all_windows if state.state == "minimized"],
        }
        for label in ("ACTIVE", "FLOATING", "MINIMIZED"):
            states = grouped[label]
            if not states:
                continue
            section = self._add_section(label)
            self._section_rows[label] = section
            for state in states:
                row = self._add_window_row(state)
                row._category = label  # type: ignore[attr-defined]
                self._window_rows[state.wid] = row

    def _refresh_query_view(self) -> None:
        windows = self._windows()
        self._count.set_text(f"{len(windows)} open" if windows else "0 open")

        query = self._search.get_text().strip()
        query_lc = query.lower()
        visible_by_category = {label: 0 for label in self._section_rows}
        visible_wids = {state.wid for state in windows}
        for wid, row in self._window_rows.items():
            if wid in visible_wids:
                category = getattr(row, "_category", "")
                if category in visible_by_category:
                    visible_by_category[category] += 1

        self._clear_app_rows()
        if query:
            apps = appdb.search(query, limit=12)
            if apps:
                self._app_section_row = self._add_section("APPS")
                for app in apps:
                    self._add_app_row(app)

        has_apps = bool(self._app_rows)
        has_windows = bool(visible_wids)
        self._set_empty_state(not has_windows and not has_apps, query_lc)

        self._listbox.show_all()
        for wid, row in self._window_rows.items():
            row.set_visible(wid in visible_wids)
        for label, row in self._section_rows.items():
            row.set_visible(visible_by_category.get(label, 0) > 0)
        self._select_first_visible()

    def _add_section(self, label: str) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.set_activatable(False)
        row.set_selectable(False)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(10)
        box.set_margin_bottom(4)
        lbl = Gtk.Label(label=label)
        lbl.get_style_context().add_class("switcher-section-hdr")
        lbl.set_halign(Gtk.Align.START)
        box.pack_start(lbl, False, False, 0)
        row.add(box)
        self._listbox.add(row)
        return row

    def _add_window_row(self, state: WindowState) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row._win = state  # type: ignore[attr-defined]
        row.get_style_context().add_class("switcher-row")
        row.get_style_context().add_class("switcher-v2-row")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        badge = Gtk.Label(label=(state.label or state.app_id or "APP")[:14].upper())
        badge.get_style_context().add_class("switcher-badge")
        badge.set_size_request(92, -1)
        box.pack_start(badge, False, False, 0)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info.set_hexpand(True)

        title = Gtk.Label(label=state.title or state.label or state.wid)
        title.get_style_context().add_class("switcher-row-title")
        title.set_halign(Gtk.Align.START)
        title.set_ellipsize(3)

        detail_bits = [
            (state.label or state.app_id or state.wclass or "Window"),
            f"Workspace {state.workspace or '-'}",
        ]
        if state.state == "minimized":
            detail_bits.append("minimized")
        elif state.state == "floating":
            detail_bits.append("floating")
        else:
            detail_bits.append(state.state)
        detail = Gtk.Label(label="  |  ".join(detail_bits))
        detail.get_style_context().add_class("switcher-app-desc")
        detail.set_halign(Gtk.Align.START)
        detail.set_ellipsize(3)

        info.pack_start(title, False, False, 0)
        info.pack_start(detail, False, False, 0)
        box.pack_start(info, True, True, 0)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        actions.pack_start(self._action_button("-", lambda *_: self._minimize(state.wid), "Minimize"), False, False, 0)
        if state.state == "floating":
            actions.pack_start(self._action_button("[]", lambda *_: self._redock(state.wid), "Redock"), False, False, 0)
        else:
            actions.pack_start(self._action_button("[]", lambda *_: self._undock(state.wid), "Undock"), False, False, 0)
        actions.pack_start(self._action_button("x", lambda *_: self._close_window(state.wid), "Close"), False, False, 0)
        box.pack_start(actions, False, False, 0)

        row.add(box)
        self._listbox.add(row)
        return row

    def _add_app_row(self, app: dict) -> None:
        row = Gtk.ListBoxRow()
        row._app = app  # type: ignore[attr-defined]
        row.get_style_context().add_class("switcher-row")
        row.get_style_context().add_class("switcher-app-row")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(8)
        box.set_margin_bottom(8)

        badge = Gtk.Label(label="APP")
        badge.get_style_context().add_class("switcher-badge")
        badge.get_style_context().add_class("switcher-app-badge")
        badge.set_size_request(92, -1)
        box.pack_start(badge, False, False, 0)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info.set_hexpand(True)
        name = Gtk.Label(label=app.get("name", "App"))
        name.get_style_context().add_class("switcher-row-title")
        name.set_halign(Gtk.Align.START)
        name.set_ellipsize(3)
        info.pack_start(name, False, False, 0)
        if app.get("desc"):
            desc = Gtk.Label(label=app["desc"])
            desc.get_style_context().add_class("switcher-app-desc")
            desc.set_halign(Gtk.Align.START)
            desc.set_ellipsize(3)
            info.pack_start(desc, False, False, 0)
        box.pack_start(info, True, True, 0)

        open_btn = self._action_button("Open", lambda *_: self._launch_app(app), "Open app")
        box.pack_start(open_btn, False, False, 0)
        row.add(box)
        self._listbox.add(row)
        self._app_rows.append(row)

    def _clear_app_rows(self) -> None:
        if self._app_section_row is not None:
            self._listbox.remove(self._app_section_row)
            self._app_section_row = None
        for row in self._app_rows:
            self._listbox.remove(row)
        self._app_rows = []

    def _set_empty_state(self, is_empty: bool, query: str) -> None:
        if self._empty_row is not None:
            self._listbox.remove(self._empty_row)
            self._empty_row = None
        if not is_empty:
            return
        row = Gtk.ListBoxRow()
        row.set_activatable(False)
        row.set_selectable(False)
        lbl = Gtk.Label(
            label="No matches yet. Type to search installed apps."
            if query
            else "No windows yet. Type to search installed apps."
        )
        lbl.get_style_context().add_class("switcher-empty")
        lbl.set_margin_top(24)
        lbl.set_margin_bottom(24)
        row.add(lbl)
        self._listbox.add(row)
        self._empty_row = row

    def _action_button(self, label: str, callback, tooltip: str) -> Gtk.Button:
        btn = Gtk.Button(label=label)
        btn.get_style_context().add_class("switcher-inline-btn")
        btn.set_tooltip_text(tooltip)
        btn.connect("clicked", callback)
        return btn

    # ------------------------------------------------------------------
    def _selected_row(self) -> Optional[Gtk.ListBoxRow]:
        row = self._listbox.get_selected_row()
        return row if isinstance(row, Gtk.ListBoxRow) else None

    def _activatable_rows(self) -> list[Gtk.ListBoxRow]:
        return [
            row for row in self._listbox.get_children()
            if isinstance(row, Gtk.ListBoxRow) and row.get_activatable() and row.get_visible()
        ]

    def _visible_window_rows(self) -> list[Gtk.ListBoxRow]:
        return [
            row for row in self._listbox.get_children()
            if isinstance(row, Gtk.ListBoxRow)
            and row.get_visible()
            and getattr(row, "_win", None) is not None
        ]

    def _refresh_now(self) -> None:
        self._snapshot_store.refresh_now()

    def _select_first_visible(self) -> None:
        current = self._selected_row()
        if current is not None and current.get_visible() and current.get_activatable():
            return
        for row in self._activatable_rows():
            self._listbox.select_row(row)
            break

    def _selected_window(self) -> Optional[WindowState]:
        row = self._selected_row()
        return getattr(row, "_win", None) if row else None

    def _focus_selected(self) -> None:
        state = self._selected_window()
        if not state:
            return
        self._hide_shell_parent()
        self._hide_for_action()
        self._client.focus(state.wid)
        self._dismiss()

    def _launch_app(self, app: dict) -> None:
        try:
            command = shlex.split(app.get("exec", ""))
        except Exception:
            command = [app.get("exec", "")]
        if not command:
            return
        self._hide_shell_parent()
        self._client.launch_app(
            command,
            app_id=_slugify(app.get("name", "")),
            label=app.get("name", ""),
            icon_name=app.get("icon", ""),
            class_hints=[app.get("name", ""), Path(command[0]).stem],
            wait_window=False,
        )
        self._dismiss()

    def _minimize(self, wid: str) -> None:
        self._client.minimize(wid)
        self._refresh_now()

    def _undock(self, wid: str) -> None:
        self._client.undock(wid)
        self._refresh_now()

    def _redock(self, wid: str) -> None:
        self._client.redock(wid)
        self._refresh_now()

    def _close_window(self, wid: str) -> None:
        self._client.close(wid)
        self._refresh_now()

    def _move_window(self, wid: str, workspace: str) -> None:
        self._client.move_to_workspace(wid, workspace)
        self._refresh_now()

    def _on_show_desktop(self, *_args) -> None:
        self._client.minimize_all()
        self._dismiss()

    def _on_minimize_all(self, *_args) -> None:
        self._client.minimize_all()
        self._refresh_now()

    def _on_close_all(self, *_args) -> None:
        self._client.close_all()
        self._refresh_now()

    # ------------------------------------------------------------------
    def _on_search_changed(self, _entry) -> None:
        self._refresh_query_view()

    def _on_search_key(self, _w, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self._dismiss()
            return True
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            row = self._selected_row()
            if row is not None:
                self._activate_row(row)
            return True
        return False

    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        key = event.keyval
        mods = event.state
        shift = bool(mods & Gdk.ModifierType.SHIFT_MASK)

        if key == Gdk.KEY_Escape:
            self._dismiss()
            return True
        if key in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            row = self._selected_row()
            if row is not None:
                self._activate_row(row)
            return True
        if key in (Gdk.KEY_Tab, Gdk.KEY_Down):
            self._move(1)
            return True
        if key in (Gdk.KEY_ISO_Left_Tab, Gdk.KEY_Up):
            self._move(-1)
            return True
        if Gdk.KEY_1 <= key <= Gdk.KEY_9:
            idx = key - Gdk.KEY_1
            if shift:
                state = self._selected_window()
                if state:
                    self._move_window(state.wid, str(idx + 1))
                return True
            windows = self._visible_window_rows()
            if idx < len(windows):
                self._listbox.select_row(windows[idx])
                self._focus_selected()
            return True
        if key in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            state = self._selected_window()
            if state:
                self._minimize(state.wid)
            return True
        if key == Gdk.KEY_u:
            state = self._selected_window()
            if state:
                self._undock(state.wid)
            return True
        if key == Gdk.KEY_r:
            state = self._selected_window()
            if state:
                self._redock(state.wid)
            return True
        if key in (Gdk.KEY_x, Gdk.KEY_Delete):
            state = self._selected_window()
            if state:
                self._close_window(state.wid)
            return True
        return False

    def _move(self, delta: int) -> None:
        rows = self._activatable_rows()
        if not rows:
            return
        sel = self._selected_row()
        idx = rows.index(sel) if sel in rows else 0
        idx = (idx + delta) % len(rows)
        self._listbox.select_row(rows[idx])
        rows[idx].grab_focus()

    def _on_row_activated(self, _lb, row: Gtk.ListBoxRow) -> None:
        self._activating = True
        self._activate_row(row)

    def _activate_row(self, row: Gtk.ListBoxRow) -> None:
        state = getattr(row, "_win", None)
        if state:
            self._focus_selected()
            return
        app = getattr(row, "_app", None)
        if app:
            self._launch_app(app)
            return
        self._dismiss()

    def _hide_for_action(self) -> None:
        try:
            self.hide()
            while Gtk.events_pending():
                Gtk.main_iteration_do(False)
        except Exception:
            pass

    def _hide_shell_parent(self) -> None:
        parent = self._transient_parent
        if parent is None:
            return
        try:
            if parent.get_visible():
                parent.hide()
        except Exception:
            pass

    def _on_focus_out(self, *_args) -> bool:
        if not self._activating:
            GLib.timeout_add(150, self._dismiss_if_inactive)
        return False

    def _dismiss_if_inactive(self) -> bool:
        if self._activating:
            return False
        if not self.is_active() and not self.has_toplevel_focus():
            self._dismiss()
        return False

    def _on_show(self, *_args) -> None:
        GLib.idle_add(self._search.grab_focus)

    def _on_destroy(self, *_args) -> None:
        self._snapshot_store.close()
        if self._on_close:
            try:
                self._on_close()
            except Exception:
                pass

    def _dismiss(self) -> None:
        self.destroy()


def main(argv: Optional[list[str]] = None) -> None:
    overview = bool(argv and "--overview" in argv)
    client = WindowManagerClient()
    client.ensure_daemon()
    win = WindowSwitcherV2(overview=overview, on_close=Gtk.main_quit)
    win.show_all()
    GLib.idle_add(win.grab_focus)
    Gtk.main()


if __name__ == "__main__":
    import sys

    main(sys.argv[1:])
