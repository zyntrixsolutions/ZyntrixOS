#!/usr/bin/env python3
"""ZyntrixOS System Monitor — full GTK3 resource monitor."""
from __future__ import annotations

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")

import os
import signal
import sys
import time
import threading, math
from collections import deque
from typing import Optional
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Pango

SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
GRAPH_POINTS = 60
_CLK_TCK = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100


def _read_ram_kb() -> int:
    try:
        with open("/proc/meminfo") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1])
    except Exception:
        pass
    return 4 * 1024 * 1024


_RAM_KB = _read_ram_kb()
_ULTRALOW = _RAM_KB <= 2 * 1024 * 1024
_LOW_END = _RAM_KB <= 3 * 1024 * 1024

# Before: every 1.5 s, read /proc/<pid>/stat and status for every PID and
# repopulated every GTK row.  After: low-memory systems sample incrementally
# and show only top rows, eliminating swap storms on 2 GB machines.
REFRESH_MS = 3000 if _ULTRALOW else 2200 if _LOW_END else 1500
PROC_REFRESH_MIN_S = 5.0 if _ULTRALOW else 3.0 if _LOW_END else 1.5
PROC_SAMPLE_BUDGET = 48 if _ULTRALOW else 96 if _LOW_END else 0
PROC_TOP_N = 32 if _ULTRALOW else 80 if _LOW_END else 0  # 0 = no high-tier row cap


# ─── System data readers ───────────────────────────────────────────────────

def _read_file(path: str) -> str:
    try:
        with open(path) as f:
            return f.read()
    except Exception:
        return ""


def _cpu_stat() -> list:
    lines = _read_file("/proc/stat").splitlines()
    stats = []
    for line in lines:
        if not line.startswith("cpu"):
            break
        parts = line.split()
        stats.append([int(x) for x in parts[1:]])
    return stats


def _calc_cpu_pct(s1: list, s2: list) -> list:
    pcts = []
    for a, b in zip(s1, s2):
        total = sum(b) - sum(a)
        idle = (b[3] + b[4]) - (a[3] + a[4])
        pcts.append(0.0 if total == 0 else max(0.0, min(100.0, (1 - idle / total) * 100)))
    return pcts


def _mem_info() -> dict:
    data = {}
    for line in _read_file("/proc/meminfo").splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            try:
                data[k.strip()] = int(v.split()[0])
            except Exception:
                pass
    total = data.get("MemTotal", 0)
    avail = data.get("MemAvailable", 0)
    swap_t = data.get("SwapTotal", 0)
    swap_f = data.get("SwapFree", 0)
    used = total - avail
    return {
        "total": total * 1024,
        "used": used * 1024,
        "avail": avail * 1024,
        "pct": (used / total * 100) if total else 0.0,
        "swap_total": swap_t * 1024,
        "swap_used": (swap_t - swap_f) * 1024,
        "swap_pct": ((swap_t - swap_f) / swap_t * 100) if swap_t else 0.0,
    }


def _net_stats() -> dict:
    data = {}
    for line in _read_file("/proc/net/dev").splitlines()[2:]:
        if ":" not in line:
            continue
        iface, rest = line.split(":", 1)
        parts = rest.split()
        if iface.strip() == "lo":
            continue
        try:
            data[iface.strip()] = {"rx": int(parts[0]), "tx": int(parts[8])}
        except Exception:
            pass
    return data


def _disk_stats() -> dict:
    data = {}
    for line in _read_file("/proc/diskstats").splitlines():
        parts = line.split()
        if len(parts) < 14:
            continue
        name = parts[2]
        if not any(name.startswith(p) for p in ("sd", "vd", "nvme", "hd", "xvd")):
            continue
        try:
            data[name] = {
                "read_sectors": int(parts[5]),
                "write_sectors": int(parts[9]),
            }
        except Exception:
            pass
    return data


def _disk_partitions() -> list:
    parts = []
    for line in _read_file("/proc/mounts").splitlines():
        cols = line.split()
        if len(cols) < 2:
            continue
        dev, mp = cols[0], cols[1]
        if not dev.startswith("/") and dev not in ("tmpfs", "overlay"):
            continue
        if any(mp.startswith(x) for x in ("/proc", "/sys", "/dev", "/run/user",
                                           "/snap", "/boot/efi")):
            continue
        try:
            st = os.statvfs(mp)
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            used = total - free
            if total < 1024 * 1024:
                continue
            parts.append({"dev": dev, "mp": mp, "total": total,
                          "used": used, "free": free,
                          "pct": (used / total * 100) if total else 0.0})
        except Exception:
            pass
    seen = set()
    uniq = []
    for p in parts:
        key = (p["dev"], p["mp"])
        if key not in seen:
            seen.add(key)
            uniq.append(p)
    return uniq


def _parse_proc_stat(stat: str) -> tuple[str, str, int]:
    """Return (comm, state, user+sys ticks) from /proc/<pid>/stat."""
    try:
        end = stat.rfind(")")
        comm_start = stat.find("(")
        comm = stat[comm_start + 1:end] if comm_start >= 0 and end > comm_start else ""
        tail = stat[end + 2:].split()
        state = tail[0] if tail else "?"
        # tail[0] is field 3; utime/stime are fields 14/15.
        ticks = int(tail[11]) + int(tail[12]) if len(tail) > 12 else 0
        return comm, state, ticks
    except Exception:
        return "", "?", 0


def _read_proc(pid: int, now: float, prev: Optional[dict]) -> Optional[dict]:
    stat = _read_file(f"/proc/{pid}/stat")
    if not stat:
        return None
    name, state, ticks = _parse_proc_stat(stat)
    mem = 0
    status = _read_file(f"/proc/{pid}/status")
    for line in status.splitlines():
        if line.startswith("Name:") and not name:
            try:
                name = line.split(None, 1)[1].strip()
            except Exception:
                pass
        elif line.startswith("VmRSS:"):
            try:
                mem = int(line.split()[1]) * 1024
            except Exception:
                pass
            break

    cpu = 0.0
    if prev:
        dt = max(0.01, now - float(prev.get("seen_t", now)))
        delta = max(0, ticks - int(prev.get("ticks", ticks)))
        cpu = max(0.0, min(999.0, delta / _CLK_TCK / dt * 100.0))

    return {
        "pid": pid,
        "name": name or f"pid{pid}",
        "state": state,
        "mem": mem,
        "ticks": ticks,
        "cpu": cpu,
        "seen_t": now,
    }


class ProcessSampler:
    """Incremental low-memory process collector.

    The sampler keeps only compact per-PID metadata and returns a top-N view.
    That avoids holding a freshly allocated full process list and avoids GTK
    row churn for background daemons the user is unlikely to inspect.
    """

    def __init__(
        self,
        top_n: int = PROC_TOP_N,
        budget: int = PROC_SAMPLE_BUDGET,
        min_interval: float = PROC_REFRESH_MIN_S,
    ):
        self._top_n = top_n
        self._budget = budget
        self._min_interval = min_interval
        self._cache: dict[int, dict] = {}
        self._pids: list[int] = []
        self._cursor = 0
        self._last_pid_refresh = 0.0
        self._last_sample = 0.0
        self._total = 0

    def collect(self) -> tuple[list[dict], int]:
        now = time.monotonic()
        if not self._pids or now - self._last_pid_refresh >= max(2.0, self._min_interval):
            self._refresh_pids(now)

        if now - self._last_sample < self._min_interval and self._cache:
            return self.snapshot()

        pids = self._next_pid_batch()
        for pid in pids:
            prev = self._cache.get(pid)
            proc = _read_proc(pid, now, prev)
            if proc is None:
                self._cache.pop(pid, None)
            else:
                self._cache[pid] = proc
        self._last_sample = now
        return self.snapshot()

    def _refresh_pids(self, now: float) -> None:
        try:
            with os.scandir("/proc") as it:
                pids = sorted(int(e.name) for e in it if e.name.isdigit())
        except Exception:
            pids = []
        self._pids = pids
        self._total = len(pids)
        live = set(pids)
        for pid in list(self._cache):
            if pid not in live:
                self._cache.pop(pid, None)
        self._cursor = min(self._cursor, len(self._pids))
        self._last_pid_refresh = now

    def _next_pid_batch(self) -> list[int]:
        if not self._pids:
            return []
        if self._budget <= 0 or self._budget >= len(self._pids):
            return list(self._pids)
        end = self._cursor + self._budget
        if end <= len(self._pids):
            batch = self._pids[self._cursor:end]
        else:
            batch = self._pids[self._cursor:] + self._pids[:end % len(self._pids)]
        self._cursor = end % len(self._pids)
        return batch

    def snapshot(self) -> tuple[list[dict], int]:
        rows = [
            {
                "pid": p["pid"],
                "name": p["name"],
                "state": p["state"],
                "mem": p["mem"],
                "ticks": p["ticks"],
                "cpu": p.get("cpu", 0.0),
            }
            for p in self._cache.values()
        ]
        if self._top_n <= 0 or self._top_n >= len(rows):
            return sorted(
                rows,
                key=lambda r: (r.get("cpu", 0.0), r.get("mem", 0)),
                reverse=True,
            ), self._total
        by_pid: dict[int, dict] = {}
        for p in sorted(rows, key=lambda r: r["cpu"], reverse=True)[:self._top_n]:
            by_pid[p["pid"]] = p
        for p in sorted(rows, key=lambda r: r["mem"], reverse=True)[:max(8, self._top_n // 2)]:
            by_pid[p["pid"]] = p
        ranked = sorted(
            by_pid.values(),
            key=lambda r: (r.get("cpu", 0.0), r.get("mem", 0)),
            reverse=True,
        )[:self._top_n]
        return ranked, self._total


def _uptime() -> str:
    try:
        secs = float(_read_file("/proc/uptime").split()[0])
        h = int(secs // 3600)
        m = int((secs % 3600) // 60)
        return f"{h}h {m}m"
    except Exception:
        return "?"


def _fmt_bytes(n: int) -> str:
    if n < 1024: return f"{n} B"
    if n < 1024**2: return f"{n/1024:.1f} KB"
    if n < 1024**3: return f"{n/1024**2:.1f} MB"
    return f"{n/1024**3:.2f} GB"


def _fmt_rate(n: float) -> str:
    if n < 1024: return f"{n:.0f} B/s"
    if n < 1024**2: return f"{n/1024:.1f} KB/s"
    return f"{n/1024**2:.1f} MB/s"


# ─── Graph widget ──────────────────────────────────────────────────────────

class Graph(Gtk.DrawingArea):
    def __init__(self, color: tuple = (0.0, 0.94, 0.78), bg=(0.05, 0.06, 0.09)):
        super().__init__()
        self._values: deque = deque([0.0] * GRAPH_POINTS, maxlen=GRAPH_POINTS)
        self._color = color
        self._bg = bg
        self.set_size_request(-1, 80)
        self.connect("draw", self._draw)

    def push(self, value: float):
        self._values.append(max(0.0, min(100.0, value)))
        self.queue_draw()

    def _draw(self, _widget, cr):
        w = self.get_allocated_width()
        h = self.get_allocated_height()
        r, g, b = self._bg
        cr.set_source_rgb(r, g, b)
        cr.paint()

        vals = list(self._values)
        n = len(vals)
        if n < 2:
            return

        step = w / (n - 1)
        r, g, b = self._color

        # Grid lines
        cr.set_source_rgba(r, g, b, 0.08)
        cr.set_line_width(1)
        for pct in [25, 50, 75]:
            y = h - (pct / 100.0 * h)
            cr.move_to(0, y); cr.line_to(w, y); cr.stroke()

        # Fill area
        cr.move_to(0, h)
        for i, v in enumerate(vals):
            x = i * step
            y = h - (v / 100.0 * (h - 4))
            cr.line_to(x, y)
        cr.line_to(w, h)
        cr.close_path()
        cr.set_source_rgba(r, g, b, 0.18)
        cr.fill()

        # Line
        cr.move_to(0, h - (vals[0] / 100.0 * (h - 4)))
        for i, v in enumerate(vals[1:], 1):
            cr.line_to(i * step, h - (v / 100.0 * (h - 4)))
        cr.set_source_rgba(r, g, b, 0.9)
        cr.set_line_width(1.5)
        cr.stroke()


# ─── CSS ──────────────────────────────────────────────────────────────────

_CSS = b"""
window.sm-window { background-color: #0a0b0f; }
.sm-header { background-color: #0e1018; border-bottom: 1px solid rgba(0,240,200,0.12); padding: 12px 20px; }
.sm-title { font-size: 13px; font-weight: 700; letter-spacing: 3px; color: #00f0c8; }
.sm-uptime { font-size: 11px; color: rgba(232,234,240,0.4); }
notebook { background-color: #0a0b0f; }
notebook header { background-color: #0e1018; border-bottom: 1px solid rgba(0,240,200,0.12); }
notebook header tabs tab { color: rgba(232,234,240,0.5); padding: 8px 18px; font-size: 12px; }
notebook header tabs tab:checked { color: #00f0c8; border-bottom: 2px solid #00f0c8; }
.sm-gauge-frame { background-color: #0e1018; border: 1px solid rgba(0,240,200,0.12);
    border-radius: 8px; padding: 14px 16px; margin: 6px; }
.sm-gauge-title { font-size: 11px; font-weight: 700; letter-spacing: 2px;
    color: rgba(0,240,200,0.7); margin-bottom: 8px; }
.sm-gauge-value { font-size: 26px; font-weight: 200; color: #e8eaf0; }
.sm-gauge-sub { font-size: 11px; color: rgba(232,234,240,0.4); margin-top: 2px; }
progressbar { min-height: 6px; }
progressbar trough { background-color: rgba(0,240,200,0.1); border-radius: 3px; min-height: 6px; }
progressbar.cpu progress { background-color: #00f0c8; border-radius: 3px; min-height: 6px; }
progressbar.mem progress { background-color: #a78bfa; border-radius: 3px; min-height: 6px; }
progressbar.disk progress { background-color: #f59e0b; border-radius: 3px; min-height: 6px; }
progressbar.net progress { background-color: #22d3ee; border-radius: 3px; min-height: 6px; }
progressbar.swap progress { background-color: #ef4444; border-radius: 3px; min-height: 6px; }
treeview { background-color: #0a0b0f; color: #e8eaf0; font-size: 12px; }
treeview:selected { background-color: rgba(0,240,200,0.15); }
treeview header button { background-color: #0e1018; color: rgba(232,234,240,0.5);
    border: none; border-bottom: 1px solid rgba(0,240,200,0.12); font-size: 11px; }
.sm-kill-btn { background-color: rgba(239,68,68,0.15); color: #ef4444;
    border: 1px solid rgba(239,68,68,0.4); border-radius: 4px; padding: 3px 10px; font-size: 11px; }
.sm-kill-btn:hover { background-color: rgba(239,68,68,0.3); }
.sm-search { background-color: #0e1018; color: #e8eaf0; border: 1px solid rgba(0,240,200,0.2);
    border-radius: 5px; padding: 4px 10px; font-size: 12px; }
.sm-section-lbl { font-size: 10px; font-weight: 700; letter-spacing: 2px;
    color: rgba(0,240,200,0.5); margin: 14px 0 6px 0; }
.sm-kv-key { font-size: 12px; color: rgba(232,234,240,0.45); min-width: 120px; }
.sm-kv-val { font-size: 12px; color: #e8eaf0; font-weight: 500; }
.sm-disk-label { font-size: 12px; color: #e8eaf0; }
.sm-disk-sub { font-size: 11px; color: rgba(232,234,240,0.4); }
.sm-net-iface { font-size: 13px; font-weight: 700; color: #00f0c8; }
.sm-net-val { font-size: 12px; color: #e8eaf0; }
"""


# ─── Main Window ──────────────────────────────────────────────────────────

class SysMonitorWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="ZyntrixOS System Monitor")
        self.set_default_size(1000, 680)
        self.get_style_context().add_class("sm-window")

        # State
        self._cpu_prev: Optional[list] = None
        self._net_prev: Optional[dict] = None
        self._net_prev_t: float = 0.0
        self._disk_prev: Optional[dict] = None
        self._disk_prev_t: float = 0.0
        self._proc_sampler = ProcessSampler()
        self._disk_tab_keys: tuple = ()
        self._net_tab_keys: tuple = ()
        self._collecting: bool = False
        self._ui_apply_pending: bool = False
        self._last_proc_refresh_t: float = 0.0
        self._cached_procs: list = []
        self._cached_proc_total: int = 0
        self._last_parts_refresh_t: float = 0.0
        self._cached_parts: list = []

        # Graph history
        self._cpu_hist = Graph((0.0, 0.94, 0.78))
        self._mem_hist = Graph((0.65, 0.55, 0.98))
        self._rx_hist  = Graph((0.13, 0.83, 0.93))
        self._tx_hist  = Graph((0.96, 0.62, 0.04))
        self._disk_r_hist = Graph((0.96, 0.62, 0.04))
        self._disk_w_hist = Graph((0.24, 0.81, 0.60))

        self._apply_css()
        self._build_ui()
        self.connect("destroy", Gtk.main_quit)

        GLib.timeout_add(REFRESH_MS, self._update)
        threading.Thread(target=self._initial_update, daemon=True).start()

    def _apply_css(self):
        p = Gtk.CssProvider()
        p.load_from_data(_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), p, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

    def _build_ui(self):
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # Header
        hdr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        hdr.get_style_context().add_class("sm-header")
        title = Gtk.Label(label="SYSTEM MONITOR")
        title.get_style_context().add_class("sm-title")
        self._uptime_lbl = Gtk.Label(label=f"up {_uptime()}")
        self._uptime_lbl.get_style_context().add_class("sm-uptime")
        self._uptime_lbl.set_halign(Gtk.Align.END)
        self._uptime_lbl.set_hexpand(True)
        hdr.pack_start(title, False, False, 0)
        hdr.pack_end(self._uptime_lbl, False, False, 0)
        vbox.pack_start(hdr, False, False, 0)

        # Notebook
        self._nb = Gtk.Notebook()
        self._nb.set_border_width(0)

        self._nb.append_page(self._build_overview_tab(),  Gtk.Label(label="Overview"))
        self._nb.append_page(self._build_process_tab(),   Gtk.Label(label="Processes"))
        self._nb.append_page(self._build_resources_tab(), Gtk.Label(label="Resources"))
        self._nb.append_page(self._build_disk_tab(),      Gtk.Label(label="Disk"))
        self._nb.append_page(self._build_network_tab(),   Gtk.Label(label="Network"))

        vbox.pack_start(self._nb, True, True, 0)
        self.add(vbox)

    # ── Overview tab ──────────────────────────────────────────────────────

    def _build_overview_tab(self) -> Gtk.Widget:
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.set_margin_start(16); vbox.set_margin_end(16)
        vbox.set_margin_top(14);  vbox.set_margin_bottom(14)

        gauges = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        gauges.set_homogeneous(True)
        self._gauge_widgets = {}

        for key, label, css_class, color in [
            ("cpu",  "CPU",    "cpu",  "#00f0c8"),
            ("mem",  "MEMORY", "mem",  "#a78bfa"),
            ("swap", "SWAP",   "swap", "#ef4444"),
            ("disk", "DISK I/O","disk","#f59e0b"),
        ]:
            frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            frame.get_style_context().add_class("sm-gauge-frame")
            frame.set_margin_start(4); frame.set_margin_end(4)

            lbl = Gtk.Label(label=label)
            lbl.get_style_context().add_class("sm-gauge-title")
            lbl.set_halign(Gtk.Align.START)

            val_lbl = Gtk.Label(label="—")
            val_lbl.get_style_context().add_class("sm-gauge-value")
            val_lbl.set_halign(Gtk.Align.START)

            bar = Gtk.ProgressBar()
            bar.get_style_context().add_class(css_class)

            sub_lbl = Gtk.Label(label="")
            sub_lbl.get_style_context().add_class("sm-gauge-sub")
            sub_lbl.set_halign(Gtk.Align.START)
            sub_lbl.set_ellipsize(Pango.EllipsizeMode.END)

            frame.pack_start(lbl,     False, False, 0)
            frame.pack_start(val_lbl, False, False, 0)
            frame.pack_start(bar,     False, False, 4)
            frame.pack_start(sub_lbl, False, False, 0)
            gauges.pack_start(frame, True, True, 0)
            self._gauge_widgets[key] = (val_lbl, bar, sub_lbl)

        vbox.pack_start(gauges, False, False, 0)

        # Top processes
        sep_lbl = Gtk.Label(label="TOP PROCESSES")
        sep_lbl.get_style_context().add_class("sm-section-lbl")
        sep_lbl.set_halign(Gtk.Align.START)
        sep_lbl.set_margin_top(16)
        vbox.pack_start(sep_lbl, False, False, 0)

        self._ov_proc_store = Gtk.ListStore(int, str, str, str)
        tv = Gtk.TreeView(model=self._ov_proc_store)
        tv.set_headers_visible(True)
        for i, (title, width) in enumerate([
                ("PID", 65), ("Name", 200), ("Memory", 100), ("State", 80)]):
            col = Gtk.TreeViewColumn(title, Gtk.CellRendererText(), text=i)
            col.set_min_width(width)
            col.set_sort_column_id(i)
            tv.append_column(col)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.add(tv)
        vbox.pack_start(sw, True, True, 0)
        return vbox

    # ── Processes tab ─────────────────────────────────────────────────────

    def _build_process_tab(self) -> Gtk.Widget:
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        vbox.set_margin_start(14); vbox.set_margin_end(14)
        vbox.set_margin_top(10);   vbox.set_margin_bottom(10)

        toolbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self._proc_search = Gtk.SearchEntry()
        self._proc_search.set_placeholder_text("Filter processes…")
        self._proc_search.set_hexpand(True)
        self._proc_search.get_style_context().add_class("sm-search")
        self._proc_search.connect("search-changed", lambda _: self._filter_procs())

        self._kill_btn = Gtk.Button(label="⊘  Kill")
        self._kill_btn.get_style_context().add_class("sm-kill-btn")
        self._kill_btn.connect("clicked", self._on_kill)
        self._kill_btn.set_sensitive(False)

        toolbar.pack_start(self._proc_search, True, True, 0)
        toolbar.pack_end(self._kill_btn, False, False, 0)
        vbox.pack_start(toolbar, False, False, 0)

        # PID, Name, CPU%, Memory, State
        self._proc_store = Gtk.ListStore(int, str, float, str, str)
        self._proc_filter = self._proc_store.filter_new()
        self._proc_filter.set_visible_func(self._proc_visible)
        self._proc_sort = Gtk.TreeModelSort(model=self._proc_filter)

        self._proc_tv = Gtk.TreeView(model=self._proc_sort)
        self._proc_tv.set_headers_visible(True)
        self._proc_tv.get_selection().connect("changed", self._on_proc_sel)

        for i, (title, width) in enumerate([
                ("PID", 70), ("Name", 220), ("CPU %", 80), ("Memory", 100), ("State", 70)]):
            if i == 2:
                renderer = Gtk.CellRendererText()
                col = Gtk.TreeViewColumn(title, renderer)
                col.set_cell_data_func(renderer,
                    lambda c, r, m, it, i=i: r.set_property("text", f"{m.get_value(it, i):.1f}"))
            else:
                renderer = Gtk.CellRendererText()
                col = Gtk.TreeViewColumn(title, renderer, text=i)
            col.set_min_width(width)
            col.set_sort_column_id(i)
            col.set_resizable(True)
            self._proc_tv.append_column(col)

        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        sw.set_vexpand(True)
        sw.add(self._proc_tv)
        vbox.pack_start(sw, True, True, 0)

        self._proc_count_lbl = Gtk.Label(label="")
        self._proc_count_lbl.get_style_context().add_class("sm-gauge-sub")
        self._proc_count_lbl.set_halign(Gtk.Align.START)
        vbox.pack_start(self._proc_count_lbl, False, False, 0)
        return vbox

    def _proc_visible(self, model, it, _data):
        q = self._proc_search.get_text().strip().lower()
        if not q:
            return True
        name = model.get_value(it, 1) or ""
        pid  = str(model.get_value(it, 0))
        return q in name.lower() or q in pid

    def _filter_procs(self):
        self._proc_filter.refilter()

    def _on_proc_sel(self, sel):
        model, it = sel.get_selected()
        self._kill_btn.set_sensitive(it is not None)

    def _on_kill(self, _btn):
        model, it = self._proc_tv.get_selection().get_selected()
        if it is None:
            return
        pid = model.get_value(it, 0)
        name = model.get_value(it, 1)
        dlg = Gtk.MessageDialog(
            transient_for=self, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=f"Kill process {name} (PID {pid})?",
        )
        if dlg.run() == Gtk.ResponseType.YES:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception as e:
                GLib.idle_add(self._show_error, str(e))
        dlg.destroy()

    # ── Resources tab ─────────────────────────────────────────────────────

    def _build_resources_tab(self) -> Gtk.Widget:
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        vbox.set_margin_start(16); vbox.set_margin_end(16)
        vbox.set_margin_top(10);   vbox.set_margin_bottom(10)

        self._res_labels: dict = {}
        for key, label, graph, css, bar_css in [
            ("cpu",    "CPU",          self._cpu_hist,    "#00f0c8", "cpu"),
            ("mem",    "MEMORY",       self._mem_hist,    "#a78bfa", "mem"),
            ("net_rx", "NETWORK RX",   self._rx_hist,     "#22d3ee", "net"),
            ("net_tx", "NETWORK TX",   self._tx_hist,     "#f59e0b", "net"),
            ("disk_r", "DISK READ",    self._disk_r_hist, "#f59e0b", "disk"),
            ("disk_w", "DISK WRITE",   self._disk_w_hist, "#4ade80", "disk"),
        ]:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            row.set_margin_bottom(12)

            meta = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            meta.set_size_request(120, -1)
            meta.set_valign(Gtk.Align.CENTER)

            title_lbl = Gtk.Label(label=label)
            title_lbl.get_style_context().add_class("sm-section-lbl")
            title_lbl.set_halign(Gtk.Align.START)

            val_lbl = Gtk.Label(label="—")
            val_lbl.get_style_context().add_class("sm-kv-val")
            val_lbl.set_halign(Gtk.Align.START)

            bar = Gtk.ProgressBar()
            bar.get_style_context().add_class(bar_css)

            meta.pack_start(title_lbl, False, False, 0)
            meta.pack_start(val_lbl,   False, False, 0)
            meta.pack_start(bar,       False, False, 4)

            graph.set_hexpand(True)

            row.pack_start(meta,  False, False, 0)
            row.pack_start(graph, True,  True,  0)
            vbox.pack_start(row, False, False, 0)
            self._res_labels[key] = (val_lbl, bar)

        sw.add(vbox)
        return sw

    # ── Disk tab ──────────────────────────────────────────────────────────

    def _build_disk_tab(self) -> Gtk.Widget:
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._disk_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self._disk_box.set_margin_start(16); self._disk_box.set_margin_end(16)
        self._disk_box.set_margin_top(14);   self._disk_box.set_margin_bottom(14)
        sw.add(self._disk_box)
        return sw

    def _rebuild_disk_tab(self, partitions: list):
        new_keys = tuple((p["dev"], p["mp"]) for p in partitions)
        if new_keys == self._disk_tab_keys:
            # Same partitions — update bars in-place
            for i, (child, p) in enumerate(zip(self._disk_box.get_children(), partitions)):
                widgets = child.get_children()
                for w in widgets:
                    if isinstance(w, Gtk.ProgressBar):
                        w.set_fraction(p["pct"] / 100.0)
                    elif isinstance(w, Gtk.Box):
                        for sub in w.get_children():
                            if hasattr(sub, "get_style_context") and \
                                    sub.get_style_context().has_class("sm-gauge-value"):
                                sub.set_text(f"{p['pct']:.1f}%")
            return
        self._disk_tab_keys = new_keys
        for child in self._disk_box.get_children():
            self._disk_box.remove(child)

        for p in partitions:
            frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            frame.get_style_context().add_class("sm-gauge-frame")
            frame.set_margin_bottom(8)

            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            mp_lbl = Gtk.Label(label=p["mp"])
            mp_lbl.get_style_context().add_class("sm-disk-label")
            mp_lbl.set_halign(Gtk.Align.START)
            mp_lbl.set_hexpand(True)

            dev_lbl = Gtk.Label(label=p["dev"])
            dev_lbl.get_style_context().add_class("sm-disk-sub")

            pct_lbl = Gtk.Label(label=f"{p['pct']:.1f}%")
            pct_lbl.get_style_context().add_class("sm-gauge-value")
            pct_lbl.set_halign(Gtk.Align.END)

            top.pack_start(mp_lbl,  True,  True,  0)
            top.pack_end(pct_lbl,   False, False, 0)
            top.pack_end(dev_lbl,   False, False, 0)

            bar = Gtk.ProgressBar()
            bar.get_style_context().add_class("disk")
            bar.set_fraction(p["pct"] / 100.0)

            sub = Gtk.Label(
                label=f"{_fmt_bytes(p['used'])} used  ·  {_fmt_bytes(p['free'])} free  ·  {_fmt_bytes(p['total'])} total")
            sub.get_style_context().add_class("sm-disk-sub")
            sub.set_halign(Gtk.Align.START)

            frame.pack_start(top, False, False, 0)
            frame.pack_start(bar, False, False, 0)
            frame.pack_start(sub, False, False, 0)
            self._disk_box.pack_start(frame, False, False, 0)

        self._disk_box.show_all()

    # ── Network tab ───────────────────────────────────────────────────────

    def _build_network_tab(self) -> Gtk.Widget:
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self._net_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self._net_box.set_margin_start(16); self._net_box.set_margin_end(16)
        self._net_box.set_margin_top(14);   self._net_box.set_margin_bottom(14)
        sw.add(self._net_box)
        return sw

    def _rebuild_net_tab(self, net_data: dict, deltas: dict):
        new_keys = tuple(sorted(net_data.keys()))
        rebuild = new_keys != self._net_tab_keys
        if rebuild:
            self._net_tab_keys = new_keys
            for child in self._net_box.get_children():
                self._net_box.remove(child)
        else:
            self._net_box.show_all()
            return

        for iface, stats in sorted(net_data.items()):
            frame = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            frame.get_style_context().add_class("sm-gauge-frame")
            frame.set_margin_bottom(8)

            title = Gtk.Label(label=iface)
            title.get_style_context().add_class("sm-net-iface")
            title.set_halign(Gtk.Align.START)
            frame.pack_start(title, False, False, 0)

            grid = Gtk.Grid()
            grid.set_column_spacing(24)
            grid.set_row_spacing(4)
            rows = [
                ("RX Total",  _fmt_bytes(stats["rx"])),
                ("TX Total",  _fmt_bytes(stats["tx"])),
                ("RX Rate",   _fmt_rate(deltas.get(iface, {}).get("rx_rate", 0))),
                ("TX Rate",   _fmt_rate(deltas.get(iface, {}).get("tx_rate", 0))),
            ]
            for i, (k, v) in enumerate(rows):
                kl = Gtk.Label(label=k)
                kl.get_style_context().add_class("sm-kv-key")
                kl.set_halign(Gtk.Align.START)
                vl = Gtk.Label(label=v)
                vl.get_style_context().add_class("sm-net-val")
                vl.set_halign(Gtk.Align.START)
                grid.attach(kl, 0, i, 1, 1)
                grid.attach(vl, 1, i, 1, 1)

            frame.pack_start(grid, False, False, 0)
            self._net_box.pack_start(frame, False, False, 0)

        self._net_box.show_all()

    # ── Update loop ───────────────────────────────────────────────────────

    def _initial_update(self):
        self._cpu_prev = _cpu_stat()
        net = _net_stats()
        self._net_prev = net
        self._net_prev_t = time.monotonic()
        disk = _disk_stats()
        self._disk_prev = disk
        self._disk_prev_t = time.monotonic()
        time.sleep(1.0)
        # Do not idle_add(_update) directly: _update returns True for the
        # periodic timer, and a True idle callback repeats as fast as GTK can
        # run it.  That was a hidden path to 100% CPU after startup.
        GLib.idle_add(self._initial_update_ready)

    def _initial_update_ready(self) -> bool:
        self._update()
        return False

    def _update(self) -> bool:
        if not self._collecting and not self._ui_apply_pending:
            self._collecting = True
            threading.Thread(target=self._collect, daemon=True).start()
        return True  # keep firing

    def _collect(self):
        try:
            self._collect_inner()
        finally:
            self._collecting = False

    def _collect_inner(self):
        now = time.monotonic()
        cpu2 = _cpu_stat()
        mem = _mem_info()
        net2 = _net_stats()
        disk2 = _disk_stats()
        proc_page = self._nb.get_current_page() if hasattr(self, "_nb") else 0
        proc_refresh_due = now - self._last_proc_refresh_t >= max(PROC_REFRESH_MIN_S, 6.0 if _LOW_END else 3.0)
        if proc_page in (0, 1) or proc_refresh_due:
            procs, proc_total = self._proc_sampler.collect()
            self._cached_procs = list(procs)
            self._cached_proc_total = proc_total
            self._last_proc_refresh_t = now
        else:
            procs = list(self._cached_procs)
            proc_total = self._cached_proc_total

        parts_refresh_due = now - self._last_parts_refresh_t >= (18.0 if _ULTRALOW else 12.0 if _LOW_END else 8.0)
        if proc_page == 3 or parts_refresh_due:
            parts = _disk_partitions()
            self._cached_parts = list(parts)
            self._last_parts_refresh_t = now
        else:
            parts = list(self._cached_parts)

        # CPU %
        cpu_pcts = [0.0]
        if self._cpu_prev:
            cpu_pcts = _calc_cpu_pct(self._cpu_prev, cpu2)
        self._cpu_prev = cpu2

        # Net rates
        dt_net = now - self._net_prev_t if self._net_prev_t else 1.0
        net_deltas = {}
        if self._net_prev:
            for iface, cur in net2.items():
                prev = self._net_prev.get(iface, {"rx": 0, "tx": 0})
                rx_rate = max(0.0, (cur["rx"] - prev["rx"]) / dt_net)
                tx_rate = max(0.0, (cur["tx"] - prev["tx"]) / dt_net)
                net_deltas[iface] = {"rx_rate": rx_rate, "tx_rate": tx_rate}
        self._net_prev = net2
        self._net_prev_t = now

        # Disk I/O rates
        dt_disk = now - self._disk_prev_t if self._disk_prev_t else 1.0
        disk_r_rate = 0.0
        disk_w_rate = 0.0
        if self._disk_prev:
            for dev, cur in disk2.items():
                prev = self._disk_prev.get(dev, {"read_sectors": 0, "write_sectors": 0})
                disk_r_rate += max(0.0, (cur["read_sectors"] - prev["read_sectors"]) * 512 / dt_disk)
                disk_w_rate += max(0.0, (cur["write_sectors"] - prev["write_sectors"]) * 512 / dt_disk)
        self._disk_prev = disk2
        self._disk_prev_t = now

        proc_cpu = {p["pid"]: p.get("cpu", 0.0) for p in procs}
        self._ui_apply_pending = True
        GLib.idle_add(self._apply_data, cpu_pcts, mem, net2, net_deltas,
                      disk_r_rate, disk_w_rate, procs, proc_cpu, proc_total, parts)

    def _apply_data(self, cpu_pcts, mem, net2, net_deltas,
                    disk_r_rate, disk_w_rate, procs, proc_cpu, proc_total, parts):
        self._ui_apply_pending = False
        cpu_pct = cpu_pcts[0]

        # Overview gauges
        self._set_gauge("cpu",  f"{cpu_pct:.1f}%",  cpu_pct / 100.0,
                        f"{len(cpu_pcts)-1} core{'s' if len(cpu_pcts)>2 else ''}")
        self._set_gauge("mem",  f"{mem['pct']:.1f}%", mem["pct"] / 100.0,
                        f"{_fmt_bytes(mem['used'])} / {_fmt_bytes(mem['total'])}")
        self._set_gauge("swap", f"{mem['swap_pct']:.1f}%", mem["swap_pct"] / 100.0,
                        f"{_fmt_bytes(mem['swap_used'])} / {_fmt_bytes(mem['swap_total'])}")
        disk_total_rate = disk_r_rate + disk_w_rate
        max_disk = 500 * 1024 * 1024
        self._set_gauge("disk", _fmt_rate(disk_total_rate),
                        min(1.0, disk_total_rate / max_disk),
                        f"R:{_fmt_rate(disk_r_rate)}  W:{_fmt_rate(disk_w_rate)}")

        # Top processes by memory
        top = sorted(procs, key=lambda p: proc_cpu.get(p["pid"], 0), reverse=True)[:12]
        self._ov_proc_store.clear()
        for p in top:
            self._ov_proc_store.append([p["pid"], p["name"],
                                        p["state"], _fmt_bytes(p["mem"])])

        # Process tab
        process_page_active = self._nb.get_current_page() == 1
        if process_page_active:
            self._proc_store.clear()
            for p in sorted(procs, key=lambda p: proc_cpu.get(p["pid"], 0), reverse=True):
                self._proc_store.append([p["pid"], p["name"],
                                         proc_cpu.get(p["pid"], 0.0),
                                         _fmt_bytes(p["mem"]), p["state"]])
        if proc_total and proc_total > len(procs):
            self._proc_count_lbl.set_text(f"showing top {len(procs)} of {proc_total} processes")
        else:
            self._proc_count_lbl.set_text(f"{len(procs)} processes")

        # Resource graphs
        self._cpu_hist.push(cpu_pct)
        self._mem_hist.push(mem["pct"])
        max_net = 100 * 1024 * 1024
        total_rx = sum(d.get("rx_rate", 0) for d in net_deltas.values())
        total_tx = sum(d.get("tx_rate", 0) for d in net_deltas.values())
        self._rx_hist.push(min(100.0, total_rx / max_net * 100))
        self._tx_hist.push(min(100.0, total_tx / max_net * 100))
        self._disk_r_hist.push(min(100.0, disk_r_rate / max_disk * 100))
        self._disk_w_hist.push(min(100.0, disk_w_rate / max_disk * 100))

        if "cpu" in self._res_labels:
            self._res_labels["cpu"][0].set_text(f"{cpu_pct:.1f}%")
            self._res_labels["cpu"][1].set_fraction(cpu_pct / 100.0)
            self._res_labels["mem"][0].set_text(f"{mem['pct']:.1f}%")
            self._res_labels["mem"][1].set_fraction(mem["pct"] / 100.0)
            self._res_labels["net_rx"][0].set_text(_fmt_rate(total_rx))
            self._res_labels["net_rx"][1].set_fraction(min(1.0, total_rx / max_net))
            self._res_labels["net_tx"][0].set_text(_fmt_rate(total_tx))
            self._res_labels["net_tx"][1].set_fraction(min(1.0, total_tx / max_net))
            self._res_labels["disk_r"][0].set_text(_fmt_rate(disk_r_rate))
            self._res_labels["disk_r"][1].set_fraction(min(1.0, disk_r_rate / max_disk))
            self._res_labels["disk_w"][0].set_text(_fmt_rate(disk_w_rate))
            self._res_labels["disk_w"][1].set_fraction(min(1.0, disk_w_rate / max_disk))

        # Disk tab
        self._rebuild_disk_tab(parts)

        # Net tab
        self._rebuild_net_tab(net2, net_deltas)

        # Uptime
        self._uptime_lbl.set_text(f"up {_uptime()}")

    def _set_gauge(self, key: str, val: str, frac: float, sub: str):
        val_lbl, bar, sub_lbl = self._gauge_widgets[key]
        val_lbl.set_text(val)
        bar.set_fraction(max(0.0, min(1.0, frac)))
        sub_lbl.set_text(sub)

    def _show_error(self, msg: str):
        d = Gtk.MessageDialog(transient_for=self, modal=True,
                              message_type=Gtk.MessageType.ERROR,
                              buttons=Gtk.ButtonsType.OK, text=msg)
        d.run(); d.destroy()


def main():
    if "DISPLAY" not in os.environ and "WAYLAND_DISPLAY" not in os.environ:
        sys.exit(1)
    win = SysMonitorWindow()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
