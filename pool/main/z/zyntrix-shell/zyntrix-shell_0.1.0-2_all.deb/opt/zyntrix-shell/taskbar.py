#!/usr/bin/env python3
"""Optional persistent taskbar for ZyntrixOS."""

from __future__ import annotations

import datetime
import subprocess
from typing import List, Optional

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk

from style import load_shared_css
from window_manager import WindowManagerClient, WindowState
from window_snapshot import WindowSnapshotStore


class Taskbar(Gtk.Window):
    def __init__(
        self,
        client: Optional[WindowManagerClient] = None,
        *,
        load_css: bool = True,
        snapshot_store: Optional[WindowSnapshotStore] = None,
    ) -> None:
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._client = client or WindowManagerClient()
        if client is None:
            self._client.ensure_daemon()
        if load_css:
            load_shared_css()
        self._owns_snapshot_store = snapshot_store is None
        self._snapshot_store = snapshot_store or WindowSnapshotStore(client=self._client)
        self._window_buttons: dict[str, Gtk.Button] = {}
        self._window_order: list[str] = []

        self.set_title("Zyntrix Taskbar")
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_resizable(False)
        self.stick()
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.get_style_context().add_class("taskbar-window")

        outer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        outer.set_margin_start(10)
        outer.set_margin_end(10)
        outer.set_margin_top(6)
        outer.set_margin_bottom(6)
        self.add(outer)

        launcher = Gtk.Button(label="[Z]")
        launcher.get_style_context().add_class("taskbar-launcher")
        launcher.connect("clicked", self._toggle_launcher)
        outer.pack_start(launcher, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        scroller.set_hexpand(True)
        scroller.set_shadow_type(Gtk.ShadowType.NONE)

        self._window_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self._window_box.get_style_context().add_class("taskbar-box")
        scroller.add(self._window_box)
        outer.pack_start(scroller, True, True, 0)

        self._clock = Gtk.Label(label="")
        self._clock.get_style_context().add_class("taskbar-clock")
        outer.pack_end(self._clock, False, False, 0)

        self.connect("realize", lambda *_: self._place())
        self.connect("size-allocate", lambda *_: self._place())
        self.connect("destroy", self._on_destroy)
        GLib.timeout_add_seconds(1, self._tick_clock)

        self._tick_clock()
        self._snapshot_store.subscribe(self._on_snapshot_changed)

    # ------------------------------------------------------------------
    def _place(self) -> None:
        screen = self.get_screen() or Gdk.Screen.get_default()
        if not screen:
            return
        width = screen.get_width()
        height = screen.get_height()
        bar_height = 44
        self.set_size_request(width, bar_height)
        self.move(0, max(0, height - bar_height))

    def _tick_clock(self) -> bool:
        self._clock.set_text(datetime.datetime.now().strftime("%H:%M"))
        return True

    def _toggle_launcher(self, *_args) -> None:
        try:
            subprocess.Popen(
                ["zyntrix-toggle-launcher"],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass

    # Internal windows to exclude from taskbar
    _INTERNAL_TITLES = ("zyntrix-shell", "zyntrix taskbar", "windows", "zyntrixos stats",
                        "launch", "window controls")

    def _is_internal_window(self, state: WindowState) -> bool:
        """Check if window is internal UI that shouldn't appear in taskbar."""
        if state.internal:
            return True
        title_lower = (state.title or "").lower()
        return any(t in title_lower for t in self._INTERNAL_TITLES)

    def _window_label(self, state: WindowState) -> str:
        """Get user-friendly window label, avoiding hex IDs."""
        # Prefer label, then app_id, then title
        text = state.label or state.app_id or state.title or ""
        # Check if it looks like a hex window ID
        if text.lower().startswith("0x") and len(text) >= 8:
            # Fall back to wclass or generic name
            text = state.wclass or "App"
        return text

    def _on_snapshot_changed(self, store: WindowSnapshotStore) -> None:
        # Filter out internal windows
        app_windows = [s for s in store.states if not self._is_internal_window(s)]
        self._apply_windows(app_windows)

    def _apply_windows(self, windows: List[WindowState]) -> None:
        order = [state.wid for state in windows]
        stale = [wid for wid in self._window_buttons if wid not in set(order)]
        for wid in stale:
            btn = self._window_buttons.pop(wid, None)
            if btn is None:
                continue
            parent = btn.get_parent()
            if parent is self._window_box:
                self._window_box.remove(btn)
            btn.destroy()

        if order != self._window_order:
            for child in self._window_box.get_children():
                self._window_box.remove(child)
            for state in windows:
                btn = self._window_buttons.get(state.wid)
                if btn is None:
                    btn = self._window_button(state)
                    self._window_buttons[state.wid] = btn
                self._update_window_button(btn, state)
                self._window_box.pack_start(btn, False, False, 0)
            self._window_order = order
        else:
            for state in windows:
                btn = self._window_buttons.get(state.wid)
                if btn is not None:
                    self._update_window_button(btn, state)

        self._window_box.show_all()

    def _window_button(self, state: WindowState) -> Gtk.Button:
        btn = Gtk.Button(label="")
        btn.get_style_context().add_class("taskbar-window-btn")
        btn.connect("clicked", self._on_window_clicked)
        btn.connect("button-press-event", self._on_window_button_press)
        self._update_window_button(btn, state)
        return btn

    def _update_window_button(self, btn: Gtk.Button, state: WindowState) -> None:
        prefix = "◆" if state.state == "minimized" else ("◇" if state.state == "floating" else "●")
        label = self._window_label(state)
        text = f"{prefix} {label}"
        if btn.get_label() != text:
            btn.set_label(text)
        btn._wid = state.wid  # type: ignore[attr-defined]
        btn._current_state = state  # type: ignore[attr-defined]
        ctx = btn.get_style_context()
        if state.focused:
            ctx.add_class("taskbar-window-btn-active")
        else:
            ctx.remove_class("taskbar-window-btn-active")
        if state.state == "minimized":
            ctx.add_class("taskbar-window-btn-minimized")
        else:
            ctx.remove_class("taskbar-window-btn-minimized")

    def _on_window_clicked(self, btn: Gtk.Button) -> None:
        wid = getattr(btn, "_wid", "")
        if wid:
            self._client.focus(wid)

    def _on_window_button_press(self, widget, event: Gdk.EventButton) -> bool:
        if event.button != 3:
            return False
        state = getattr(widget, "_current_state", None)
        if not isinstance(state, WindowState):
            return False
        menu = Gtk.Menu()
        for label, callback in (
            ("Focus / Restore", lambda *_: self._client.focus(state.wid)),
            ("Minimize", lambda *_: self._client.minimize(state.wid)),
            ("Undock" if state.state != "floating" else "Redock",
             lambda *_: self._client.undock(state.wid) if state.state != "floating" else self._client.redock(state.wid)),
            ("Close", lambda *_: self._client.close(state.wid)),
        ):
            item = Gtk.MenuItem(label=label)
            item.connect("activate", callback)
            menu.append(item)
        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def _on_destroy(self, *_args) -> None:
        if self._owns_snapshot_store:
            self._snapshot_store.close()


def main() -> None:
    win = Taskbar()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
