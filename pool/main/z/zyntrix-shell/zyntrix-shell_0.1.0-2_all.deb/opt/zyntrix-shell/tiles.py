"""
Tile definitions for ZyntrixOS shell.
Loaded from ~/.config/zyntrix/config.toml if present, else built-in defaults.
Each tile has a primary command and a fallbacks list — the launcher tries each
in order until one resolves on PATH.
"""

import os
import sys
from dataclasses import dataclass, field
from typing import Optional

try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib  # type: ignore
    except ImportError:
        tomllib = None  # type: ignore

_SHELL_DIR = os.path.dirname(os.path.abspath(__file__))


@dataclass
class Tile:
    id: str
    label: str
    subtitle: str
    icon: str                          # freedesktop icon name or absolute path
    command: list                      # primary argv
    fallbacks: list = field(default_factory=list)  # list of argv lists to try
    color: Optional[str] = None        # per-tile accent override (CSS colour)
    enabled: bool = True
    live_only: bool = False


# ── Terminal helpers used in fallback chains ─────────────────────────────────
def _term(cmd: str) -> list:
    """Return an xterm that runs cmd, gracefully falling back to bash."""
    return ["xterm", "-e", "bash", "-c", f"{cmd} || bash"]


def is_live_system() -> bool:
    try:
        with open("/proc/cmdline", "r") as fh:
            cmdline = fh.read()
    except Exception:
        cmdline = ""
    return (
        os.path.exists("/live/aufs")
        or os.path.exists("/run/live/medium")
        or os.path.exists("/lib/live/mount/medium")
        or "boot=live" in cmdline
        or "fromiso" in cmdline
    )


def _tile_visible(tile: Tile) -> bool:
    if tile.live_only or tile.id == "installer":
        return is_live_system()
    return True


DEFAULT_TILES: list[Tile] = [
    Tile(
        id="projects",
        label="Projects",
        subtitle="Devbox",
        icon="applications-development",
        command=[sys.executable, os.path.join(_SHELL_DIR, "projects.py")],
        fallbacks=[
            # Fallback: open editor directly if projects panel fails
            ["codium", "--new-window", "--no-sandbox"],
            ["code", "--new-window", "--no-sandbox",
             "--user-data-dir=/root/.config/code-root"],
            ["vscodium", "--no-sandbox"],
            ["geany"],
        ],
    ),
    Tile(
        id="terminal",
        label="Terminal",
        subtitle="Shell",
        icon="utilities-terminal",
        # Foot ships in install.list as the default terminal; xterm is the
        # last-resort fallback to guarantee the tile always lights green.
        command=["foot"],
        fallbacks=[
            ["alacritty"],
            ["kitty"],
            ["xfce4-terminal"],
            ["gnome-terminal"],
            ["mate-terminal"],
            ["lxterminal"],
            ["xterm"],
        ],
    ),
    Tile(
        id="agents",
        label="Agents",
        subtitle="AI Workspace",
        icon="applications-science",
        command=[sys.executable, os.path.join(_SHELL_DIR, "agents.py")],
        fallbacks=[
            [
                "foot", "--title", "Agents",
                "--", "tmux", "new-session", "-A", "-s", "agents",
                "-c", os.path.expanduser("~/agents"),
            ],
            ["alacritty", "--title", "Agents",
             "-e", "tmux", "new-session", "-A", "-s", "agents"],
            ["kitty", "--title", "Agents",
             "-e", "tmux", "new-session", "-A", "-s", "agents"],
            ["xfce4-terminal", "--title", "Agents",
             "-e", "tmux", "new-session", "-A", "-s", "agents"],
            _term("tmux new-session -A -s agents || bash"),
        ],
    ),
    Tile(
        id="browser",
        label="Browser",
        subtitle="Web",
        icon="web-browser",
        command=["firefox-esr", "--allow-downgrade"],
        fallbacks=[
            ["bash", "-c",
             "HOME=/root firefox-esr --no-remote --profile /root/.mozilla/firefox-root 2>/dev/null"],
            ["chromium", "--no-sandbox"],
            ["chromium-browser", "--no-sandbox"],
            ["google-chrome", "--no-sandbox", "--user-data-dir=/root/.config/chrome-root"],
            ["epiphany"],
            ["midori"],
            ["surf"],
        ],
    ),
    Tile(
        id="files",
        label="Files",
        subtitle="File Manager",
        icon="system-file-manager",
        command=[sys.executable, os.path.join(_SHELL_DIR, "filemanager.py")],
        fallbacks=[
            ["thunar"],
            ["pcmanfm"],
            ["nautilus"],
            ["nemo"],
            ["dolphin"],
            ["nautilus"],
            ["caja"],
            ["doublecmd-gtk"],
            ["mc"],
            ["foot", "--title", "Files", "bash", "-c",
             "nnn || ranger || vifm || mc || ls -la --color=always; read -rp 'press enter to close'"],
        ],
    ),
    Tile(
        id="monitor",
        label="Monitor",
        subtitle="System",
        icon="utilities-system-monitor",
        command=[sys.executable, os.path.join(_SHELL_DIR, "sysmonitor.py")],
        fallbacks=[
            ["gnome-system-monitor"],
            ["mate-system-monitor"],
            ["xfce4-taskmanager"],
            ["lxqt-taskmanager"],
            ["qps"],
            ["foot", "--title", "Monitor", "bash", "-c", "btop || htop || btop || top || ps aux"],
        ],
    ),
    Tile(
        id="store",
        label="Store",
        subtitle="Apps",
        icon="system-software-install",
        command=[sys.executable, os.path.join(_SHELL_DIR, "store.py")],
        fallbacks=[],
    ),
    Tile(
        id="installer",
        label="Install",
        subtitle="Hard Drive",
        icon="drive-harddisk-symbolic",
        command=[sys.executable, os.path.join(_SHELL_DIR, "installer.py")],
        fallbacks=[
            ["python3", os.path.join(_SHELL_DIR, "installer.py")],
            ["cli-installer"],
        ],
        color="#00d4aa",
        live_only=True,
    ),
    Tile(
        id="settings",
        label="Settings",
        subtitle="System",
        icon="preferences-system",
        command=[sys.executable, os.path.join(_SHELL_DIR, "settings.py")],
        fallbacks=[],
    ),
]


def _find_config() -> Optional[str]:
    xdg = os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config"))
    path = os.path.join(xdg, "zyntrix", "config.toml")
    return path if os.path.exists(path) else None


def _load_toml(path: str) -> dict:
    if tomllib is None:
        return {}
    try:
        with open(path, "rb") as fh:
            return tomllib.load(fh)
    except Exception:
        return {}


def load_tiles() -> list[Tile]:
    """Return tile list from config, or defaults if none / empty."""
    config_path = _find_config()
    if config_path is None:
        return [t for t in DEFAULT_TILES if t.enabled and _tile_visible(t)]

    data = _load_toml(config_path)
    tiles_data = data.get("tiles", [])
    if not tiles_data:
        return [t for t in DEFAULT_TILES if t.enabled and _tile_visible(t)]

    result = []
    for td in tiles_data:
        try:
            result.append(Tile(
                id=td["id"],
                label=td["label"],
                subtitle=td.get("subtitle", ""),
                icon=td.get("icon", "applications-other"),
                command=td["command"] if isinstance(td["command"], list) else [td["command"]],
                fallbacks=td.get("fallbacks", []),
                color=td.get("color"),
                enabled=td.get("enabled", True),
                live_only=td.get("live_only", td.get("id") == "installer"),
            ))
        except KeyError:
            continue
    configured_ids = {t.id for t in result}
    for tile in DEFAULT_TILES:
        if tile.id == "installer" and tile.id not in configured_ids:
            result.append(tile)
    visible = [t for t in result if t.enabled and _tile_visible(t)]
    return visible or [t for t in DEFAULT_TILES if t.enabled and _tile_visible(t)]


def load_theme(data: dict) -> dict:
    defaults = {
        "accent":     "#00f0c8",
        "background": "#0a0b0f",
        "surface":    "#12141a",
        "text":       "#e8eaf0",
        "columns":    4,
    }
    return {**defaults, **(data.get("theme", {}) if data else {})}


def load_config() -> tuple[list[Tile], dict]:
    """Return (tiles, theme_dict). Safe — never raises."""
    config_path = _find_config()
    data = _load_toml(config_path) if config_path else {}
    return load_tiles(), load_theme(data)
