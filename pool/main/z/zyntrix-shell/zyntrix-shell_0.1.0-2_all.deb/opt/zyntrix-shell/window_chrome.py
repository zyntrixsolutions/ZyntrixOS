#!/usr/bin/env python3
"""Floating control bar for undocked windows."""

from __future__ import annotations

from typing import Optional

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk

from style import load_shared_css
from window_manager import WindowManagerClient, WindowState
from window_snapshot import WindowSnapshotStore


class WindowChrome(Gtk.Window):
    def __init__(
        self,
        client: Optional[WindowManagerClient] = None,
        *,
        load_css: bool = True,
        snapshot_store: Optional[WindowSnapshotStore] = None,
    ) -> None:
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._client = client or WindowManagerClient()
        if client is None:
            self._client.ensure_daemon()
        if load_css:
            load_shared_css()
        self._owns_snapshot_store = snapshot_store is None
        self._snapshot_store = snapshot_store or WindowSnapshotStore(client=self._client)
        self._current_wid = ""

        self.set_title("Window Controls")
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_resizable(False)
        self.get_style_context().add_class("window-chrome")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.set_margin_start(8)
        box.set_margin_end(8)
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        self.add(box)

        self._title = Gtk.Label(label="")
        self._title.get_style_context().add_class("window-chrome-title")
        self._title.set_ellipsize(3)
        self._title.set_hexpand(True)
        self._title.set_halign(Gtk.Align.START)
        box.pack_start(self._title, True, True, 0)

        for label, callback in (
            ("-", self._on_minimize),
            ("[]", self._on_redock),
            ("x", self._on_close),
        ):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("window-chrome-btn")
            btn.connect("clicked", callback)
            box.pack_start(btn, False, False, 0)

        self.connect("destroy", self._on_destroy)
        self._snapshot_store.subscribe(self._on_snapshot_changed)

    # ------------------------------------------------------------------
    @staticmethod
    def _focused_floating(windows: list[WindowState]) -> Optional[WindowState]:
        for state in windows:
            if state.focused and state.state == "floating":
                return state
        for state in windows:
            if state.state == "floating":
                return state
        return None

    def _on_snapshot_changed(self, store: WindowSnapshotStore) -> None:
        self._apply_state(self._focused_floating(store.states))

    def _apply_state(self, state: Optional[WindowState]) -> None:
        if state is None:
            self._current_wid = ""
            self.hide()
            return
        self._current_wid = state.wid
        self._title.set_text(state.title or state.label or state.app_id or "Window")
        x = max(0, state.geometry.x + 12)
        y = max(0, state.geometry.y + 8)
        self.show_all()
        self.move(x, y)

    def _on_minimize(self, *_args) -> None:
        if self._current_wid:
            self._client.minimize(self._current_wid)
        self.hide()

    def _on_redock(self, *_args) -> None:
        if self._current_wid:
            self._client.redock(self._current_wid)
        self.hide()

    def _on_close(self, *_args) -> None:
        if self._current_wid:
            self._client.close(self._current_wid)
        self.hide()

    def _on_destroy(self, *_args) -> None:
        if self._owns_snapshot_store:
            self._snapshot_store.close()


def main() -> None:
    win = WindowChrome()
    win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
