#!/usr/bin/env python3
"""Shared window snapshot loader/monitor for GTK consumers."""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

import gi

gi.require_version("Gio", "2.0")
from gi.repository import Gio, GLib

from window_manager import (
    STATE_PATH,
    WindowManager,
    WindowManagerClient,
    WindowState,
    _stable_json,
)


class WindowSnapshotStore:
    """Monitors the WM state file, parses it once, and fans out updates."""

    def __init__(
        self,
        client: Optional[WindowManagerClient] = None,
        *,
        state_path: str = STATE_PATH,
        refresh_delay_ms: int = 120,
    ) -> None:
        self._client = client or WindowManagerClient()
        if client is None:
            self._client.ensure_daemon()
        self._state_path = state_path
        self._refresh_delay_ms = refresh_delay_ms
        self._monitor = None
        self._refresh_source = 0
        self._callbacks: list[Callable[["WindowSnapshotStore"], None]] = []
        self._snapshot: dict = {}
        self._states: list[WindowState] = []
        self._signature = ""
        self._generated_at = 0.0
        self._install_monitor()
        self.refresh_now()

    @property
    def generated_at(self) -> float:
        return self._generated_at

    @property
    def snapshot(self) -> dict:
        return dict(self._snapshot)

    @property
    def states(self) -> list[WindowState]:
        return list(self._states)

    def subscribe(
        self,
        callback: Callable[["WindowSnapshotStore"], None],
        *,
        emit_current: bool = True,
    ) -> None:
        if callback not in self._callbacks:
            self._callbacks.append(callback)
        if emit_current and self._snapshot:
            callback(self)

    def unsubscribe(self, callback: Callable[["WindowSnapshotStore"], None]) -> None:
        self._callbacks = [item for item in self._callbacks if item is not callback]

    def close(self) -> None:
        if self._refresh_source:
            GLib.source_remove(self._refresh_source)
            self._refresh_source = 0
        if self._monitor is not None:
            try:
                self._monitor.cancel()
            except Exception:
                pass
            self._monitor = None
        self._callbacks.clear()

    def refresh_now(self) -> None:
        self._apply_snapshot()

    def _install_monitor(self) -> None:
        path = Path(self._state_path)
        target = Gio.File.new_for_path(str(path if path.exists() else path.parent))
        try:
            if path.exists():
                self._monitor = target.monitor_file(Gio.FileMonitorFlags.NONE, None)
            else:
                self._monitor = target.monitor_directory(Gio.FileMonitorFlags.NONE, None)
            self._monitor.connect("changed", self._queue_refresh)
        except Exception:
            self._monitor = None

    def _queue_refresh(self, *_args) -> bool:
        if self._refresh_source:
            return False
        self._refresh_source = GLib.timeout_add(self._refresh_delay_ms, self._apply_snapshot)
        return False

    def _load_snapshot(self) -> dict:
        snapshot = WindowManager.load_snapshot(self._state_path)
        if snapshot:
            return snapshot
        return self._client.snapshot()

    def _apply_snapshot(self) -> bool:
        self._refresh_source = 0
        snapshot = self._load_snapshot()
        if not snapshot:
            return False
        body = {k: v for k, v in snapshot.items() if k != "generated_at"}
        signature = _stable_json(body)
        if signature and signature == self._signature:
            return False

        states: list[WindowState] = []
        for item in snapshot.get("windows") or []:
            if isinstance(item, dict):
                try:
                    states.append(WindowState.from_dict(item))
                except Exception:
                    continue

        self._snapshot = snapshot
        self._states = states
        self._generated_at = float(snapshot.get("generated_at") or 0.0)
        self._signature = signature
        for callback in list(self._callbacks):
            try:
                callback(self)
            except Exception:
                continue
        return False
