#! /usr/bin/python3
"""Small herbstluftwm/wmctrl helpers for ZyntrixOS window management."""

from __future__ import annotations

import shutil
import subprocess
import sys
import time

from window_manager import WindowManagerClient


HC = shutil.which("herbstclient") or ""
WMCTRL = shutil.which("wmctrl") or ""
_CLIENT = WindowManagerClient()


def _run(args: list[str], timeout: float = 0.8) -> bool:
    try:
        proc = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            check=False,
        )
        return proc.returncode == 0
    except Exception:
        return False


def _check_output(args: list[str], timeout: float = 0.8) -> str:
    try:
        return subprocess.check_output(
            args,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        ).strip()
    except Exception:
        return ""


def _norm_wid(wid: str) -> str:
    wid = (wid or "").strip()
    if not wid:
        return ""
    try:
        return f"0x{int(wid, 16):x}"
    except Exception:
        return wid


def _hc(args: list[str], timeout: float = 0.8) -> bool:
    return bool(HC) and _run([HC] + args, timeout=timeout)


def _hc_out(args: list[str], timeout: float = 0.8) -> str:
    return _check_output([HC] + args, timeout=timeout) if HC else ""


def _hlwm_ready() -> bool:
    return bool(HC) and _hc(["true"], timeout=0.4)


def _hc_int(attr: str, default: int = 0) -> int:
    raw = _hc_out(["get_attr", attr])
    try:
        return int(raw)
    except Exception:
        return default


def _hc_bool(attr: str, default: bool = False) -> bool:
    raw = _hc_out(["get_attr", attr]).lower()
    if raw in ("true", "on", "1"):
        return True
    if raw in ("false", "off", "0"):
        return False
    return default


def activate_window(wid: str) -> None:
    """Focus and raise a window using hlwm's native state plus EWMH."""
    target = _norm_wid(wid)
    if not target:
        return

    used_hlwm = False
    if HC:
        # Batch focus+raise into one herbstclient process.  Before this was
        # two spawns, plus a follow-up focus check; during launch bursts that
        # created visible stalls on single/dual-core CPUs.
        used_hlwm = _hc(["chain", ",", "jumpto", target, ",", "raise", target])
    if WMCTRL and not used_hlwm:
        _run([WMCTRL, "-ia", target])


def _split_focused_stack(direction: str) -> bool:
    align, shift = _split_args(direction)
    return _hc(["chain", ",", "split", align, "0.5", ",", "shift", shift])


def _split_args(direction: str) -> tuple[str, str]:
    direction = (direction or "right").lower()
    if direction in ("bottom", "down", "vertical", "v"):
        return "bottom", "down"
    return "right", "right"


def smart_split(direction: str = "right") -> int:
    """Split only when there is a hidden client to reveal.

    Plain hlwm split creates an empty frame and repeated presses recursively
    shrink the useful area. This command keeps manual splits productive: if
    the current frame has a stack, it splits and moves the focused window into
    the new frame; otherwise it only explodes existing hidden stacks.
    """
    if not _hlwm_ready():
        return 1
    if _hc_bool("tags.focus.floating"):
        return 0

    clients = _hc_int("tags.focus.client_count")
    frames = _hc_int("tags.focus.frame_count")
    curframe_clients = _hc_int("tags.focus.curframe_wcount")

    if curframe_clients > 1:
        return 0 if _split_focused_stack(direction) else 1
    if clients > frames:
        return 0 if _hc(["split", "explode"]) else 1
    return 0


def autotile(wid: str) -> int:
    """Focus a newly managed client and reveal it if it landed in a stack."""
    target = _norm_wid(wid)
    if not target or not _hlwm_ready():
        return 1

    # Let hlwm finish managing the client before querying frame attributes.
    time.sleep(0.12)
    _hc(["jumpto", target])

    if (
        not _hc_bool(f"clients.{target}.floating")
        and not _hc_bool(f"clients.{target}.fullscreen")
        and not _hc_bool("tags.focus.floating")
    ):
        clients = _hc_int("tags.focus.client_count")
        frames = _hc_int("tags.focus.frame_count")
        curframe_clients = _hc_int("tags.focus.curframe_wcount")
        if curframe_clients > 1 or clients > frames:
            _hc(["split", "explode"])

    activate_window(target)
    return 0


# ═════════════════════════════════════════════════════════════════════════════
# TUI Integration Functions (added for zyntrix-tui)
# ═════════════════════════════════════════════════════════════════════════════


def get_workspaces() -> list[dict]:
    """Return all 9 workspace states for TUI consumption.
    
    Returns list of dicts with keys: idx, name, occupied, current
    """
    wss = []
    try:
        tags = _hc_out(["tag_status"])
        if not tags:
            # Fallback if herbstclient not available
            return [{"idx": i, "name": str(i), "occupied": False, "current": i == 1} 
                    for i in range(1, 10)]
        
        parts = tags.split("\t")
        for i, t in enumerate(parts[1:], 1):
            # Tag status codes:
            # . empty, # current, - not empty, + viewed but not focused
            # : urgent, ! urgent + current, % urgent + viewed
            occupied = t[0] in ("#", "+", ":", "!", "-", "%")
            current = t[0] == "#"
            wss.append({
                "idx": i,
                "name": str(i),
                "occupied": occupied,
                "current": current,
            })
    except Exception:
        # Fallback
        for i in range(1, 10):
            wss.append({"idx": i, "name": str(i), "occupied": False, "current": i == 1})
    return wss


def get_windows(workspace: int = None) -> list[dict]:
    """Return window list for current or specified workspace.
    
    Returns list of dicts with keys: wid, title, class, workspace
    """
    try:
        windows = []
        for state in _CLIENT.get_all_windows():
            entry = {
                "wid": state.wid,
                "title": state.title or state.label or "Unknown",
                "class": state.wclass or state.app_id,
                "workspace": state.workspace,
                "floating": state.state == "floating",
                "state": state.state,
            }
            windows.append(entry)
        if workspace is None:
            return windows
        return [w for w in windows if str(workspace) == str(w["workspace"])]
    except Exception:
        pass

    wins = []
    if workspace and isinstance(workspace, int):
        _hc(["use_index", str(workspace - 1)])
    
    try:
        out = _hc_out(["clients"])
        if not out:
            return wins
        
        for wid in out.split():
            if not wid.strip():
                continue
            title = _hc_out(["get_attr", f"clients.{wid}.title"])
            cls = _hc_out(["get_attr", f"clients.{wid}.class"])
            tag = _hc_out(["get_attr", f"clients.{wid}.tag"])
            floating = _hc_bool(f"clients.{wid}.floating")
            wins.append({
                "wid": wid,
                "title": title or "Unknown",
                "class": cls or "",
                "workspace": tag,
                "floating": floating,
            })
    except Exception:
        pass
    return wins


def switch_workspace(idx: int) -> bool:
    """Switch to workspace by index (1-9)."""
    if not 1 <= idx <= 9:
        return False
    return _hc(["use_index", str(idx - 1)])


def focus_window(wid: str) -> bool:
    """Focus window by ID."""
    target = _norm_wid(wid)
    if not target:
        return False
    try:
        return bool(_CLIENT.focus(target))
    except Exception:
        return _hc(["jumpto", target])


def close_window(wid: str) -> bool:
    """Close window by ID."""
    target = _norm_wid(wid)
    if not target:
        return False
    try:
        return bool(_CLIENT.close(target))
    except Exception:
        return _hc(["close", target])


def move_window(wid: str, workspace: int) -> bool:
    """Move window to workspace (1-9)."""
    target = _norm_wid(wid)
    if not target or not 1 <= workspace <= 9:
        return False
    try:
        return bool(_CLIENT.move_to_workspace(target, str(workspace)))
    except Exception:
        return _hc(["move_index", str(workspace - 1), target])


def toggle_float(wid: str) -> bool:
    """Toggle floating state of window."""
    target = _norm_wid(wid)
    if not target:
        return False
    try:
        return bool(_CLIENT.toggle_undock(target))
    except Exception:
        return _hc(["set_attr", f"clients.{target}.floating", "toggle"])


def minimize_window(wid: str) -> bool:
    target = _norm_wid(wid)
    return bool(target) and bool(_CLIENT.minimize(target))


def restore_window(wid: str) -> bool:
    target = _norm_wid(wid)
    return bool(target) and bool(_CLIENT.restore(target))


def undock_window(wid: str) -> bool:
    target = _norm_wid(wid)
    return bool(target) and bool(_CLIENT.undock(target))


def redock_window(wid: str) -> bool:
    target = _norm_wid(wid)
    return bool(target) and bool(_CLIENT.redock(target))


def get_layout() -> str:
    """Get current layout name."""
    return _hc_out(["get_attr", "tags.focus.layout"])


def set_layout(name: str) -> bool:
    """Set layout by name (e.g., 'vertical', 'horizontal', 'max')."""
    return _hc(["set_layout", name])


# ═════════════════════════════════════════════════════════════════════════════
# Main CLI
# ═════════════════════════════════════════════════════════════════════════════

def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print(
            "usage: wm_control.py activate WID | smart-split DIR | autotile WID | minimize WID | restore WID | undock WID | redock WID",
            file=sys.stderr,
        )
        return 2
    cmd = argv[1]
    if cmd == "activate" and len(argv) >= 3:
        activate_window(argv[2])
        return 0
    if cmd == "smart-split":
        return smart_split(argv[2] if len(argv) >= 3 else "right")
    if cmd == "autotile" and len(argv) >= 3:
        return autotile(argv[2])
    if cmd == "minimize" and len(argv) >= 3:
        return 0 if minimize_window(argv[2]) else 1
    if cmd == "restore" and len(argv) >= 3:
        return 0 if restore_window(argv[2]) else 1
    if cmd == "undock" and len(argv) >= 3:
        return 0 if undock_window(argv[2]) else 1
    if cmd == "redock" and len(argv) >= 3:
        return 0 if redock_window(argv[2]) else 1
    print(f"unknown command: {cmd}", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
