#!/usr/bin/env python3
"""Event-driven herbstluftwm/X11 daemon for ZyntrixOS window state."""

from __future__ import annotations

import argparse
import json
import os
import signal
import socketserver
import subprocess
import threading
import time
from typing import Any, Optional, Sequence

try:
    from Xlib import X
except Exception:  # pragma: no cover - optional at runtime
    X = None

from window_manager import SOCKET_PATH, WindowManager, _list_hex_tokens, _norm_wid


_RESTORE_STAMP = os.path.join(os.path.dirname(SOCKET_PATH), "zyntrix-wm-restore.json")


class _UnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True


class _RequestHandler(socketserver.StreamRequestHandler):
    def handle(self) -> None:
        daemon = getattr(self.server, "daemon_ref", None)
        while True:
            line = self.rfile.readline(262144)
            if not line:
                return
            try:
                request = json.loads(line.decode("utf-8", errors="replace")) if line else {}
            except Exception:
                request = {}
            response = daemon.handle_request(request) if daemon else {"ok": False, "error": "no_daemon"}
            self.wfile.write((json.dumps(response) + "\n").encode("utf-8"))
            try:
                self.wfile.flush()
            except Exception:
                return


class WindowManagerDaemon:
    def __init__(self, *, socket_path: str = SOCKET_PATH, restore_session: bool = False) -> None:
        self.socket_path = socket_path
        self.restore_session_on_start = restore_session
        self.manager = WindowManager(enable_x11=True)
        self.running = threading.Event()
        self.running.set()
        self.server: Optional[_UnixServer] = None
        self._threads: list[threading.Thread] = []
        self._refresh_lock = threading.Lock()
        self._pending_wids: set[str] = set()
        self._pending_full_refresh = False
        self._last_refresh_t = 0.0

    # ------------------------------------------------------------------
    def start(self) -> None:
        self._prepare_socket()
        self.server = _UnixServer(self.socket_path, _RequestHandler)
        self.server.daemon_ref = self  # type: ignore[attr-defined]

        self.manager.refresh_all()
        self.manager.prepare_event_masks()

        if self.restore_session_on_start and self._should_restore_session():
            self.manager.restore_session()
            self.manager.refresh_all()
            self._mark_session_restored()

        self._start_thread(self._serve_socket, "wm-socket")
        self._start_thread(self._refresh_loop, "wm-refresh")
        self._start_thread(self._hlwm_idle_loop, "wm-hlwm")
        self._start_thread(self._x11_event_loop, "wm-x11")

        signal.signal(signal.SIGTERM, self._handle_signal)
        signal.signal(signal.SIGINT, self._handle_signal)

        try:
            while self.running.is_set():
                time.sleep(0.5)
        finally:
            self.stop()

    def stop(self) -> None:
        if not self.running.is_set():
            return
        self.running.clear()
        if self.server is not None:
            try:
                self.server.shutdown()
            except Exception:
                pass
            try:
                self.server.server_close()
            except Exception:
                pass
        try:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)
        except Exception:
            pass

    def _handle_signal(self, *_args) -> None:
        self.stop()

    def _start_thread(self, target, name: str) -> None:
        thread = threading.Thread(target=target, daemon=True, name=name)
        thread.start()
        self._threads.append(thread)

    def _prepare_socket(self) -> None:
        try:
            if os.path.exists(self.socket_path):
                os.unlink(self.socket_path)
        except Exception:
            pass
        os.makedirs(os.path.dirname(self.socket_path), exist_ok=True)

    def _restore_token(self) -> dict[str, str]:
        boot_id = ""
        try:
            with open("/proc/sys/kernel/random/boot_id", "r", encoding="utf-8") as handle:
                boot_id = handle.read().strip()
        except Exception:
            pass
        return {
            "boot_id": boot_id,
            "display": os.environ.get("DISPLAY", ""),
        }

    def _should_restore_session(self) -> bool:
        current = self._restore_token()
        try:
            with open(_RESTORE_STAMP, "r", encoding="utf-8") as handle:
                previous = json.load(handle)
        except Exception:
            return True
        return any(previous.get(key) != value for key, value in current.items())

    def _mark_session_restored(self) -> None:
        try:
            with open(_RESTORE_STAMP, "w", encoding="utf-8") as handle:
                json.dump(self._restore_token(), handle)
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _queue_refresh(self, wids: Optional[Sequence[str]] = None, *, full: bool = False) -> None:
        with self._refresh_lock:
            if full:
                self._pending_full_refresh = True
            for wid in wids or ():
                norm = _norm_wid(str(wid))
                if norm:
                    self._pending_wids.add(norm)

    def _flush_refresh(self, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_refresh_t < 0.12:
            return
        with self._refresh_lock:
            pending_full = self._pending_full_refresh
            pending_wids = set(self._pending_wids)
            if not pending_full and not pending_wids:
                return
            self._pending_full_refresh = False
            self._pending_wids.clear()
        if pending_full or len(pending_wids) > 8:
            self.manager.refresh_all()
            self._last_refresh_t = time.monotonic()
            return
        with self.manager._lock:
            for wid in sorted(pending_wids):
                self.manager.refresh_window(wid, write_snapshot=False)
            self.manager._sync_focus_state_locked()
            self.manager._purge_pending_intents()
            self.manager.save_session()
            self.manager.write_snapshot()
        self._last_refresh_t = time.monotonic()

    def _refresh_loop(self) -> None:
        while self.running.is_set():
            time.sleep(0.12)
            self._flush_refresh()

    def _serve_socket(self) -> None:
        if self.server is None:
            return
        self.server.serve_forever(poll_interval=0.3)

    def _hlwm_idle_loop(self) -> None:
        reconnect_delay = 0.6
        while self.running.is_set():
            try:
                proc = subprocess.Popen(
                    ["herbstclient", "--idle"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                )
            except Exception:
                time.sleep(reconnect_delay)
                reconnect_delay = min(2.0, reconnect_delay * 1.5)
                continue
            reconnect_delay = 0.6
            try:
                assert proc.stdout is not None
                for line in proc.stdout:
                    if not self.running.is_set():
                        break
                    tokens = _list_hex_tokens(line)
                    if tokens:
                        self._queue_refresh(tokens)
                    else:
                        self._queue_refresh(full=True)
            finally:
                try:
                    proc.terminate()
                except Exception:
                    pass
            if self.running.is_set():
                time.sleep(reconnect_delay)

    def _x11_event_loop(self) -> None:
        xdisplay = self.manager.xdisplay()
        if not xdisplay or X is None:
            return
        while self.running.is_set():
            try:
                event = xdisplay.next_event()
            except Exception:
                time.sleep(0.2)
                continue
            wid = self._event_wid(event)
            if not wid:
                continue
            if event.type in (X.CreateNotify, X.MapNotify, X.ReparentNotify):
                self.manager.watch_window(getattr(event, "window", None))
                self._queue_refresh([wid])
            elif event.type in (X.ConfigureNotify, X.PropertyNotify, X.FocusIn, X.FocusOut):
                self._queue_refresh([wid])
            elif event.type in (X.UnmapNotify, X.DestroyNotify):
                self._queue_refresh(full=True)

    @staticmethod
    def _event_wid(event) -> str:
        for attr in ("window", "drawable"):
            obj = getattr(event, attr, None)
            if obj is None:
                continue
            try:
                return _norm_wid(f"0x{obj.id:x}")
            except Exception:
                continue
        return ""

    # ------------------------------------------------------------------
    def handle_request(self, request: dict[str, Any]) -> dict[str, Any]:
        action = str(request.get("action", "")).strip().lower()
        if action == "ping":
            return {"ok": True, "status": "alive"}
        if action == "snapshot":
            return {"ok": True, "snapshot": self.manager.snapshot()}
        if action == "launch":
            command = list(request.get("command") or [])
            fallbacks = [list(item) for item in request.get("fallbacks") or []]
            return self.manager.launch_app(
                command,
                fallbacks,
                app_id=str(request.get("app_id", "")),
                label=str(request.get("label", "")),
                icon_name=str(request.get("icon_name", "")),
                class_hints=list(request.get("class_hints") or []),
                wait_window=bool(request.get("wait_window", True)),
                timeout=float(request.get("timeout", 6.0)),
            )

        wid = str(request.get("wid", ""))
        if action == "focus":
            return {"ok": self.manager.focus(wid), "wid": wid}
        if action == "minimize":
            return {"ok": self.manager.minimize(wid), "wid": wid}
        if action == "restore":
            return {"ok": self.manager.restore(wid), "wid": wid}
        if action == "undock":
            return {"ok": self.manager.undock(wid), "wid": wid}
        if action == "redock":
            return {"ok": self.manager.redock(wid), "wid": wid}
        if action == "toggle-undock":
            return {"ok": self.manager.toggle_undock(wid), "wid": wid}
        if action == "close":
            return {"ok": self.manager.close(wid), "wid": wid}
        if action == "move":
            workspace = str(request.get("workspace", "")).strip()
            return {"ok": self.manager.move_to_workspace(wid, workspace), "wid": wid}
        if action == "minimize-all":
            return {"ok": self.manager.minimize_all()}
        if action == "close-all":
            return {"ok": self.manager.close_all()}
        if action == "restore-session":
            return {"ok": self.manager.restore_session() >= 0}
        return {"ok": False, "error": f"unknown_action:{action}"}


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ZyntrixOS window manager daemon")
    parser.add_argument("--restore-session", action="store_true")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = _build_parser().parse_args(argv)
    daemon = WindowManagerDaemon(restore_session=args.restore_session)
    daemon.start()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
