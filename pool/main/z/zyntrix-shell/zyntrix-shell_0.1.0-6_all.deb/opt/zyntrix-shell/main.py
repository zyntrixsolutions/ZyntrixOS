#! /usr/bin/python3
"""
ZyntrixOS Shell — fullscreen GTK3 tile launcher.
Runs standalone on any Linux with PyGObject installed:
    sudo apt install python3-gi gir1.2-gtk-3.0
    python3 shell/main.py
"""

from __future__ import annotations

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")

import logging
from logging.handlers import RotatingFileHandler
import os
import shutil
import signal
import subprocess
import sys
import threading
import datetime
import time
from pathlib import Path
from typing import Optional

# Detect if running under herbstluftwm
_HAS_HLWM = shutil.which("herbstclient") is not None
_HAS_WMCTRL = shutil.which("wmctrl") is not None

# ---------------------------------------------------------------------------
# Hardware performance tier — detected once at startup from /proc/meminfo.
# ultralow : ≤2 GB    — Pentium/Core2-era desktops; no non-essential
#                       daemons, no LoadScreen, no wallpaper scaling,
#                       minimal polling.  Before: 2 GB landed in "low" and
#                       still ran animations/watchers.  After: it degrades to
#                       a static, reliable shell first.
# low      : ≤3 GB    — older laptops; no CSS transitions, 30 fps
# mid      : 4–11 GB  — balanced
# high     : ≥12 GB   — full effects, BILINEAR wallpaper, 60 fps
# ---------------------------------------------------------------------------
def _read_ram_kb() -> int:
    try:
        with open("/proc/meminfo") as _f:
            for _line in _f:
                if _line.startswith("MemTotal"):
                    return int(_line.split()[1])
    except Exception:
        pass
    return 4 * 1024 * 1024

_RAM_KB:   int  = _read_ram_kb()
_PERF_TIER: str = (
    "low"  if _RAM_KB <= 3  * 1024 * 1024 else
    "mid"  if _RAM_KB <= 11 * 1024 * 1024 else
    "high"
)
# _ULTRALOW: fast-path for 2 GB systems where swap pressure freezes GTK.
# Sits inside the "low" bucket so all existing dict lookups still work.
_ULTRALOW: bool = (
    os.environ.get("ZYNTRIX_ULTRALOW", "").lower() in ("1", "true", "yes")
    or _RAM_KB <= 2 * 1024 * 1024
)

# Polling interval for periodic hint refreshes.
_HINT_POLL_S:   int = 30 if _ULTRALOW else {"low": 15, "mid": 4, "high": 2}[_PERF_TIER]

from gi.repository import Gtk, Gdk, GLib, GdkPixbuf, Gio

# Resolve wallpaper interpolation constant now that GdkPixbuf is imported.
_WP_INTERP = (
    GdkPixbuf.InterpType.NEAREST
    if _PERF_TIER == "low"
    else GdkPixbuf.InterpType.BILINEAR
)

from tiles import load_config, Tile
from launcher import Launcher
from fuzzy_launcher import FuzzyLauncher, prewarm as _fuzzy_prewarm
from notifier import NotificationManager, SystemWatcher
from recents import record_launch, sort_tiles
from switcher_v2 import WindowSwitcherV2
from window_manager import STATE_PATH, WindowManager, WindowManagerClient, WindowState, _norm_wid, _slugify
from loadscreen import LoadScreen

log = logging.getLogger("zyntrix-shell")
logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s  %(message)s")
try:
    _perf_handler = RotatingFileHandler(
        "/tmp/zyntrix-perf.log", maxBytes=256 * 1024, backupCount=2
    )
    _perf_handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    )
    logging.getLogger().addHandler(_perf_handler)
except Exception:
    pass

SHELL_DIR = os.path.dirname(os.path.abspath(__file__))
CSS_PATH = os.path.join(SHELL_DIR, "theme.css")
ICON_SIZE = 64


# ─────────────────────────────────────────────────────────────────────────────
def build_css(theme: dict) -> bytes:
    """Inject runtime colour tokens into the CSS before loading."""
    accent = theme["accent"]
    bg = theme["background"]
    surface = theme["surface"]
    text = theme["text"]

    # Derive dim / hover variants
    def darken(hex_color: str, factor: float = 0.6) -> str:
        h = hex_color.lstrip("#")
        r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
        return "#{:02x}{:02x}{:02x}".format(
            min(255, int(r * factor)),
            min(255, int(g * factor)),
            min(255, int(b * factor)),
        )

    def alpha(hex_color: str, a: float = 0.18) -> str:
        h = hex_color.lstrip("#")
        r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
        return f"rgba({r},{g},{b},{a})"

    with open(CSS_PATH, "r") as fh:
        css_template = fh.read()

    replacements = {
        "@bg": bg,
        "@surface-hover": darken(surface, 1.4) if surface.startswith("#") else "#1e2030",
        "@surface": surface,
        "@accent-dim": alpha(accent),
        "@accent": accent,
        "@border": darken(accent, 0.35),
        "@text-dim": darken(text, 0.55),
        "@text": text,
    }
    css = css_template
    for token, value in sorted(replacements.items(), key=lambda kv: -len(kv[0])):
        css = css.replace(token, value)

    # On low-end hardware kill every CSS transition / animation so the GPU
    # raster thread never blocks the GTK main loop between frames.
    if _PERF_TIER == "low":
        css += (
            "\n* { transition-duration: 0s; }\n"
            "* { animation-duration: 0s; }\n"
        )

    return css.encode()


# ─────────────────────────────────────────────────────────────────────────────
class TileButton(Gtk.Button):
    def __init__(self, tile: Tile, on_activate, index: int = 0):
        super().__init__()
        self.tile = tile
        self._index = index
        self._on_activate = on_activate
        self.get_style_context().add_class("tile-button")
        self.set_can_focus(True)
        self.connect("clicked", lambda _: on_activate(tile))
        self.connect("button-press-event", self._on_button_press)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        box.set_halign(Gtk.Align.CENTER)
        box.set_valign(Gtk.Align.CENTER)

        # Icon
        icon = Gtk.Image()
        icon.get_style_context().add_class("tile-icon")
        if tile.icon and (tile.icon.startswith("/") or tile.icon.endswith(".png")):
            try:
                pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(tile.icon, ICON_SIZE, ICON_SIZE, True)
                icon.set_from_pixbuf(pb)
            except Exception:
                icon.set_from_icon_name("applications-other", Gtk.IconSize.DIALOG)
        else:
            icon.set_from_icon_name(tile.icon or "applications-other", Gtk.IconSize.DIALOG)
            icon.set_pixel_size(ICON_SIZE)

        # Labels
        label = Gtk.Label(label=tile.label)
        label.get_style_context().add_class("tile-label")
        label.set_halign(Gtk.Align.CENTER)

        sublabel = Gtk.Label(label=tile.subtitle.upper() if tile.subtitle else "")
        sublabel.get_style_context().add_class("tile-sublabel")
        sublabel.set_halign(Gtk.Align.CENTER)

        box.pack_start(icon, False, False, 0)
        box.pack_start(label, False, False, 0)
        box.pack_start(sublabel, False, False, 0)

        # Badge + spinner overlay
        overlay = Gtk.Overlay()
        overlay.add(box)

        self._badge = Gtk.Label(label="")
        self._badge.get_style_context().add_class("badge")
        self._badge.set_halign(Gtk.Align.END)
        self._badge.set_valign(Gtk.Align.START)
        overlay.add_overlay(self._badge)
        overlay.set_overlay_pass_through(self._badge, True)

        # Keyboard shortcut hint in the top-left corner (1..9)
        if 0 <= index < 9:
            self._num_badge = Gtk.Label(label=str(index + 1))
            self._num_badge.get_style_context().add_class("tile-num-badge")
            self._num_badge.set_halign(Gtk.Align.START)
            self._num_badge.set_valign(Gtk.Align.START)
            overlay.add_overlay(self._num_badge)
            overlay.set_overlay_pass_through(self._num_badge, True)

        self._spinner = Gtk.Spinner()
        self._spinner.get_style_context().add_class("tile-spinner")
        self._spinner.set_halign(Gtk.Align.CENTER)
        self._spinner.set_valign(Gtk.Align.CENTER)
        self._spinner.set_no_show_all(True)
        overlay.add_overlay(self._spinner)

        self.add(overlay)

    def set_status(self, status: str) -> None:
        """Update the badge: 'ok' (green) | 'fallback' (amber) | 'missing' (grey)."""
        ctx = self._badge.get_style_context()
        for cls in ("badge-ok", "badge-fallback", "badge-missing"):
            ctx.remove_class(cls)
        self._badge.set_text("●")
        ctx.add_class(f"badge-{status}")

    def set_loading(self, loading: bool) -> None:
        """Show/hide loading spinner and pulse animation."""
        ctx = self.get_style_context()
        if loading:
            ctx.add_class("tile-loading")
            self._spinner.show()
            self._spinner.start()
        else:
            ctx.remove_class("tile-loading")
            self._spinner.stop()
            self._spinner.hide()

    def _on_button_press(self, _widget, event: Gdk.EventButton) -> bool:
        if event.button != 3:
            return False
        menu = Gtk.Menu()

        item_launch = Gtk.MenuItem(label=f"Launch  {self.tile.label}")
        item_launch.connect("activate", lambda _: self._on_activate(self.tile))
        menu.append(item_launch)

        menu.append(Gtk.SeparatorMenuItem())

        cmd_str = " ".join(self.tile.command[:2])
        item_cmd = Gtk.MenuItem(label=f"Command: {cmd_str}")
        item_cmd.set_sensitive(False)
        menu.append(item_cmd)

        menu.show_all()
        menu.popup_at_pointer(event)
        return True


# ─────────────────────────────────────────────────────────────────────────────
class LockScreen(Gtk.Window):
    """Fullscreen branded lock overlay with password entry.

    Instantiate with a verify callable (str) -> bool and call present().
    The verify function is expected to be PAM-backed and fails-closed.
    """

    _LOGO_PATHS = [
        os.path.join(os.path.dirname(SHELL_DIR), "config", "assets", "zyntrix-logo.png"),
        "/usr/share/zyntrix/zyntrix-logo.png",
        "/opt/zyntrix-shell/config/assets/zyntrix-logo.png",
    ]

    def __init__(self, verify_fn):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self._verify_fn = verify_fn
        self.set_decorated(False)
        self.fullscreen()
        self.set_keep_above(True)
        self.get_style_context().add_class("lock-screen")
        self._build_ui()
        self.connect("key-press-event", self._on_key)
        self.connect("delete-event", lambda *_: True)

    def _build_ui(self) -> None:
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        vbox.set_halign(Gtk.Align.CENTER)
        vbox.set_valign(Gtk.Align.CENTER)

        logo = self._make_logo()
        logo.set_margin_bottom(8)

        self._clock_lbl = Gtk.Label()
        self._clock_lbl.get_style_context().add_class("lock-clock")

        self._date_lbl = Gtk.Label()
        self._date_lbl.get_style_context().add_class("lock-date")

        self._entry = Gtk.Entry()
        self._entry.set_visibility(False)
        self._entry.set_placeholder_text("Password")
        self._entry.set_size_request(280, -1)
        self._entry.set_halign(Gtk.Align.CENTER)
        self._entry.get_style_context().add_class("lock-entry")
        self._entry.set_margin_top(16)

        self._error_lbl = Gtk.Label(label="")
        self._error_lbl.get_style_context().add_class("lock-error")

        hint = Gtk.Label(label="Enter — unlock")
        hint.get_style_context().add_class("status-hint")
        hint.set_margin_top(4)

        for w in (logo, self._clock_lbl, self._date_lbl,
                  self._entry, self._error_lbl, hint):
            vbox.pack_start(w, False, False, 0)
        self.add(vbox)

        self._tick_clock()
        GLib.timeout_add_seconds(1, self._tick_clock)

    def _make_logo(self) -> Gtk.Widget:
        for lp in self._LOGO_PATHS:
            if os.path.exists(lp):
                try:
                    pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(lp, 180, 216, True)
                    return Gtk.Image.new_from_pixbuf(pb)
                except Exception:
                    break
        return Gtk.Image.new_from_icon_name("system-lock-screen", Gtk.IconSize.DIALOG)

    def _tick_clock(self) -> bool:
        _now = datetime.datetime.now()
        self._clock_lbl.set_text(_now.strftime("%H:%M"))
        self._date_lbl.set_text(_now.strftime("%A, %d %B %Y"))
        return self.get_visible()

    def _shake(self) -> None:
        ctx = self._entry.get_style_context()
        ctx.add_class("lock-shake")
        GLib.timeout_add(400, lambda: (ctx.remove_class("lock-shake"), False))

    def _on_key(self, _w, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_Escape:
            self._entry.set_text("")
            self._error_lbl.set_text("")
            return True
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            pw = self._entry.get_text()
            if self._verify_fn(pw):
                self.destroy()
            else:
                self._entry.set_text("")
                self._error_lbl.set_text("Incorrect password")
                self._shake()
            return True
        return False

    def present(self) -> None:  # type: ignore[override]
        self.show_all()
        GLib.idle_add(self._entry.grab_focus)


# ─────────────────────────────────────────────────────────────────────────────
class ZyntrixShell(Gtk.Window):
    COLS = 4  # default; overridden by theme["columns"]

    def __init__(self):
        super().__init__(title="ZyntrixOS")
        self.set_name("zyntrix-shell")
        self.get_style_context().add_class("zyntrix-shell")

        tiles, theme = load_config()
        self._tiles = tiles
        self._theme = theme
        self._buttons: list[TileButton] = []
        self._focus_idx = 0
        self.COLS = int(theme.get("columns", 4))

        self._launcher = Launcher(
            on_child_exit=self._on_child_exit,
            on_launch_error=self._on_launch_error,
            on_launched=self._on_launched,
        )
        self._wm = WindowManagerClient()
        self._wm.ensure_daemon()
        self._wm_snapshot: dict = self._wm.snapshot()
        self._window_monitor = None
        self._window_refresh_source: int = 0
        self._loading_btn: TileButton = None
        self._load_screen: LoadScreen = None

        # Input guards — prevent spam on slow hardware.
        # _switcher_active: True while a switcher window exists.
        # _last_tab_ms: monotonic timestamp of last Tab press (300 ms debounce).
        self._switcher_active: bool = False
        self._last_tab_ms: float = 0.0
        # Thread-pileup guards: prevent concurrent background pollers.
        self._hint_bar_busy:  bool = False
        self._focus_newest_busy: bool = False
        self._last_windows: list[dict] = []
        self._last_windows_t: float = 0.0
        self._recent_buttons: dict[str, Gtk.Button] = {}
        self._recent_order: list[str] = []
        self._recent_empty_label: Optional[Gtk.Label] = None
        # Cached hex WID (e.g. "0x01400003") set once in _on_realize so that
        # _hide_launcher/_show_launcher never need to run a blocking wmctrl
        # subprocess on the GTK main thread.
        self._cached_wid: str = ""

        # Sort tiles by recent usage before building UI
        tiles = sort_tiles(tiles)
        self._tiles = tiles

        # Notification system — always present for in-process toasts.
        # SystemWatcher polls disk/battery/updates; skip on ultralow to save
        # the two background threads (one poller + one notifier dispatcher).
        self._notifier = NotificationManager()
        try:
            self._watcher = SystemWatcher(self._notifier) if not _ULTRALOW else None
        except Exception as exc:
            # Defensive startup: notifications are nice-to-have, but a watcher
            # init failure must not prevent the basic shell from loading.
            log.exception("SystemWatcher init failed; continuing without it: %s", exc)
            self._watcher = None

        self._apply_css(theme)
        self._build_ui(tiles)
        self._apply_window_snapshot()
        # Wallpaper scaling is deferred until after first paint.  On a 2 GB
        # machine it can transiently allocate 50–150 MB; keeping it out of the
        # constructor makes GUI startup reliable even if scaling later fails.
        self._setup_keys()

        # Disable GTK animations on low-end: CSS transitions cost GPU rasters
        # that a 2006-era Intel GMA simply cannot sustain without jank.
        if _PERF_TIER == "low":
            try:
                Gtk.Settings.get_default().set_property(
                    "gtk-enable-animations", False
                )
            except Exception:
                pass

        self.set_decorated(False)
        self.fullscreen()
        # Connect realize BEFORE show_all(): GTK fires "realize" synchronously
        # during show_all(), so connecting afterwards would silently drop the
        # callback and WM_CLASS would never be set — which breaks _get_wid()
        # and makes _hide_launcher() fall back to a no-op iconify() under hlwm.
        self.connect("realize", self._on_realize)
        self.show_all()
        # Belt-and-braces: window is realized by now, set WM_CLASS directly in
        # case the signal was missed (e.g. reparented before connect).
        self._on_realize(self)
        log.info(
            "startup tier=%s ultralow=%s ram_mb=%d hint_poll=%ss",
            _PERF_TIER, _ULTRALOW, _RAM_KB // 1024, _HINT_POLL_S,
        )

        # Ask WM to keep us on top
        self._set_wm_above(True)

        # Clock refresh
        GLib.timeout_add_seconds(1, self._update_clock)

        # Write PID file so zyntrix-toggle-launcher can signal us
        try:
            Path("/tmp/zyntrix-shell.pid").write_text(str(os.getpid()))
        except Exception:
            pass

        # SIGUSR1 → toggle show/hide (sent by zyntrix-toggle-launcher)
        GLib.unix_signal_add(
            GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self._on_toggle_signal
        )

        # Badge scan and initial hint/workspace fetch are deferred 1 s so the
        # GTK main loop is free to paint the shell window first.
        GLib.timeout_add(1000, self._deferred_startup)

        # SIGUSR2 → open switcher in-process (zero latency — no new Python
        # interpreter spawn).  Alt+Tab in autostart sends this signal first;
        # it falls back to the standalone switcher.py only if PID is stale.
        GLib.unix_signal_add(
            GLib.PRIORITY_DEFAULT, signal.SIGUSR2, self._on_switcher_signal
        )
        self._setup_window_state_monitor()
        GLib.timeout_add(160 if _ULTRALOW else 80, self._queue_window_snapshot_refresh)

    # ------------------------------------------------------------------
    def _apply_css(self, theme: dict) -> None:
        css_data = build_css(theme)
        provider = Gtk.CssProvider()
        provider.load_from_data(css_data)
        screen = Gdk.Screen.get_default()
        Gtk.StyleContext.add_provider_for_screen(
            screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    # ------------------------------------------------------------------
    def _build_ui(self, tiles: list[Tile]) -> None:
        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        # ── Header ──
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        header.get_style_context().add_class("shell-header")

        title_label = Gtk.Label(label="ZYNTRIX OS")
        title_label.get_style_context().add_class("shell-title")
        title_label.set_halign(Gtk.Align.START)

        self._clock_label = Gtk.Label(label=self._clock_str())
        self._clock_label.get_style_context().add_class("shell-clock")
        self._clock_label.set_halign(Gtk.Align.END)

        header.pack_start(title_label, True, True, 0)
        header.pack_end(self._clock_label, False, False, 0)

        # ── Recent windows ──
        recent = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        recent.get_style_context().add_class("recent-windows")
        recent.set_margin_start(48)
        recent.set_margin_end(48)
        recent.set_margin_top(16)
        recent.set_margin_bottom(8)

        recent_head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self._recent_label = Gtk.Label(label="RECENT WINDOWS")
        self._recent_label.get_style_context().add_class("switcher-title")
        self._recent_label.set_halign(Gtk.Align.START)

        self._recent_summary = Gtk.Label(label="No apps open")
        self._recent_summary.get_style_context().add_class("switcher-count")
        self._recent_summary.set_halign(Gtk.Align.END)
        self._recent_summary.set_hexpand(True)

        recent_head.pack_start(self._recent_label, False, False, 0)
        recent_head.pack_start(self._recent_summary, True, True, 0)
        recent.pack_start(recent_head, False, False, 0)

        self._recent_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self._recent_box.get_style_context().add_class("recent-window-box")
        recent.pack_start(self._recent_box, False, False, 0)

        # ── Tile grid ──
        grid = Gtk.Grid()
        grid.get_style_context().add_class("tile-grid")
        grid.set_halign(Gtk.Align.CENTER)
        grid.set_valign(Gtk.Align.CENTER)
        grid.set_hexpand(True)
        grid.set_vexpand(True)
        grid.set_column_spacing(24)
        grid.set_row_spacing(24)

        self._buttons = []
        for idx, tile in enumerate(tiles):
            btn = TileButton(tile, self._on_tile_activate, index=idx)
            row, col = divmod(idx, self.COLS)
            grid.attach(btn, col, row, 1, 1)
            self._buttons.append(btn)

        # ── Status bar ──
        statusbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        statusbar.get_style_context().add_class("shell-statusbar")

        # Workspace indicator (hlwm tag display)
        self._workspace_label = Gtk.Label(label="")
        self._workspace_label.get_style_context().add_class("status-hint")
        self._workspace_label.set_halign(Gtk.Align.START)
        statusbar.add(self._workspace_label)
        # Always-on contextual help bar. Kept visible so the user never has
        # to remember a hotkey — updated dynamically (see _update_hint_bar)
        # based on what's focused / whether any apps are open.
        self._hint_label = Gtk.Label()
        self._hint_label.get_style_context().add_class("status-hint")
        self._hint_label.set_halign(Gtk.Align.CENTER)
        self._hint_label.set_hexpand(True)
        self._hint_label.set_use_markup(True)
        statusbar.add(self._hint_label)
        # Refresh hint every _HINT_POLL_S seconds (tier-adaptive).
        if not _ULTRALOW:
            GLib.timeout_add_seconds(_HINT_POLL_S, self._update_hint_bar_tick)

        sep = Gtk.Separator()
        sep.get_style_context().add_class("header-sep")

        root.pack_start(header, False, False, 0)
        root.pack_start(sep, False, False, 0)
        root.pack_start(recent, False, False, 0)
        root.pack_start(grid, True, True, 0)
        root.pack_start(statusbar, False, False, 0)
        self.add(root)

        if self._buttons:
            self._buttons[0].grab_focus()

    # ------------------------------------------------------------------
    def _setup_keys(self) -> None:
        self.connect("key-press-event", self._on_key_press)

    def _setup_window_state_monitor(self) -> None:
        path = Path(STATE_PATH)
        target = Gio.File.new_for_path(str(path if path.exists() else path.parent))
        try:
            if path.exists():
                self._window_monitor = target.monitor_file(Gio.FileMonitorFlags.NONE, None)
            else:
                self._window_monitor = target.monitor_directory(Gio.FileMonitorFlags.NONE, None)
            self._window_monitor.connect("changed", self._queue_window_snapshot_refresh)
        except Exception:
            self._window_monitor = None

    def _queue_window_snapshot_refresh(self, *_args) -> bool:
        if self._window_refresh_source:
            return False
        delay = 220 if _ULTRALOW else 90
        self._window_refresh_source = GLib.timeout_add(delay, self._refresh_window_snapshot)
        return False

    def _load_window_snapshot(self) -> dict:
        snapshot = WindowManager.load_snapshot(STATE_PATH)
        if snapshot:
            return snapshot
        return self._wm.snapshot()

    def _window_states(self) -> list[WindowState]:
        snapshot = self._wm_snapshot or {}
        states: list[WindowState] = []
        for item in snapshot.get("windows") or []:
            if isinstance(item, dict):
                try:
                    states.append(WindowState.from_dict(item))
                except Exception:
                    continue
        return states

    def _visible_app_windows(self) -> list[WindowState]:
        return [state for state in self._window_states() if state.state != "minimized"]

    def _last_app_window(self) -> Optional[WindowState]:
        target = _norm_wid(str((self._wm_snapshot or {}).get("last_active_wid", "")))
        windows = self._window_states()
        for state in windows:
            if state.wid == target:
                return state
        return windows[0] if windows else None

    def _refresh_window_snapshot(self) -> bool:
        self._window_refresh_source = 0
        snapshot = self._load_window_snapshot()
        if not snapshot:
            return False
        if snapshot.get("generated_at") == (self._wm_snapshot or {}).get("generated_at"):
            return False
        self._wm_snapshot = snapshot
        self._apply_window_snapshot()
        return False

    def _apply_window_snapshot(self) -> None:
        windows = self._window_states()
        minimized = sum(1 for state in windows if state.state == "minimized")
        visible = sum(1 for state in windows if state.state != "minimized")
        if hasattr(self, "_recent_summary"):
            summary = f"{visible} open  |  {minimized} minimized" if windows else "No apps open"
            if self._recent_summary.get_text() != summary:
                self._recent_summary.set_text(summary)
        if hasattr(self, "_recent_box"):
            self._update_recent_windows(windows[:3])
        if hasattr(self, "_workspace_label"):
            text = str((self._wm_snapshot or {}).get("workspace_text", ""))
            if self._workspace_label.get_text() != text:
                self._workspace_label.set_text(text)
        self._apply_hint_bar(bool(windows))

    def _recent_button_label(self, state: WindowState) -> str:
        return f"{state.label or state.title or state.app_id}{' [min]' if state.state == 'minimized' else ''}"

    def _recent_button(self, state: WindowState) -> Gtk.Button:
        btn = Gtk.Button(label="")
        btn.get_style_context().add_class("recent-window-btn")
        btn.connect("clicked", self._on_recent_window_clicked)
        self._update_recent_button(btn, state)
        return btn

    def _update_recent_button(self, btn: Gtk.Button, state: WindowState) -> None:
        label = self._recent_button_label(state)
        if btn.get_label() != label:
            btn.set_label(label)
        btn._wid = state.wid  # type: ignore[attr-defined]

    def _clear_recent_box(self) -> None:
        for child in self._recent_box.get_children():
            self._recent_box.remove(child)

    def _update_recent_windows(self, windows: list[WindowState]) -> None:
        order = [state.wid for state in windows]
        order_set = set(order)
        stale = [wid for wid in self._recent_buttons if wid not in order_set]
        for wid in stale:
            btn = self._recent_buttons.pop(wid, None)
            if btn is None:
                continue
            parent = btn.get_parent()
            if parent is self._recent_box:
                self._recent_box.remove(btn)
            btn.destroy()

        if not windows:
            if self._recent_order or self._recent_empty_label is None:
                self._clear_recent_box()
                if self._recent_empty_label is None:
                    empty = Gtk.Label(label="Launch something and it will show up here.")
                    empty.get_style_context().add_class("switcher-empty")
                    empty.set_halign(Gtk.Align.START)
                    self._recent_empty_label = empty
                self._recent_box.pack_start(self._recent_empty_label, False, False, 0)
                self._recent_box.show_all()
            self._recent_order = []
            return

        self._recent_empty_label = None
        if order != self._recent_order:
            self._clear_recent_box()
            for state in windows:
                btn = self._recent_buttons.get(state.wid)
                if btn is None:
                    btn = self._recent_button(state)
                    self._recent_buttons[state.wid] = btn
                self._update_recent_button(btn, state)
                self._recent_box.pack_start(btn, False, False, 0)
            self._recent_box.show_all()
            self._recent_order = order
            return

        for state in windows:
            btn = self._recent_buttons.get(state.wid)
            if btn is not None:
                self._update_recent_button(btn, state)

    def _on_recent_window_clicked(self, btn: Gtk.Button) -> None:
        wid = getattr(btn, "_wid", "")
        if wid:
            self._focus_window_from_shell(wid)

    def _focus_window_from_shell(self, wid: str) -> None:
        if self._wm.focus(wid):
            self._hide_launcher()

    def _on_key_press(self, _widget, event: Gdk.EventKey) -> bool:
        key = event.keyval
        mods = event.state

        n = len(self._buttons)
        if n == 0:
            return False

        if key == Gdk.KEY_Escape:
            # Esc: if a load screen is up, cancel launch; otherwise switch
            # to the most recently active app window (tab away from shell).
            if self._load_screen is not None:
                self._load_screen.dismiss()
                self._load_screen = None
                if self._loading_btn is not None:
                    self._loading_btn.set_loading(False)
                    self._loading_btn = None
                return True
            last_app = self._last_app_window()
            if last_app is not None:
                self._wm.focus(last_app.wid)
                self._hide_launcher()
            elif _HAS_HLWM or _HAS_WMCTRL:
                self._hide_launcher()
            else:
                Gtk.main_quit()
            return True

        if key == Gdk.KEY_l and (mods & Gdk.ModifierType.SUPER_MASK):
            self._lock_screen()
            return True

        if key == Gdk.KEY_space and (mods & Gdk.ModifierType.SUPER_MASK):
            self._hide_launcher()
            return True

        if key == Gdk.KEY_Return or key == Gdk.KEY_KP_Enter:
            if self._loading_btn is None:
                self._on_tile_activate(self._tiles[self._focus_idx])
            return True

        if key == Gdk.KEY_slash:
            self._open_fuzzy()
            return True

        # Tab → window switcher with 200 ms debounce so rapid presses on
        # slow hardware don't queue up and spawn a stack of overlays.
        if key in (Gdk.KEY_Tab, Gdk.KEY_ISO_Left_Tab):
            now = time.monotonic()
            if now - self._last_tab_ms >= 0.30:
                self._last_tab_ms = now
                self._open_switcher()
            return True  # always consume Tab even if debounced

        if key == Gdk.KEY_question:
            self._show_shortcuts()
            return True

        if key == Gdk.KEY_n and (mods & Gdk.ModifierType.CONTROL_MASK):
            self._notifier.notify("Test", "Notification system active", "info")
            return True

        if key == Gdk.KEY_grave and (mods & Gdk.ModifierType.SUPER_MASK):
            self._spawn_stats()
            return True

        # Number shortcuts 1..9 → launch tile directly. Avoids arrow-key
        # hunt-and-peck; matches console-dashboard UX (Xbox/PS grid).
        if Gdk.KEY_1 <= key <= Gdk.KEY_9 and not mods & (
            Gdk.ModifierType.CONTROL_MASK | Gdk.ModifierType.MOD1_MASK
        ):
            idx = key - Gdk.KEY_1
            if idx < n and self._loading_btn is None:
                self._focus_idx = idx
                self._buttons[idx].grab_focus()
                self._on_tile_activate(self._tiles[idx])
                return True

        move = 0
        if key in (Gdk.KEY_Right, Gdk.KEY_l):
            move = 1
        elif key in (Gdk.KEY_Left, Gdk.KEY_h):
            move = -1
        elif key in (Gdk.KEY_Down, Gdk.KEY_j):
            move = self.COLS
        elif key in (Gdk.KEY_Up, Gdk.KEY_k):
            move = -self.COLS

        if move != 0:
            new_idx = (self._focus_idx + move) % n
            self._focus_idx = new_idx
            self._buttons[new_idx].grab_focus()
            return True

        return False

    # ------------------------------------------------------------------
    def _apply_wallpaper(self, theme: dict) -> None:
        """Set window background: solid colour, or image from theme[wallpaper].

        Image scaling runs off the GTK main thread and caches the scaled PNG
        keyed on (path, mtime, screen-size) so subsequent launches reuse it.
        """
        wp = theme.get("wallpaper", "").strip()
        if not wp:
            return
        if os.path.isfile(wp):
            threading.Thread(
                target=self._prepare_wallpaper_bg,
                args=(wp,),
                daemon=True,
                name="wallpaper-prep",
            ).start()
        elif wp.startswith("#") or wp.startswith("rgb"):
            screen = Gdk.Screen.get_default()
            extra_css = f'window.zyntrix-shell {{ background-color: {wp}; }}'.encode()
            provider = Gtk.CssProvider()
            provider.load_from_data(extra_css)
            Gtk.StyleContext.add_provider_for_screen(
                screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1
            )

    # ------------------------------------------------------------------
    def _prepare_wallpaper_bg(self, wp: str) -> None:
        """Background thread: scale wallpaper and push CSS on GTK main thread.
        Cache key includes mtime + screen size so subsequent launches reuse
        the scaled PNG instead of re-decoding and re-encoding every time.
        """
        try:
            screen = Gdk.Screen.get_default()
            sw = screen.get_width() if screen else 1920
            sh = screen.get_height() if screen else 1080
            mtime = int(os.path.getmtime(wp))
            cache_dir = os.path.join(
                os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")),
                "zyntrix",
            )
            os.makedirs(cache_dir, exist_ok=True)
            key = f"wp-{abs(hash(wp))}-{mtime}-{sw}x{sh}.png"
            cached = os.path.join(cache_dir, key)
            if not os.path.isfile(cached):
                pb = GdkPixbuf.Pixbuf.new_from_file(wp)
                pb = pb.scale_simple(sw, sh, _WP_INTERP)
                pb.savev(cached, "png", [], [])
        except Exception as exc:
            log.warning("Wallpaper prep failed: %s", exc)
            return
        GLib.idle_add(self._install_wallpaper_css, cached)

    def _install_wallpaper_css(self, path: str) -> bool:
        try:
            screen = Gdk.Screen.get_default()
            extra_css = (
                f'window.zyntrix-shell {{ background-image: url("{path}"); '
                f'background-size: cover; }}'
            ).encode()
            provider = Gtk.CssProvider()
            provider.load_from_data(extra_css)
            Gtk.StyleContext.add_provider_for_screen(
                screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1
            )
        except Exception as exc:
            log.warning("Wallpaper CSS install failed: %s", exc)
        return False

    # ------------------------------------------------------------------
    def _on_tile_activate(self, tile: Tile) -> None:
        if self._loading_btn is not None or self._load_screen is not None:
            return  # launch already in progress — ignore re-trigger
        log.info("Activating tile: %s  cmd=%s", tile.id, tile.command)
        record_launch(tile.id)
        for btn in self._buttons:
            if btn.tile.id == tile.id:
                btn.set_loading(True)
                self._loading_btn = btn
                break

        # Loading overlay — skip entirely on ultralow (saves ~20 MB of Cairo
        # surface memory and one 30 fps timer firing on a single CPU core).
        if not _ULTRALOW:
            icon_path = tile.icon if (tile.icon and os.path.isfile(tile.icon)) else ""
            fps = {"low": 30, "mid": 45, "high": 60}[_PERF_TIER]
            self._load_screen = LoadScreen(tile.label, icon_path, self._theme, fps=fps)
            self._load_screen.show()

        threading.Thread(
            target=self._launch_tile_via_wm,
            args=(tile,),
            daemon=True,
            name=f"launch-{tile.id}",
        ).start()

    def _launch_tile_via_wm(self, tile: Tile) -> None:
        result = self._wm.launch_app(
            tile.command,
            tile.fallbacks,
            app_id=tile.id,
            label=tile.label,
            icon_name=tile.icon,
            class_hints=[tile.label, tile.subtitle, tile.id],
            wait_window=not _ULTRALOW,
            timeout=8.0 if tile.id == "browser" else 6.0,
        )
        GLib.idle_add(self._on_wm_launch_result, tile, result)

    def _on_wm_launch_result(self, tile: Tile, result: dict) -> bool:
        if self._load_screen is not None:
            self._load_screen.dismiss()
            self._load_screen = None
        if self._loading_btn is not None:
            self._loading_btn.set_loading(False)
            self._loading_btn = None

        if result.get("ok"):
            self._refresh_window_snapshot()
            self._hide_launcher()
            return False

        tried = result.get("tried") or []
        self._notifier.notify(
            f"Cannot launch: {tile.label}",
            f"Tried {len(tried)} command path(s)",
            "error",
        )
        return False

    def _on_launched(self) -> None:
        """Called on GTK main thread when a healthy process has started."""
        # Dismiss loading screen with completion animation
        if self._load_screen is not None:
            self._load_screen.dismiss()
            self._load_screen = None
        # Keep spinner running until the app exits; just hide the shell.
        self._hide_launcher()
        # hlwm has focus_stealing_prevention=1 — the newly-mapped window
        # won't auto-focus. Give Xorg a beat to map it, then focus the
        # most-recently-created client in one background operation.  Before:
        # the GTK thread ran wmctrl at 180 ms and sometimes retried at 350 ms.
        # After: one delayed worker does the scan/focus off the main loop.
        GLib.timeout_add(420 if _ULTRALOW else 260, self._schedule_focus_newest_window)

    def _schedule_focus_newest_window(self) -> bool:
        if self._focus_newest_busy:
            return False
        self._focus_newest_busy = True
        threading.Thread(
            target=self._focus_newest_window_bg,
            daemon=True,
            name="focus-newest",
        ).start()
        return False  # one-shot

    def _focus_newest_window_bg(self) -> None:
        """Background scan/focus for the newest non-shell window."""
        wid = ""
        try:
            last = self._last_app_window()
            wid = last.wid if last else ""
        except Exception as exc:
            log.debug("focus newest scan failed: %s", exc)
        try:
            if wid:
                self._wm.focus(wid)
        finally:
            self._focus_newest_busy = False

    def _hide_launcher(self) -> None:
        """Hide the launcher so the launched app is actually visible.

        Simply drop keep-above and unmap the GTK window.  The previous
        approach sent three racing non-blocking wmctrl state-change calls
        that the WM processed out-of-order, leaving the shell covering the
        child.  A plain self.hide() is atomic from the WM's perspective.
        """
        self._set_wm_above(False)
        self.hide()

    def _show_launcher(self) -> None:
        """Bring the launcher back to the front with a brief fade-in.

        GTK show/present/fullscreen are synchronous — the WM processes them
        in order before any deferred callbacks run.  A single deferred
        wmctrl -ia call is issued 80 ms later to confirm X focus once the
        WM has finished mapping the window.
        """
        if _PERF_TIER != "low":
            self.set_opacity(0.0)
        self.show()
        self.deiconify()
        self.present()
        self.fullscreen()
        self._set_wm_above(True)
        if _HAS_WMCTRL and not _ULTRALOW:
            GLib.timeout_add(80, self._focus_shell_deferred)
        if _PERF_TIER != "low":
            GLib.timeout_add(16, self._fade_in_step)

    def _focus_shell_deferred(self) -> bool:
        """Deferred: confirm X focus on the shell window via wmctrl."""
        threading.Thread(
            target=self._focus_shell_bg,
            args=(self._cached_wid,),
            daemon=True,
            name="focus-shell",
        ).start()
        return False  # one-shot

    def _focus_shell_bg(self, wid: str) -> None:
        try:
            if not wid:
                wid = self._get_wid()
            if not wid:
                return
            subprocess.run(
                ["wmctrl", "-ia", wid],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.6,
                check=False,
            )
        except Exception:
            pass

    def _fade_in_step(self) -> bool:
        """Advance opacity by 10 % per frame (~160 ms total at 60 fps)."""
        op = self.get_opacity()
        if op >= 1.0:
            self.set_opacity(1.0)
            return False
        self.set_opacity(min(1.0, op + 0.1))
        return True

    def _on_realize(self, _widget) -> None:
        """Called after GTK creates the X window.

        Sets WM_CLASS for hlwm rules and caches the hex WID so subsequent
        hide/show calls never need to run a blocking wmctrl subprocess.
        """
        try:
            gdkwin = self.get_window()
            if gdkwin:
                xid = gdkwin.get_xid()
                # Cache as lowercase hex with 0x prefix — matches wmctrl output
                self._cached_wid = f"0x{xid:08x}"
                threading.Thread(
                    target=self._set_wm_class_bg,
                    args=(xid,),
                    daemon=True,
                    name="wm-class",
                ).start()
        except Exception:
            pass

    @staticmethod
    def _set_wm_class_bg(xid: int) -> None:
        try:
            subprocess.run(
                ["xprop", "-id", str(xid), "-set", "WM_CLASS", "zyntrix-shell\0ZyntrixOS"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=0.6,
                check=False,
            )
        except Exception:
            pass

    def _set_wm_above(self, above: bool) -> None:
        """Set/clear _NET_WM_STATE_ABOVE via GTK GDK."""
        try:
            win = self.get_window()
            if win:
                win.set_keep_above(above)
        except Exception:
            pass

    def _get_wid(self) -> str:
        """Return the hex window ID of this window.

        Returns the cached value set during realize when possible.  Falls
        back to a wmctrl scan only when the cache is empty (e.g. on a WM
        that reparents us after realize).
        """
        if self._cached_wid:
            return self._cached_wid
        try:
            out = subprocess.check_output(
                ["wmctrl", "-lx"], stderr=subprocess.DEVNULL, text=True, timeout=2
            )
            for line in out.splitlines():
                if "zyntrixos" in line.lower() or "zyntrix-shell" in line.lower():
                    wid = line.split()[0]
                    self._cached_wid = wid
                    return wid
        except Exception:
            pass
        return ""

    # ------------------------------------------------------------------
    _HINT_BASE = (
        '<b>1–9</b> Launch   '
        '<b>←→↑↓</b> Navigate   '
        '<b>Enter</b> Open   '
        '<b>Tab</b> Switch Window   '
        '<b>/</b> Fuzzy   '
    )
    _HINT_WINDOWS = (
        '<b>Esc</b> Go to App   '
        '<b>Super+Q</b> Close App   '
    )
    _HINT_TAIL = (
        '<b>?</b> Help   '
        '<b>Super+L</b> Lock   '
        '<b>Super+`</b> Stats'
    )

    def _deferred_startup(self) -> bool:
        """Run heavyweight startup tasks after the first paint."""
        if not _ULTRALOW:
            self._apply_wallpaper(self._theme)
            try:
                # Pre-warm app cache only off the critical startup path.  On
                # ultralow we load it on demand to avoid duplicating catalogue
                # data before the user asks for the fuzzy launcher/switcher.
                _fuzzy_prewarm()
            except Exception as exc:
                log.warning("fuzzy prewarm failed: %s", exc)
            if self._watcher is not None:
                try:
                    self._watcher.start()
                except Exception as exc:
                    log.warning("SystemWatcher start failed: %s", exc)
        if not _ULTRALOW:
            threading.Thread(target=self._scan_tile_statuses, daemon=True, name="tile-status").start()
        if _ULTRALOW:
            self._apply_hint_bar(False)
        else:
            self._update_hint_bar()
        return False

    def _update_hint_bar(self) -> bool:
        self._apply_hint_bar(bool(self._window_states()))
        return False

    def _fetch_hint_bar_data(self) -> None:
        GLib.idle_add(self._apply_hint_bar, bool(self._window_states()))

    def _apply_hint_bar(self, show_windows: bool) -> bool:
        # Reset the busy flag on the GTK main thread so the next timer tick
        # never fires a second thread before this result has been applied.
        self._hint_bar_busy = False
        middle = self._HINT_WINDOWS if show_windows else ""
        markup = f"{self._HINT_BASE}{middle}{self._HINT_TAIL}"
        try:
            self._hint_label.set_markup(markup)
        except Exception:
            pass
        return False

    def _update_hint_bar_tick(self) -> bool:
        if self.get_visible():
            self._update_hint_bar()
        return True  # keep firing

    # ------------------------------------------------------------------
    def _on_toggle_signal(self) -> bool:
        """Called from GLib main loop when SIGUSR1 is received (Super key toggle)."""
        if self.get_visible():
            last_app = self._last_app_window()
            if last_app is not None:
                self._wm.focus(last_app.wid)
            self._hide_launcher()
        else:
            self._show_launcher()
        return GLib.SOURCE_CONTINUE  # keep handler registered

    # ------------------------------------------------------------------
    def _on_switcher_signal(self) -> bool:
        """SIGUSR2 handler — opens switcher without spawning a new process."""
        GLib.idle_add(self._open_switcher)
        return GLib.SOURCE_CONTINUE

    def _open_fuzzy(self) -> None:
        def _do_launch(cmd: list) -> None:
            threading.Thread(
                target=self._launch_fuzzy_command,
                args=(list(cmd),),
                daemon=True,
                name="fuzzy-launch",
            ).start()

        fl = FuzzyLauncher(on_launch=_do_launch, transient_for=self)
        fl.show_all()
        fl.present()

    def _launch_fuzzy_command(self, cmd: list[str]) -> None:
        result = self._wm.launch_app(
            cmd,
            app_id=_slugify(" ".join(cmd[:2])),
            label=Path(cmd[0]).stem if cmd else "App",
            wait_window=not _ULTRALOW,
        )
        GLib.idle_add(self._on_fuzzy_launch_result, result)

    def _on_fuzzy_launch_result(self, result: dict) -> bool:
        if result.get("ok"):
            self._refresh_window_snapshot()
            self._hide_launcher()
        else:
            self._notifier.notify("Launch failed", "The selected app could not be started", "error")
        return False

    def _open_switcher(self) -> None:
        """Alt/Super+Tab overlay — guarded so only one instance can exist.
        Rapid Tab presses on slow hardware won't stack up multiple overlays."""
        if self._switcher_active:
            return
        self._switcher_active = True

        def _on_close():
            self._switcher_active = False

        # Don't set the shell as transient parent when it is hidden — some WMs
        # refuse to map or focus a transient whose parent is unmapped.
        sw = WindowSwitcherV2(
            on_close=_on_close,
            transient_for=self if self.get_visible() else None,
        )
        sw.show_all()
        sw.present()
        GLib.idle_add(sw.grab_focus)

    def _spawn_stats(self) -> None:
        stats = os.path.join(SHELL_DIR, "stats_popup.py")
        if os.path.isfile(stats):
            subprocess.Popen(
                [sys.executable, stats],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

    def _show_shortcuts(self) -> None:
        shortcuts = [
            ("1 … 9",               "Launch tile by number"),
            ("↑ ↓ ← →",            "Navigate tiles"),
            ("h j k l",             "Navigate (Vim)"),
            ("Enter",               "Launch focused tile"),
            ("/",                   "Search and launch installed apps"),
            ("Super",               "Toggle home screen (anywhere in OS)"),
            ("Tab / Alt+Tab",       "Enhanced switcher with window controls"),
            ("Esc",                 "Switch to the last active app"),
            ("Super+-",             "Minimize focused window"),
            ("Super+U",             "Undock focused window"),
            ("Super+R",             "Redock focused window"),
            ("Super+Q",             "Close focused window"),
            ("Super+A",             "All windows overview"),
            ("Super+D",             "Show desktop (minimize all)"),
            ("Super+F / Super+M",   "Toggle fullscreen (legacy)"),
            ("Super+Ctrl+hjkl/←→↑↓","Resize frame (5 % increments)"),
            ("Super+Shift+hjkl",    "Move window to adjacent frame"),
            ("Super+1 … 6",         "Jump to workspace"),
            ("Super+Shift+1–6",     "Move window to workspace"),
            ("?",                   "Show this help"),
            ("Super+`",             "Live system stats"),
            ("Super+L",             "Lock screen"),
            ("Super+Space",         "Hide / show launcher (alt)"),
            ("Ctrl+N",              "Test notification"),
            ("Right-click",         "Tile context menu"),
        ]
        dialog = Gtk.Dialog(
            title="Keyboard Shortcuts",
            transient_for=self,
            modal=True,
        )
        dialog.set_default_size(380, 300)
        area = dialog.get_content_area()
        area.set_margin_start(28)
        area.set_margin_end(28)
        area.set_margin_top(20)
        area.set_margin_bottom(8)

        grid = Gtk.Grid()
        grid.set_column_spacing(28)
        grid.set_row_spacing(10)
        for i, (key, desc) in enumerate(shortcuts):
            k = Gtk.Label(label=key)
            k.set_halign(Gtk.Align.END)
            k.get_style_context().add_class("shortcut-key")
            d = Gtk.Label(label=desc)
            d.set_halign(Gtk.Align.START)
            d.get_style_context().add_class("shortcut-desc")
            grid.attach(k, 0, i, 1, 1)
            grid.attach(d, 1, i, 1, 1)

        area.add(grid)
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    # ------------------------------------------------------------------
    def _lock_screen(self) -> None:
        """Delegate to the standalone LockScreen window class."""
        if os.path.exists("/tmp/zyntrix-installing"):
            self._notifier.notify(
                "Installer Active",
                "Lock screen is paused during installation",
                "warning",
            )
            return
        LockScreen(self._verify_password).present()

    @staticmethod
    def _verify_password(pw: str) -> bool:
        """Verify password via PAM. FAILS CLOSED if PAM is unavailable —
        the previous su-pipe approach silently returned True, making the
        lock cosmetic. python3-pam is now listed in scripts/install.list.
        """
        if not pw:
            return False
        user = os.environ.get("USER") or os.environ.get("LOGNAME") or "root"
        try:
            import pam  # python3-pam
        except Exception:
            log.warning("python3-pam not available — lock screen disabled")
            return False
        try:
            p = pam.pam()
            return bool(p.authenticate(user, pw, service="login"))
        except Exception as exc:
            log.warning("PAM auth error: %s", exc)
            return False

    # ------------------------------------------------------------------
    @staticmethod
    def _cmd_resolves(cmd: list) -> bool:
        """Return True if the command can be successfully launched.

        Mirrors the logic in Launcher._resolve so that badge state matches
        actual launch behaviour.  For interpreter-based tiles such as
        ``[sys.executable, "store.py"]`` we check both that the interpreter
        file exists *and* that the script argument exists, avoiding false
        "missing" badges when shutil.which fails on absolute paths.
        """
        if not cmd:
            return False
        exe = cmd[0]
        if os.path.isabs(exe):
            if not os.path.isfile(exe):
                return False
            # Interpreter + script  e.g. python3 store.py
            if len(cmd) > 1 and isinstance(cmd[1], str) and cmd[1].endswith(".py"):
                return os.path.isfile(cmd[1])
            return True
        return shutil.which(exe) is not None

    def _scan_tile_statuses(self) -> None:
        """Background thread: check each tile's command resolution, update badges.

        A tile is considered "installed" (green) when *any* command in the
        primary+fallbacks chain resolves — the launcher will try them in
        order so the user always gets a working app.  Grey only when nothing
        at all resolves — that's the real "not installed" state.
        """
        for tile, btn in zip(self._tiles, self._buttons):
            primary_ok  = self._cmd_resolves(tile.command)
            fallback_ok = any(self._cmd_resolves(fb) for fb in tile.fallbacks if fb)
            status = "ok" if (primary_ok or fallback_ok) else "missing"
            # Guard: main window may have been destroyed before we finish.
            GLib.idle_add(self._safe_set_status, btn, status)

    @staticmethod
    def _safe_set_status(btn: "TileButton", status: str) -> bool:
        try:
            if btn.get_realized() or btn.get_parent() is not None:
                btn.set_status(status)
        except Exception:
            pass
        return False

    # ------------------------------------------------------------------
    def _on_child_exit(self) -> None:
        """Called (on main thread) when a child process exits."""
        if self._loading_btn is not None:
            self._loading_btn.set_loading(False)
            self._loading_btn = None
        self._show_launcher()
        if self._buttons:
            self._buttons[self._focus_idx].grab_focus()

    def _on_launch_error(self, exe: str, tried: list) -> None:
        """Called when no candidate command resolves."""
        if self._load_screen is not None:
            self._load_screen.dismiss()
            self._load_screen = None
        if self._loading_btn is not None:
            self._loading_btn.set_loading(False)
            self._loading_btn = None
        self._notifier.notify(
            f"Cannot launch: {exe}",
            "Not installed — open Store to install it",
            "error",
        )

    # ------------------------------------------------------------------
    def _clock_str(self) -> str:
        return datetime.datetime.now().strftime("%H:%M  %a %d %b")

    def _update_clock(self) -> bool:
        self._clock_label.set_text(self._clock_str())
        return True  # keep firing

    # ------------------------------------------------------------------
    def do_delete_event(self, _event) -> bool:
        if self._watcher is not None:
            self._watcher.stop()
        if self._window_monitor is not None:
            try:
                self._window_monitor.cancel()
            except Exception:
                pass
        if self._window_refresh_source:
            try:
                GLib.source_remove(self._window_refresh_source)
            except Exception:
                pass
            self._window_refresh_source = 0
        self._launcher.terminate_all()
        try:
            Path("/tmp/zyntrix-shell.pid").unlink(missing_ok=True)
        except Exception:
            pass
        Gtk.main_quit()
        return False


# ─────────────────────────────────────────────────────────────────────────────
def main() -> None:
    # Allow running the shell without a full DE for testing
    if "DISPLAY" not in os.environ and "WAYLAND_DISPLAY" not in os.environ:
        print("No display detected. Set DISPLAY or WAYLAND_DISPLAY.", file=sys.stderr)
        sys.exit(1)

    try:
        win = ZyntrixShell()
        win.connect("destroy", Gtk.main_quit)
    except Exception as exc:
        log.exception("fatal shell startup failure")
        # Last-resort GTK window so users on weak hardware get a visible
        # failure instead of a black screen.  Details are in /tmp/zyntrix-perf.log.
        win = Gtk.Window(title="ZyntrixOS")
        win.set_default_size(520, 160)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(18)
        box.set_margin_end(18)
        box.set_margin_top(18)
        box.set_margin_bottom(18)
        title = Gtk.Label(label="ZyntrixOS could not finish loading")
        title.set_halign(Gtk.Align.START)
        body = Gtk.Label(label=f"{type(exc).__name__}: {exc}\nSee /tmp/zyntrix-perf.log")
        body.set_halign(Gtk.Align.START)
        body.set_selectable(True)
        box.pack_start(title, False, False, 0)
        box.pack_start(body, False, False, 0)
        win.add(box)
        win.connect("destroy", Gtk.main_quit)
        win.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
