#!/usr/bin/env python3
"""
ZyntrixOS Notification System.
Dunst-free GTK3 toast banners — slide in from top-right, auto-dismiss.
Also runs a background watcher for battery, disk, and apt updates.
"""

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gtk, Gdk, GLib

import os
import shutil
import subprocess
import threading
import time
from typing import Optional


def _read_ram_kb() -> int:
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1])
    except Exception:
        pass
    return 4 * 1024 * 1024


_LOW_END = (
    os.environ.get("ZYNTRIX_ULTRALOW", "").lower() in ("1", "true", "yes")
    or _read_ram_kb() <= 3 * 1024 * 1024
)

# ── Constants ─────────────────────────────────────────────────────────────────
BANNER_WIDTH  = 320
BANNER_HEIGHT = 72
BANNER_MARGIN = 16
BANNER_DURATION_MS = 4500   # auto-dismiss after this
BANNER_ANIM_MS     = 180    # slide/fade animation steps

LEVEL_INFO    = "info"
LEVEL_WARNING = "warning"
LEVEL_ERROR   = "error"

_ICONS = {
    LEVEL_INFO:    "dialog-information",
    LEVEL_WARNING: "dialog-warning",
    LEVEL_ERROR:   "dialog-error",
}


# ── Toast banner window ───────────────────────────────────────────────────────
class ToastBanner(Gtk.Window):
    """A single notification toast. Stacked by NotificationManager."""

    def __init__(self, title: str, body: str, level: str, slot: int, on_dismiss):
        super().__init__(type=Gtk.WindowType.POPUP)
        self._on_dismiss = on_dismiss
        self._slot = slot
        self._dismiss_id: Optional[int] = None

        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_keep_above(True)
        self.set_accept_focus(False)
        self.set_default_size(BANNER_WIDTH, BANNER_HEIGHT)
        self.get_style_context().add_class("toast")
        self.get_style_context().add_class(f"toast-{level}")

        # Position: top-right, stacked by slot
        self._reposition()

        # Content
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_margin_start(14)
        box.set_margin_end(14)
        box.set_margin_top(10)
        box.set_margin_bottom(10)

        icon = Gtk.Image.new_from_icon_name(_ICONS.get(level, "dialog-information"), Gtk.IconSize.LARGE_TOOLBAR)
        box.pack_start(icon, False, False, 0)

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title_lbl = Gtk.Label()
        title_lbl.set_markup(f"<b>{GLib.markup_escape_text(title)}</b>")
        title_lbl.set_halign(Gtk.Align.START)
        title_lbl.set_ellipsize(3)

        body_lbl = Gtk.Label(label=body)
        body_lbl.set_halign(Gtk.Align.START)
        body_lbl.set_ellipsize(3)
        body_lbl.get_style_context().add_class("toast-body")

        text_box.pack_start(title_lbl, False, False, 0)
        text_box.pack_start(body_lbl, False, False, 0)
        box.pack_start(text_box, True, True, 0)

        close_btn = Gtk.Button(label="✕")
        close_btn.set_relief(Gtk.ReliefStyle.NONE)
        close_btn.connect("clicked", lambda _: self.dismiss())
        close_btn.get_style_context().add_class("toast-close")
        box.pack_end(close_btn, False, False, 0)

        self.add(box)

        # Click anywhere to dismiss
        self.connect("button-press-event", lambda *_: self.dismiss())

        # Auto-dismiss timer
        self._dismiss_id = GLib.timeout_add(BANNER_DURATION_MS, self._auto_dismiss)

    def _reposition(self) -> None:
        screen = Gdk.Screen.get_default()
        if screen:
            sw = screen.get_width()
        else:
            sw = 1920
        x = sw - BANNER_WIDTH - BANNER_MARGIN
        y = BANNER_MARGIN + self._slot * (BANNER_HEIGHT + 8)
        self.move(x, y)

    def restack(self, slot: int) -> None:
        self._slot = slot
        self._reposition()

    def _auto_dismiss(self) -> bool:
        self.dismiss()
        return False

    def dismiss(self) -> None:
        if self._dismiss_id:
            GLib.source_remove(self._dismiss_id)
            self._dismiss_id = None
        self._on_dismiss(self)
        self.destroy()


# ── Notification manager ──────────────────────────────────────────────────────
class NotificationManager:
    """
    Owns all active toasts, handles stacking.
    Call notify() from any thread — it is GLib.idle_add-safe.
    """

    def __init__(self):
        self._banners: list[ToastBanner] = []
        self._lock = threading.Lock()
        self._recent: dict[tuple[str, str, str], float] = {}

    def notify(self, title: str, body: str = "", level: str = LEVEL_INFO) -> None:
        """Thread-safe: schedules banner on the GTK main loop."""
        key = (title.strip(), body.strip(), level)
        now = time.monotonic()
        with self._lock:
            last = self._recent.get(key, 0.0)
            if now - last < 2.0:
                return
            self._recent[key] = now
            stale = [item for item, seen_at in self._recent.items() if now - seen_at > 300.0]
            for item in stale:
                self._recent.pop(item, None)
        GLib.idle_add(self._show_banner, title, body, level)

    def _show_banner(self, title: str, body: str, level: str) -> bool:
        with self._lock:
            slot = len(self._banners)
            banner = ToastBanner(title, body, level, slot, self._on_banner_dismiss)
            self._banners.append(banner)
        banner.show_all()
        return False

    def _on_banner_dismiss(self, banner: ToastBanner) -> None:
        with self._lock:
            if banner in self._banners:
                self._banners.remove(banner)
            # Restack remaining
            for i, b in enumerate(self._banners):
                b.restack(i)


# ── System watcher ────────────────────────────────────────────────────────────
class SystemWatcher:
    """
    Background thread that polls battery, disk, and apt-check.
    Fires notifications via the provided NotificationManager.
    """

    POLL_INTERVAL   = 60     # seconds between checks
    BATTERY_WARN    = 20     # % threshold for low-battery warning
    BATTERY_CRIT    = 8      # % threshold for critical alert
    DISK_WARN_PCT   = 85     # % disk usage warning threshold
    UPDATE_INTERVAL = 21600 if _LOW_END else 3600   # seconds between apt-check polls

    def __init__(self, notifier: NotificationManager):
        self._notifier = notifier
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._last_battery_warned = 0
        self._last_update_check = 0
        self._last_update_notified = False

    def start(self) -> None:
        if self._running and self._thread and self._thread.is_alive():
            return
        self._running = True
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="sys-watcher"
        )
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.5)

    def _loop(self) -> None:
        if self._stop_event.wait(5.0):
            return  # let the shell settle first without pinning shutdown
        while self._running and not self._stop_event.is_set():
            try:
                self._check_battery()
                self._check_disk()
                now = time.time()
                if now - self._last_update_check >= self.UPDATE_INTERVAL:
                    self._check_updates()
                    self._last_update_check = now
            except Exception:
                pass
            if self._stop_event.wait(self.POLL_INTERVAL):
                break

    # ── Battery ────────────────────────────────────────────────────────────
    def _check_battery(self) -> None:
        pct, charging = self._read_battery()
        if pct is None or charging:
            return
        now = time.time()
        if pct <= self.BATTERY_CRIT and now - self._last_battery_warned > 120:
            self._notifier.notify(
                "Battery Critical", f"{pct}% — plug in now", LEVEL_ERROR
            )
            self._last_battery_warned = now
        elif pct <= self.BATTERY_WARN and now - self._last_battery_warned > 300:
            self._notifier.notify(
                "Battery Low", f"{pct}% remaining", LEVEL_WARNING
            )
            self._last_battery_warned = now

    @staticmethod
    def _read_battery() -> tuple[Optional[int], bool]:
        """Returns (percent, is_charging) or (None, False)."""
        bat_dirs = [
            "/sys/class/power_supply/BAT0",
            "/sys/class/power_supply/BAT1",
        ]
        for bat in bat_dirs:
            try:
                with open(f"{bat}/capacity") as _f:
                    cap = int(_f.read().strip())
                with open(f"{bat}/status") as _f:
                    status = _f.read().strip().lower()
                return cap, status in ("charging", "full")
            except Exception:
                continue
        return None, False

    # ── Disk ───────────────────────────────────────────────────────────────
    def _check_disk(self) -> None:
        try:
            st = os.statvfs("/")
            pct = int(100 * (1 - st.f_bavail / st.f_blocks))
            free_gb = (st.f_bavail * st.f_frsize) / (1024 ** 3)
            if pct >= self.DISK_WARN_PCT:
                self._notifier.notify(
                    "Disk Space Low",
                    f"{pct}% used — {free_gb:.1f} GB free on /",
                    LEVEL_WARNING,
                )
        except Exception:
            pass

    # ── Updates ────────────────────────────────────────────────────────────
    def _check_updates(self) -> None:
        if not shutil.which("apt-get"):
            return
        try:
            # Single call is enough — the previous "warm-up" run was a no-op
            # duplicate that doubled disk I/O and sometimes collided with
            # the user running apt in a terminal.
            out = subprocess.check_output(
                ["apt-get", "-q", "--just-print", "upgrade"],
                stderr=subprocess.DEVNULL, text=True, timeout=20
            )
            # Count "Inst " lines
            count = sum(1 for l in out.splitlines() if l.startswith("Inst "))
            if count > 0 and not self._last_update_notified:
                self._notifier.notify(
                    "Updates Available",
                    f"{count} package{'s' if count > 1 else ''} can be upgraded",
                    LEVEL_INFO,
                )
                self._last_update_notified = True
            elif count == 0:
                self._last_update_notified = False
        except Exception:
            pass
