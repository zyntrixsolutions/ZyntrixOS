#!/usr/bin/env python3
"""Central window lifecycle management for ZyntrixOS.

This module is the shared foundation for the app-centric desktop flow:

* Tracks X11 top-level windows with python-xlib when available.
* Mirrors herbstluftwm state (workspace, floating, fullscreen, focus).
* Exposes minimize / restore / undock / redock / close actions.
* Persists a compact live snapshot for GTK components and helper scripts.
* Provides a lightweight Unix-socket client used by the shell and switcher.
"""

from __future__ import annotations

import argparse
import atexit
import json
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

try:
    from Xlib import X, Xatom, display, error as xerror
except Exception:  # pragma: no cover - optional at runtime
    X = None
    Xatom = None
    display = None
    xerror = Exception


HC = shutil.which("herbstclient") or ""
WMCTRL = shutil.which("wmctrl") or ""

_RUNTIME_DIR = (
    os.environ.get("XDG_RUNTIME_DIR")
    or os.environ.get("TMPDIR")
    or "/tmp"
)
STATE_PATH = os.environ.get(
    "ZYNTRIX_WM_STATE",
    os.path.join(_RUNTIME_DIR, "zyntrix-wm-state.json"),
)
SOCKET_PATH = os.environ.get(
    "ZYNTRIX_WM_SOCKET",
    os.path.join(_RUNTIME_DIR, "zyntrix-wm.sock"),
)
SESSION_PATH = os.environ.get(
    "ZYNTRIX_WM_SESSION",
    os.path.join(_RUNTIME_DIR, "zyntrix-wm-session.json"),
)
MINIMIZED_TAG = os.environ.get("ZYNTRIX_WM_MINIMIZED_TAG", "minimized")

_INTERNAL_MARKERS = (
    "zyntrixos",
    "zyntrix-shell",
    "window controls",
    "zyntrix taskbar",
    "windows",
    "launch",
    "zyntrixos stats",
)
_SKIP_WINDOW_TYPES = {
    "_NET_WM_WINDOW_TYPE_DOCK",
    "_NET_WM_WINDOW_TYPE_DESKTOP",
    "_NET_WM_WINDOW_TYPE_NOTIFICATION",
    "_NET_WM_WINDOW_TYPE_MENU",
    "_NET_WM_WINDOW_TYPE_TOOLBAR",
    "_NET_WM_WINDOW_TYPE_DROPDOWN_MENU",
    "_NET_WM_WINDOW_TYPE_POPUP_MENU",
    "_NET_WM_WINDOW_TYPE_TOOLTIP",
    "_NET_WM_WINDOW_TYPE_COMBO",
    "_NET_WM_WINDOW_TYPE_DND",
}
_DIALOG_WINDOW_TYPES = {
    "_NET_WM_WINDOW_TYPE_DIALOG",
    "_NET_WM_WINDOW_TYPE_UTILITY",
    "_NET_WM_WINDOW_TYPE_SPLASH",
}
_FAST_FAIL_GRACE_S = 0.35
_PENDING_TTL_S = 18.0


def _read_ram_kb() -> int:
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1])
    except Exception:
        pass
    return 4 * 1024 * 1024


_RAM_KB = _read_ram_kb()
_LOW_END = (
    os.environ.get("ZYNTRIX_ULTRALOW", "").lower() in ("1", "true", "yes")
    or _RAM_KB <= 3 * 1024 * 1024
)
_WAIT_REFRESH_S = 0.30 if _LOW_END else 0.18
_WAIT_SLEEP_S = 0.12 if _LOW_END else 0.08


def _ensure_runtime_path(path: str) -> None:
    try:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def _run(args: list[str], timeout: float = 1.0) -> bool:
    try:
        proc = subprocess.run(
            args,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            check=False,
        )
        return proc.returncode == 0
    except Exception:
        return False


def _check_output(args: list[str], timeout: float = 1.0) -> str:
    try:
        return subprocess.check_output(
            args,
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        ).strip()
    except Exception:
        return ""


def _stable_json(data: Any) -> str:
    try:
        return json.dumps(data, sort_keys=True, separators=(",", ":"))
    except Exception:
        return ""


def _norm_wid(wid: str) -> str:
    raw = (wid or "").strip()
    if not raw:
        return ""
    try:
        return f"0x{int(raw, 16):x}"
    except Exception:
        return raw.lower()


def _slugify(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (value or "").lower()).strip("-")


def _tokenize(value: str) -> set[str]:
    if not value:
        return set()
    parts = re.split(r"[^a-z0-9]+", value.lower())
    return {p for p in parts if p}


def _basename_token(path: str) -> str:
    base = os.path.basename(path or "").strip()
    if not base:
        return ""
    base = re.sub(r"\.(py|sh|desktop)$", "", base, flags=re.IGNORECASE)
    return re.sub(r"-(esr|bin|gtk|qt)$", "", base.lower())


def _resolve_exe(exe: str) -> Optional[str]:
    if not exe:
        return None
    if os.path.isabs(exe):
        return exe if os.path.isfile(exe) else None
    return shutil.which(exe)


def _atomic_json_write(
    path: str,
    payload: dict[str, Any],
    *,
    durable: bool = True,
    pretty: bool = True,
) -> None:
    _ensure_runtime_path(path)
    directory = str(Path(path).parent)
    fd, tmp_path = tempfile.mkstemp(prefix=".zyntrix-wm-", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            dump_kwargs = {"sort_keys": True}
            if pretty:
                dump_kwargs["indent"] = 2
            else:
                dump_kwargs["separators"] = (",", ":")
            json.dump(payload, handle, **dump_kwargs)
            handle.flush()
            if durable:
                os.fsync(handle.fileno())
        os.replace(tmp_path, path)
    finally:
        try:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except Exception:
            pass


def _read_json(path: str) -> dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _read_cmdline(pid: Optional[int]) -> list[str]:
    if not pid:
        return []
    try:
        raw = Path(f"/proc/{pid}/cmdline").read_bytes()
        parts = [p.decode("utf-8", errors="replace") for p in raw.split(b"\0") if p]
        return parts
    except Exception:
        return []


def _cmdline_label(cmdline: list[str]) -> str:
    if not cmdline:
        return ""
    if len(cmdline) > 1 and cmdline[0].startswith("python"):
        stem = Path(cmdline[1]).stem
        if stem:
            return stem.replace("_", " ").title()
    base = _basename_token(cmdline[0]).replace("-", " ")
    return base.title() if base else ""


def _list_hex_tokens(line: str) -> list[str]:
    return [_norm_wid(tok) for tok in re.findall(r"0x[0-9a-fA-F]+", line or "")]


@dataclass
class WindowGeometry:
    x: int = 0
    y: int = 0
    width: int = 0
    height: int = 0


@dataclass
class WindowState:
    wid: str
    title: str = ""
    wclass: str = ""
    app_id: str = ""
    label: str = ""
    icon_name: str = ""
    workspace: str = ""
    original_tag: str = ""
    state: str = "fullscreen"
    previous_state: str = "fullscreen"
    pid: Optional[int] = None
    cmdline: list[str] = field(default_factory=list)
    launch_command: list[str] = field(default_factory=list)
    geometry: WindowGeometry = field(default_factory=WindowGeometry)
    created_at: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    last_focus: float = 0.0
    floating: bool = False
    fullscreen: bool = False
    minimized: bool = False
    focused: bool = False
    visible: bool = True
    managed: bool = True
    internal: bool = False
    urgent: bool = False
    dialog: bool = False
    launch_token: str = ""

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["geometry"] = asdict(self.geometry)
        return data

    def to_snapshot_dict(self) -> dict[str, Any]:
        data = self.to_dict()
        for key in ("last_seen", "last_focus", "launch_token", "internal"):
            data.pop(key, None)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WindowState":
        geometry = data.get("geometry") or {}
        return cls(
            wid=_norm_wid(str(data.get("wid", ""))),
            title=str(data.get("title", "")),
            wclass=str(data.get("wclass", "")),
            app_id=str(data.get("app_id", "")),
            label=str(data.get("label", "")),
            icon_name=str(data.get("icon_name", "")),
            workspace=str(data.get("workspace", "")),
            original_tag=str(data.get("original_tag", "")),
            state=str(data.get("state", "fullscreen")),
            previous_state=str(data.get("previous_state", "fullscreen")),
            pid=data.get("pid"),
            cmdline=list(data.get("cmdline") or []),
            launch_command=list(data.get("launch_command") or []),
            geometry=WindowGeometry(
                x=int(geometry.get("x", 0)),
                y=int(geometry.get("y", 0)),
                width=int(geometry.get("width", 0)),
                height=int(geometry.get("height", 0)),
            ),
            created_at=float(data.get("created_at", time.time())),
            last_seen=float(data.get("last_seen", time.time())),
            last_focus=float(data.get("last_focus", 0.0)),
            floating=bool(data.get("floating", False)),
            fullscreen=bool(data.get("fullscreen", False)),
            minimized=bool(data.get("minimized", False)),
            focused=bool(data.get("focused", False)),
            visible=bool(data.get("visible", True)),
            managed=bool(data.get("managed", True)),
            internal=bool(data.get("internal", False)),
            urgent=bool(data.get("urgent", False)),
            dialog=bool(data.get("dialog", False)),
            launch_token=str(data.get("launch_token", "")),
        )


@dataclass
class LaunchIntent:
    token: str
    command: list[str]
    fallbacks: list[list[str]] = field(default_factory=list)
    app_id: str = ""
    label: str = ""
    icon_name: str = ""
    class_hints: list[str] = field(default_factory=list)
    started_at: float = field(default_factory=time.time)
    pid: Optional[int] = None
    existing_wids: set[str] = field(default_factory=set)


class WindowManager:
    """Tracks all windows and exposes app-centric actions."""

    STATES = {
        "fullscreen": "App occupies entire screen (default on launch)",
        "floating": "App is undocked, resizable, can be moved",
        "minimized": "App is hidden, accessible only via switcher",
        "tiling": "App participates in herbstluftwm tiling (legacy mode)",
    }

    def __init__(
        self,
        *,
        minimized_tag: str = MINIMIZED_TAG,
        state_path: str = STATE_PATH,
        session_path: str = SESSION_PATH,
        enable_x11: bool = True,
    ) -> None:
        self.minimized_tag = minimized_tag
        self.state_path = state_path
        self.session_path = session_path
        self.windows: dict[str, WindowState] = {}
        self.pending_launches: list[LaunchIntent] = []
        self.focused_wid: str = ""
        self.last_active_wid: str = ""
        self._lock = threading.RLock()
        self._display = self._open_display(enable_x11)
        self._root = self._display.screen().root if self._display else None
        self._atoms: dict[str, Any] = {}
        self._tag_names_cache: list[str] = []
        self._current_workspace: str = ""
        self.workspace_text: str = ""
        self._last_snapshot_signature = ""
        self._last_snapshot_payload: dict[str, Any] = {}
        self._last_session_signature = ""

    # ------------------------------------------------------------------
    def _open_display(self, enable_x11: bool):
        if not enable_x11 or not display or not os.environ.get("DISPLAY"):
            return None
        try:
            return display.Display()
        except Exception:
            return None

    def _atom(self, name: str):
        if not self._display:
            return None
        atom = self._atoms.get(name)
        if atom is None:
            try:
                atom = self._display.intern_atom(name)
                self._atoms[name] = atom
            except Exception:
                return None
        return atom

    def xdisplay(self):
        return self._display

    def prepare_event_masks(self) -> None:
        if not self._root or X is None:
            return
        try:
            self._root.change_attributes(
                event_mask=X.SubstructureNotifyMask | X.PropertyChangeMask
            )
            self._display.flush()
        except Exception:
            return
        for child in self._iter_top_level_windows():
            self.watch_window(child)

    def watch_window(self, xwindow) -> None:
        if X is None or not xwindow:
            return
        try:
            xwindow.change_attributes(
                event_mask=(
                    X.PropertyChangeMask
                    | X.StructureNotifyMask
                    | X.FocusChangeMask
                )
            )
            self._display.flush()
        except Exception:
            pass

    def _iter_top_level_windows(self) -> list[Any]:
        if not self._root:
            return []
        try:
            return list(self._root.query_tree().children)
        except Exception:
            return []

    def _xwindow_from_wid(self, wid: str):
        if not self._display:
            return None
        target = _norm_wid(wid)
        if not target:
            return None
        try:
            return self._display.create_resource_object("window", int(target, 16))
        except Exception:
            return None

    # ------------------------------------------------------------------
    def _hc(self, args: list[str], timeout: float = 1.0) -> bool:
        return bool(HC) and _run([HC] + args, timeout=timeout)

    def _hc_out(self, args: list[str], timeout: float = 1.0) -> str:
        return _check_output([HC] + args, timeout=timeout) if HC else ""

    def _hc_bool(self, attr: str, default: bool = False) -> bool:
        raw = self._hc_out(["get_attr", attr]).lower()
        if raw in ("true", "on", "1"):
            return True
        if raw in ("false", "off", "0"):
            return False
        return default

    def _hlwm_clients(self) -> list[str]:
        raw = self._hc_out(["clients"])
        return [_norm_wid(wid) for wid in raw.split() if wid.strip()]

    def _focused_client(self) -> str:
        return _norm_wid(self._hc_out(["get_attr", "clients.focus.winid"]))

    def _tag_index(self, tag_name: str) -> Optional[int]:
        target = str(tag_name).strip()
        if not target:
            return None
        names = list(self._tag_names_cache)
        if not names:
            self._refresh_workspace_text()
            names = list(self._tag_names_cache)
        for idx, name in enumerate(names):
            if name == target:
                return idx
        # Workspace names can change at runtime; refresh once before giving up.
        self._refresh_workspace_text()
        for idx, name in enumerate(self._tag_names_cache):
            if name == target:
                return idx
        return None

    def _workspace_text_from_state(self) -> str:
        if not self._tag_names_cache:
            return ""
        used = {
            state.workspace
            for state in self.windows.values()
            if not state.internal and state.workspace and state.workspace != self.minimized_tag
        }
        parts: list[str] = []
        for name in self._tag_names_cache:
            if name == self._current_workspace:
                parts.append(f"[{name}]")
            elif name in used:
                parts.append(name)
            else:
                parts.append(f"·{name}·")
        return "  ".join(parts)

    def _refresh_workspace_text(self) -> str:
        raw = self._hc_out(["tag_status"])
        names: list[str] = []
        current = self._current_workspace
        for token in (raw or "").split("\t"):
            token = token.strip()
            if len(token) < 2:
                continue
            flag, name = token[0], token[1:]
            names.append(name)
            if flag in ("#", "!"):
                current = name
        if names:
            self._tag_names_cache = names
        self._current_workspace = current
        self.workspace_text = self._workspace_text_from_state()
        return self.workspace_text

    # ------------------------------------------------------------------
    def _prop_text(self, xwindow, atom_name: str) -> str:
        if not xwindow or Xatom is None:
            return ""
        atom = self._atom(atom_name)
        if atom is None:
            return ""
        try:
            prop = xwindow.get_full_property(atom, X.AnyPropertyType)
        except Exception:
            return ""
        if not prop or prop.value is None:
            return ""
        value = prop.value
        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace").strip("\0")
        if isinstance(value, str):
            return value.strip("\0")
        if isinstance(value, (list, tuple)):
            if atom_name == "WM_CLASS":
                parts = []
                for item in value:
                    if isinstance(item, bytes):
                        text = item.decode("utf-8", errors="replace").strip("\0")
                    else:
                        text = str(item).strip("\0")
                    if text:
                        parts.append(text)
                return ".".join(parts)
            if value and isinstance(value[0], int):
                try:
                    blob = bytes(int(v) for v in value)
                    return blob.decode("utf-8", errors="replace").replace("\0", " ").strip()
                except Exception:
                    return " ".join(str(v) for v in value)
        return str(value)

    def _prop_cardinal(self, xwindow, atom_name: str) -> Optional[int]:
        if not xwindow:
            return None
        atom = self._atom(atom_name)
        if atom is None:
            return None
        try:
            prop = xwindow.get_full_property(atom, Xatom.CARDINAL)
        except Exception:
            return None
        if not prop or not prop.value:
            return None
        try:
            return int(prop.value[0])
        except Exception:
            return None

    def _window_types(self, xwindow) -> list[str]:
        if not xwindow or Xatom is None:
            return []
        atom = self._atom("_NET_WM_WINDOW_TYPE")
        if atom is None:
            return []
        try:
            prop = xwindow.get_full_property(atom, Xatom.ATOM)
        except Exception:
            return []
        if not prop or not prop.value:
            return []
        names: list[str] = []
        for atom_id in prop.value:
            try:
                name = self._display.get_atom_name(atom_id)
            except Exception:
                continue
            if name:
                names.append(name)
        return names

    def _window_geometry(self, xwindow) -> WindowGeometry:
        if not xwindow:
            return WindowGeometry()
        try:
            geom = xwindow.get_geometry()
            x = int(getattr(geom, "x", 0))
            y = int(getattr(geom, "y", 0))
            try:
                translated = xwindow.translate_coords(self._root, 0, 0)
                x = int(translated.x)
                y = int(translated.y)
            except Exception:
                pass
            return WindowGeometry(
                x=x,
                y=y,
                width=int(getattr(geom, "width", 0)),
                height=int(getattr(geom, "height", 0)),
            )
        except Exception:
            return WindowGeometry()

    def _window_title(self, xwindow, wid: str) -> str:
        title = self._prop_text(xwindow, "_NET_WM_NAME") or self._prop_text(xwindow, "WM_NAME")
        if title:
            return title
        return self._hc_out(["get_attr", f"clients.{wid}.title"]) or wid

    def _window_class(self, xwindow, wid: str) -> str:
        wclass = self._prop_text(xwindow, "WM_CLASS")
        if wclass:
            return wclass
        return self._hc_out(["get_attr", f"clients.{wid}.class"]) or ""

    def _window_pid(self, xwindow) -> Optional[int]:
        return self._prop_cardinal(xwindow, "_NET_WM_PID")

    def _is_internal_window(
        self,
        title: str,
        wclass: str,
        window_types: list[str],
    ) -> tuple[bool, bool]:
        low = f"{title} {wclass}".lower()
        if any(marker in low for marker in _INTERNAL_MARKERS):
            return True, False
        if any(wtype in _SKIP_WINDOW_TYPES for wtype in window_types):
            return True, False
        if any(wtype in _DIALOG_WINDOW_TYPES for wtype in window_types):
            return False, True
        return False, False

    def _candidate_hints(
        self,
        command: list[str],
        *,
        app_id: str = "",
        label: str = "",
        class_hints: Optional[list[str]] = None,
    ) -> list[str]:
        hints: set[str] = set()
        if app_id:
            hints.update(_tokenize(app_id))
            hints.add(_slugify(app_id))
        if label:
            hints.update(_tokenize(label))
        if class_hints:
            for hint in class_hints:
                hints.update(_tokenize(hint))
                hints.add(_slugify(hint))
        if command:
            hints.update(_tokenize(_basename_token(command[0])))
            if len(command) > 1 and command[0].startswith("python"):
                hints.update(_tokenize(Path(command[1]).stem))
            elif len(command) > 1 and command[0] in ("bash", "sh"):
                hints.update(_tokenize(command[1]))
        return [hint for hint in hints if hint]

    def _guess_app_id(
        self,
        *,
        current: Optional[WindowState],
        wid: str,
        title: str,
        wclass: str,
        cmdline: list[str],
        dialog: bool,
    ) -> str:
        if current and current.app_id:
            return current.app_id
        if dialog:
            return ""
        parts = [wclass, title, _cmdline_label(cmdline), wid]
        for part in parts:
            slug = _slugify(part)
            if slug and slug not in ("window", wid.lower().replace("0x", "")):
                return slug
        return ""

    def _window_tokens(self, state: WindowState) -> set[str]:
        tokens = set()
        tokens.update(_tokenize(state.wclass))
        tokens.update(_tokenize(state.title))
        tokens.update(_tokenize(state.app_id))
        tokens.update(_tokenize(state.label))
        tokens.update(_tokenize(" ".join(state.cmdline)))
        return tokens

    def _record_focus(self, wid: str) -> None:
        target = _norm_wid(wid)
        if not target:
            return
        now = time.time()
        self.focused_wid = target
        for state in self.windows.values():
            state.focused = state.wid == target
        state = self.windows.get(target)
        if state and not state.internal and not state.minimized:
            state.last_focus = now
            self.last_active_wid = target
            if state.workspace:
                self._current_workspace = state.workspace
        text = self._workspace_text_from_state()
        if text or self._tag_names_cache:
            self.workspace_text = text

    def _purge_pending_intents(self) -> None:
        now = time.time()
        self.pending_launches = [
            intent
            for intent in self.pending_launches
            if now - intent.started_at < _PENDING_TTL_S
        ]

    def _match_pending_intent(self, state: WindowState) -> Optional[LaunchIntent]:
        tokens = self._window_tokens(state)
        best: Optional[LaunchIntent] = None
        best_score = 0
        for intent in list(self.pending_launches):
            if state.wid in intent.existing_wids:
                continue
            if state.created_at + 1.5 < intent.started_at:
                continue
            score = 0
            if intent.pid and state.pid and intent.pid == state.pid:
                score += 80
            overlap = tokens.intersection(intent.class_hints)
            score += len(overlap) * 15
            if intent.app_id and state.app_id and state.app_id == intent.app_id:
                score += 20
            if score > best_score:
                best = intent
                best_score = score
        if best and best_score >= 20:
            self.pending_launches = [
                intent for intent in self.pending_launches if intent.token != best.token
            ]
            return best
        return None

    # ------------------------------------------------------------------
    def refresh_window(
        self,
        wid: str,
        *,
        xwindow=None,
        write_snapshot: bool = False,
    ) -> Optional[WindowState]:
        target = _norm_wid(wid)
        if not target:
            return None
        with self._lock:
            current = self.windows.get(target)
            xwindow = xwindow or self._xwindow_from_wid(target)
            workspace = self._hc_out(["get_attr", f"clients.{target}.tag"])
            if not workspace and current and current.minimized:
                workspace = self.minimized_tag

            title = self._window_title(xwindow, target)
            wclass = self._window_class(xwindow, target)
            pid = self._window_pid(xwindow) or (current.pid if current else None)
            cmdline = _read_cmdline(pid) or (current.cmdline if current else [])
            geometry = self._window_geometry(xwindow)
            floating = self._hc_bool(f"clients.{target}.floating", current.floating if current else False)
            fullscreen = self._hc_bool(f"clients.{target}.fullscreen", current.fullscreen if current else False)
            urgent = self._hc_bool(f"clients.{target}.urgent", current.urgent if current else False)
            window_types = self._window_types(xwindow)
            internal, dialog = self._is_internal_window(title, wclass, window_types)
            if internal:
                self.windows.pop(target, None)
                if write_snapshot:
                    self.write_snapshot()
                return None

            created_at = current.created_at if current else time.time()
            visible = True
            minimized = workspace == self.minimized_tag
            if minimized:
                state_name = "minimized"
            elif floating:
                state_name = "floating"
            elif fullscreen:
                state_name = "fullscreen"
            else:
                state_name = "tiling"

            state = WindowState(
                wid=target,
                title=title or (current.title if current else target),
                wclass=wclass or (current.wclass if current else ""),
                app_id=self._guess_app_id(
                    current=current,
                    wid=target,
                    title=title,
                    wclass=wclass,
                    cmdline=cmdline,
                    dialog=dialog,
                ),
                label=current.label if current else "",
                icon_name=current.icon_name if current else "",
                workspace=workspace or (current.workspace if current else ""),
                original_tag=(
                    current.original_tag
                    if current and current.original_tag
                    else (workspace if workspace and workspace != self.minimized_tag else "")
                ),
                state=state_name,
                previous_state=current.previous_state if current else state_name,
                pid=pid,
                cmdline=list(cmdline),
                launch_command=list(current.launch_command if current else []),
                geometry=geometry,
                created_at=created_at,
                last_seen=time.time(),
                last_focus=current.last_focus if current else 0.0,
                floating=floating,
                fullscreen=fullscreen,
                minimized=minimized,
                focused=current.focused if current else False,
                visible=visible,
                managed=bool(workspace or wclass or title),
                internal=False,
                urgent=urgent,
                dialog=dialog,
                launch_token=current.launch_token if current else "",
            )

            intent = self._match_pending_intent(state)
            if intent:
                if intent.app_id:
                    state.app_id = intent.app_id
                if intent.label:
                    state.label = intent.label
                if intent.icon_name:
                    state.icon_name = intent.icon_name
                state.launch_command = list(intent.command)
                state.launch_token = intent.token
                self._apply_default_window_state(state.wid, dialog=dialog)
                floating = self._hc_bool(f"clients.{target}.floating", state.floating)
                fullscreen = self._hc_bool(f"clients.{target}.fullscreen", state.fullscreen)
                state.floating = floating
                state.fullscreen = fullscreen
                if not state.minimized:
                    state.state = "floating" if floating else ("fullscreen" if fullscreen else "tiling")

            if not state.label:
                state.label = _cmdline_label(state.launch_command or state.cmdline) or state.title
            if not state.icon_name:
                state.icon_name = state.app_id or _basename_token((state.cmdline or [""])[0])

            self.windows[target] = state
            if state.workspace and state.workspace != self.minimized_tag and not state.minimized:
                state.original_tag = state.workspace
            self._sync_focus_state_locked()
            if write_snapshot:
                self.save_session()
                self.write_snapshot()
            return state

    def refresh_all(self, *, persist: bool = True) -> list[WindowState]:
        with self._lock:
            seen: set[str] = set()
            for xwindow in self._iter_top_level_windows():
                try:
                    wid = f"0x{xwindow.id:x}"
                except Exception:
                    continue
                self.watch_window(xwindow)
                state = self.refresh_window(wid, xwindow=xwindow, write_snapshot=False)
                if state:
                    seen.add(state.wid)

            for wid in self._hlwm_clients():
                state = self.refresh_window(wid, write_snapshot=False)
                if state:
                    seen.add(state.wid)

            for wid in list(self.windows):
                if wid not in seen:
                    self.windows.pop(wid, None)

            self._sync_focus_state_locked()
            self._purge_pending_intents()
            self._refresh_workspace_text()
            if persist:
                self.save_session()
                self.write_snapshot()
            return self.get_all_windows()

    def _sync_focus_state_locked(self) -> None:
        focused = self._focused_client() or self.focused_wid
        self.focused_wid = focused
        now = time.time()
        for state in self.windows.values():
            state.focused = state.wid == focused
        if focused and focused in self.windows:
            state = self.windows[focused]
            if not state.internal and not state.minimized:
                state.last_focus = max(state.last_focus, now)
                self.last_active_wid = focused
                if state.workspace:
                    self._current_workspace = state.workspace
        elif not self.last_active_wid:
            choices = [
                state for state in self.windows.values()
                if not state.internal and not state.minimized
            ]
            if choices:
                latest = max(choices, key=lambda item: item.last_focus or item.created_at)
                self.last_active_wid = latest.wid
        text = self._workspace_text_from_state()
        if text or self._tag_names_cache:
            self.workspace_text = text

    # ------------------------------------------------------------------
    def _apply_default_window_state(self, wid: str, *, dialog: bool = False) -> None:
        target = _norm_wid(wid)
        if not target or dialog:
            return
        self._hc(
            [
                "chain",
                ",",
                "set_attr",
                f"clients.{target}.floating",
                "false",
                ",",
                "set_attr",
                f"clients.{target}.fullscreen",
                "true",
                ",",
                "raise",
                target,
                ",",
                "jumpto",
                target,
            ]
        )

    def _spawn_candidate(self, command: list[str]) -> Optional[subprocess.Popen]:
        if not command or not _resolve_exe(command[0]):
            return None
        env = os.environ.copy()
        try:
            return subprocess.Popen(
                command,
                env=env,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            return None

    def find_duplicate(
        self,
        command: list[str],
        *,
        app_id: str = "",
        label: str = "",
        class_hints: Optional[list[str]] = None,
    ) -> Optional[WindowState]:
        with self._lock:
            self._purge_pending_intents()
            hints = set(self._candidate_hints(command, app_id=app_id, label=label, class_hints=class_hints))
            scored: list[tuple[int, float, WindowState]] = []
            for state in self.windows.values():
                if state.internal or not state.managed:
                    continue
                score = 0
                if app_id and state.app_id == app_id:
                    score += 80
                if label and _slugify(label) == _slugify(state.label):
                    score += 20
                overlap = hints.intersection(self._window_tokens(state))
                score += len(overlap) * 12
                if state.launch_command and command:
                    left = _basename_token(command[0])
                    right = _basename_token(state.launch_command[0])
                    if left and left == right:
                        score += 15
                elif state.cmdline and command:
                    left = _basename_token(command[0])
                    right = _basename_token(state.cmdline[0])
                    if left and left == right:
                        score += 10
                if score > 0:
                    scored.append((score, state.last_focus or state.created_at, state))
            if not scored:
                return None
            scored.sort(key=lambda item: (item[0], item[1]), reverse=True)
            return scored[0][2]

    def wait_for_window(
        self,
        command: list[str],
        *,
        app_id: str = "",
        label: str = "",
        class_hints: Optional[list[str]] = None,
        timeout: float = 6.0,
    ) -> Optional[WindowState]:
        deadline = time.time() + timeout
        next_refresh = 0.0
        while time.time() < deadline:
            match = self.find_duplicate(
                command,
                app_id=app_id,
                label=label,
                class_hints=class_hints,
            )
            if match:
                return match
            now = time.monotonic()
            if now >= next_refresh:
                self.refresh_all(persist=False)
                next_refresh = now + _WAIT_REFRESH_S
            time.sleep(_WAIT_SLEEP_S)
        return None

    def launch_app(
        self,
        command: list[str],
        fallbacks: Optional[list[list[str]]] = None,
        *,
        app_id: str = "",
        label: str = "",
        icon_name: str = "",
        class_hints: Optional[list[str]] = None,
        wait_window: bool = True,
        timeout: float = 6.0,
    ) -> dict[str, Any]:
        fallbacks = fallbacks or []
        self.refresh_all(persist=False)
        duplicate = self.find_duplicate(
            command,
            app_id=app_id,
            label=label,
            class_hints=class_hints,
        )
        if duplicate:
            if duplicate.minimized:
                self.restore(duplicate.wid)
                result = {"ok": True, "status": "restored", "wid": duplicate.wid}
            else:
                self.focus(duplicate.wid)
                result = {"ok": True, "status": "existing", "wid": duplicate.wid}
            self.write_snapshot()
            return result

        candidates = [command] + list(fallbacks)
        tried: list[str] = []
        for candidate in candidates:
            if not candidate:
                continue
            tried.append(shlex.join(candidate))
            proc = self._spawn_candidate(candidate)
            if proc is None:
                continue
            time.sleep(_FAST_FAIL_GRACE_S)
            if proc.poll() is not None and proc.returncode not in (0, None):
                continue

            intent = LaunchIntent(
                token=uuid.uuid4().hex,
                command=list(candidate),
                fallbacks=[list(fb) for fb in fallbacks],
                app_id=app_id or _slugify(label or _cmdline_label(candidate)),
                label=label or _cmdline_label(candidate),
                icon_name=icon_name,
                class_hints=self._candidate_hints(
                    candidate,
                    app_id=app_id,
                    label=label,
                    class_hints=class_hints,
                ),
                started_at=time.time(),
                pid=proc.pid,
                existing_wids=set(self.windows),
            )
            with self._lock:
                self.pending_launches.append(intent)
            if wait_window:
                matched = self.wait_for_window(
                    candidate,
                    app_id=intent.app_id,
                    label=intent.label,
                    class_hints=intent.class_hints,
                    timeout=timeout,
                )
                if matched:
                    self.save_session()
                    self.write_snapshot()
                    return {
                        "ok": True,
                        "status": "launched",
                        "wid": matched.wid,
                        "pid": proc.pid,
                        "command": candidate,
                    }
            return {
                "ok": True,
                "status": "launched",
                "pid": proc.pid,
                "command": candidate,
            }

        return {
            "ok": False,
            "status": "error",
            "error": "launch_failed",
            "tried": tried,
        }

    # ------------------------------------------------------------------
    def focus(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        state = self.windows.get(target)
        if state and state.minimized:
            return self.restore(target)
        if HC:
            self._hc(["chain", ",", "jumpto", target, ",", "raise", target])
        elif WMCTRL:
            _run([WMCTRL, "-ia", target], timeout=0.8)
        with self._lock:
            self._record_focus(target)
            self.write_snapshot()
        return True

    def minimize(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        with self._lock:
            state = self.windows.get(target) or self.refresh_window(target)
            if not state:
                return False
            if state.workspace and state.workspace != self.minimized_tag:
                state.original_tag = state.workspace
            min_index = self._tag_index(self.minimized_tag)
            if min_index is None:
                return False
            ok = self._hc(["move_index", str(min_index), target])
            if not ok:
                return False
            state.workspace = self.minimized_tag
            state.minimized = True
            state.visible = False
            state.state = "minimized"
            state.focused = False
            text = self._workspace_text_from_state()
            if text or self._tag_names_cache:
                self.workspace_text = text
            self.write_snapshot()
            self.save_session()
            return True

    def restore(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        with self._lock:
            state = self.windows.get(target) or self.refresh_window(target)
            if not state:
                return False
            tag = state.original_tag or "1"
            idx = self._tag_index(tag)
            if idx is None:
                return False
            ok = self._hc(["move_index", str(idx), target])
            if not ok:
                return False
            self._hc(["use_index", str(idx)])
            self._hc(["chain", ",", "jumpto", target, ",", "raise", target])
            state.workspace = tag
            state.minimized = False
            state.visible = True
            state.state = state.previous_state if state.previous_state != "minimized" else "fullscreen"
            self._record_focus(target)
            self.write_snapshot()
            self.save_session()
            return True

    def undock(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        with self._lock:
            state = self.windows.get(target) or self.refresh_window(target)
            if not state:
                return False
            if state.state != "floating":
                state.previous_state = state.state or "fullscreen"
            ok = self._hc(
                [
                    "chain",
                    ",",
                    "set_attr",
                    f"clients.{target}.fullscreen",
                    "false",
                    ",",
                    "set_attr",
                    f"clients.{target}.floating",
                    "true",
                    ",",
                    "set_attr",
                    f"clients.{target}.pseudotile",
                    "true",
                    ",",
                    "raise",
                    target,
                    ",",
                    "jumpto",
                    target,
                ]
            )
            if not ok:
                return False
            state.floating = True
            state.fullscreen = False
            state.minimized = False
            state.state = "floating"
            self._record_focus(target)
            self.write_snapshot()
            return True

    def redock(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        with self._lock:
            state = self.windows.get(target) or self.refresh_window(target)
            if not state:
                return False
            next_state = state.previous_state if state.previous_state in ("fullscreen", "tiling") else "fullscreen"
            ok = self._hc(
                [
                    "chain",
                    ",",
                    "set_attr",
                    f"clients.{target}.floating",
                    "false",
                    ",",
                    "set_attr",
                    f"clients.{target}.pseudotile",
                    "false",
                    ",",
                    "set_attr",
                    f"clients.{target}.fullscreen",
                    "true" if next_state == "fullscreen" else "false",
                    ",",
                    "raise",
                    target,
                    ",",
                    "jumpto",
                    target,
                ]
            )
            if not ok:
                return False
            state.floating = False
            state.fullscreen = next_state == "fullscreen"
            state.minimized = False
            state.state = next_state
            self._record_focus(target)
            self.write_snapshot()
            return True

    def toggle_undock(self, wid: str) -> bool:
        target = _norm_wid(wid)
        state = self.windows.get(target) or self.refresh_window(target)
        if not state:
            return False
        return self.redock(target) if state.state == "floating" else self.undock(target)

    def close(self, wid: str) -> bool:
        target = _norm_wid(wid)
        if not target:
            return False
        state = self.windows.get(target) or self.refresh_window(target)
        if HC:
            self._hc(["close", target])
        elif WMCTRL:
            _run([WMCTRL, "-ic", target], timeout=0.8)
        deadline = time.time() + 1.5
        while time.time() < deadline:
            self.refresh_all(persist=False)
            if target not in self.windows:
                self.save_session()
                self.write_snapshot()
                return True
            time.sleep(_WAIT_SLEEP_S)
        pid = state.pid if state else None
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
        deadline = time.time() + 1.5
        while time.time() < deadline:
            self.refresh_all(persist=False)
            if target not in self.windows:
                self.save_session()
                self.write_snapshot()
                return True
            time.sleep(_WAIT_SLEEP_S)
        if pid:
            try:
                os.kill(pid, signal.SIGKILL)
            except Exception:
                pass
        self.refresh_all()
        return target not in self.windows

    def move_to_workspace(self, wid: str, workspace: str) -> bool:
        target = _norm_wid(wid)
        tag_name = str(workspace).strip()
        idx = self._tag_index(tag_name)
        if not target or idx is None:
            return False
        ok = self._hc(["move_index", str(idx), target])
        if not ok:
            return False
        with self._lock:
            state = self.windows.get(target)
            if state:
                state.workspace = tag_name
                state.original_tag = tag_name
                state.minimized = tag_name == self.minimized_tag
                state.state = "minimized" if state.minimized else state.state
            text = self._workspace_text_from_state()
            if text or self._tag_names_cache:
                self.workspace_text = text
            self.write_snapshot()
            self.save_session()
        return True

    def minimize_all(self) -> bool:
        targets = [
            state.wid
            for state in self.get_all_windows()
            if not state.internal and not state.minimized
        ]
        changed = False
        for wid in targets:
            changed = self.minimize(wid) or changed
        return changed

    def close_all(self) -> bool:
        targets = [state.wid for state in self.get_all_windows() if not state.internal]
        changed = False
        for wid in targets:
            changed = self.close(wid) or changed
        return changed

    def show_desktop(self) -> bool:
        return self.minimize_all()

    # ------------------------------------------------------------------
    def get_all_windows(self) -> list[WindowState]:
        with self._lock:
            return sorted(
                self.windows.values(),
                key=lambda state: (state.last_focus or state.created_at, state.created_at),
                reverse=True,
            )

    def _snapshot_body(self) -> dict[str, Any]:
        windows = [state.to_snapshot_dict() for state in self.get_all_windows() if not state.internal]
        minimized = sum(1 for state in self.windows.values() if state.minimized and not state.internal)
        floating = sum(1 for state in self.windows.values() if state.state == "floating" and not state.internal)
        workspace_text = self._workspace_text_from_state() or self.workspace_text
        if workspace_text != self.workspace_text:
            self.workspace_text = workspace_text
        return {
            "focused_wid": self.focused_wid,
            "last_active_wid": self.last_active_wid,
            "minimized_tag": self.minimized_tag,
            "workspace_text": workspace_text,
            "counts": {
                "open": len(windows),
                "minimized": minimized,
                "floating": floating,
            },
            "windows": windows,
        }

    def snapshot(self) -> dict[str, Any]:
        return {"generated_at": time.time(), **self._snapshot_body()}

    def write_snapshot(self, *, force: bool = False) -> dict[str, Any]:
        body = self._snapshot_body()
        signature = _stable_json(body)
        if (
            not force
            and signature
            and signature == self._last_snapshot_signature
            and self._last_snapshot_payload
        ):
            return dict(self._last_snapshot_payload)
        payload = {"generated_at": time.time(), **body}
        _atomic_json_write(self.state_path, payload, durable=False, pretty=False)
        self._last_snapshot_signature = signature
        self._last_snapshot_payload = dict(payload)
        return payload

    def save_session(self, *, force: bool = False) -> None:
        restorable: list[dict[str, Any]] = []
        for state in self.get_all_windows():
            if state.internal or state.dialog or not state.managed:
                continue
            command = state.launch_command or state.cmdline
            if not command:
                continue
            restorable.append(
                {
                    "app_id": state.app_id,
                    "label": state.label,
                    "command": command,
                    "workspace": state.original_tag or state.workspace,
                    "state": state.state,
                }
            )
        body = {"windows": restorable}
        signature = _stable_json(body)
        if not force and signature and signature == self._last_session_signature:
            return
        _atomic_json_write(
            self.session_path,
            {
                "saved_at": time.time(),
                **body,
            },
            durable=False,
            pretty=False,
        )
        self._last_session_signature = signature

    def restore_session(self) -> int:
        data = _read_json(self.session_path)
        windows = data.get("windows") or []
        count = 0
        for entry in windows:
            command = list(entry.get("command") or [])
            if not command:
                continue
            self.launch_app(
                command,
                app_id=str(entry.get("app_id", "")),
                label=str(entry.get("label", "")),
                wait_window=False,
            )
            count += 1
            time.sleep(0.35)
        return count

    @staticmethod
    def load_snapshot(path: str = STATE_PATH) -> dict[str, Any]:
        return _read_json(path)


class WindowManagerClient:
    """Thin synchronous client for the wm daemon with connection reuse."""

    def __init__(
        self,
        *,
        socket_path: str = SOCKET_PATH,
        state_path: str = STATE_PATH,
    ) -> None:
        self.socket_path = socket_path
        self.state_path = state_path
        self._lock = threading.Lock()
        self._socket: Optional[socket.socket] = None
        self._stream = None
        atexit.register(self.close)

    def close(self) -> None:
        with self._lock:
            self._close_locked()

    def _close_locked(self) -> None:
        try:
            if self._stream is not None:
                self._stream.close()
        except Exception:
            pass
        try:
            if self._socket is not None:
                self._socket.close()
        except Exception:
            pass
        self._stream = None
        self._socket = None

    def _connect_locked(self) -> None:
        if self._socket is not None and self._stream is not None:
            return
        client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        client.settimeout(3.0)
        client.connect(self.socket_path)
        self._socket = client
        self._stream = client.makefile("rwb", buffering=0)

    def _request(self, action: str, **payload: Any) -> dict[str, Any]:
        if not self.socket_path:
            return {}
        message = (json.dumps({"action": action, **payload}) + "\n").encode("utf-8")
        with self._lock:
            for _attempt in range(2):
                try:
                    self._connect_locked()
                    assert self._stream is not None
                    self._stream.write(message)
                    self._stream.flush()
                    raw = self._stream.readline(262144)
                    if not raw:
                        raise BrokenPipeError("wm daemon closed socket")
                    text = raw.decode("utf-8", errors="replace").strip()
                    return json.loads(text) if text else {}
                except Exception:
                    self._close_locked()
            return {}

    def ensure_daemon(self) -> bool:
        pong = self._request("ping")
        if pong.get("ok"):
            return True
        daemon_script = os.path.join(os.path.dirname(__file__), "wm_daemon.py")
        if not os.path.isfile(daemon_script):
            return False
        try:
            subprocess.Popen(
                [sys.executable, daemon_script],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            return False
        deadline = time.time() + 4.0
        while time.time() < deadline:
            pong = self._request("ping")
            if pong.get("ok"):
                return True
            time.sleep(0.12)
        return False

    def snapshot(self) -> dict[str, Any]:
        response = self._request("snapshot")
        if response.get("ok") and isinstance(response.get("snapshot"), dict):
            return response["snapshot"]
        return WindowManager.load_snapshot(self.state_path)

    def get_all_windows(self) -> list[WindowState]:
        snapshot = self.snapshot()
        return [
            WindowState.from_dict(item)
            for item in snapshot.get("windows") or []
            if isinstance(item, dict)
        ]

    def last_active_window(self) -> Optional[WindowState]:
        snapshot = self.snapshot()
        target = _norm_wid(str(snapshot.get("last_active_wid", "")))
        windows = [
            WindowState.from_dict(item)
            for item in snapshot.get("windows") or []
            if isinstance(item, dict)
        ]
        for state in windows:
            if state.wid == target:
                return state
        return windows[0] if windows else None

    def launch_app(
        self,
        command: list[str],
        fallbacks: Optional[list[list[str]]] = None,
        *,
        app_id: str = "",
        label: str = "",
        icon_name: str = "",
        class_hints: Optional[list[str]] = None,
        wait_window: bool = True,
        timeout: float = 6.0,
    ) -> dict[str, Any]:
        response = self._request(
            "launch",
            command=command,
            fallbacks=fallbacks or [],
            app_id=app_id,
            label=label,
            icon_name=icon_name,
            class_hints=class_hints or [],
            wait_window=wait_window,
            timeout=timeout,
        )
        if response:
            return response
        manager = WindowManager(enable_x11=bool(os.environ.get("DISPLAY")))
        return manager.launch_app(
            command,
            fallbacks,
            app_id=app_id,
            label=label,
            icon_name=icon_name,
            class_hints=class_hints,
            wait_window=wait_window,
            timeout=timeout,
        )

    def focus(self, wid: str) -> bool:
        response = self._request("focus", wid=wid)
        return bool(response.get("ok"))

    def minimize(self, wid: str) -> bool:
        response = self._request("minimize", wid=wid)
        return bool(response.get("ok"))

    def restore(self, wid: str) -> bool:
        response = self._request("restore", wid=wid)
        return bool(response.get("ok"))

    def undock(self, wid: str) -> bool:
        response = self._request("undock", wid=wid)
        return bool(response.get("ok"))

    def redock(self, wid: str) -> bool:
        response = self._request("redock", wid=wid)
        return bool(response.get("ok"))

    def toggle_undock(self, wid: str) -> bool:
        response = self._request("toggle-undock", wid=wid)
        return bool(response.get("ok"))

    def close(self, wid: str) -> bool:
        response = self._request("close", wid=wid)
        return bool(response.get("ok"))

    def move_to_workspace(self, wid: str, workspace: str) -> bool:
        response = self._request("move", wid=wid, workspace=str(workspace))
        return bool(response.get("ok"))

    def minimize_all(self) -> bool:
        response = self._request("minimize-all")
        return bool(response.get("ok"))

    def close_all(self) -> bool:
        response = self._request("close-all")
        return bool(response.get("ok"))

    def restore_session(self) -> bool:
        response = self._request("restore-session")
        return bool(response.get("ok"))


def _cli_print(payload: dict[str, Any]) -> int:
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0 if payload.get("ok", True) else 1


def _resolve_cli_wid(wid: Optional[str], client: WindowManagerClient) -> str:
    target = _norm_wid(wid or "")
    if target:
        return target
    snapshot = client.snapshot()
    target = _norm_wid(str(snapshot.get("focused_wid", "")))
    if target:
        return target
    if HC:
        target = _norm_wid(_check_output([HC, "get_attr", "clients.focus.winid"]))
    return target


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ZyntrixOS window manager client")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("snapshot")

    launch = sub.add_parser("launch")
    launch.add_argument("--app-id", default="")
    launch.add_argument("--label", default="")
    launch.add_argument("--icon-name", default="")
    launch.add_argument("--timeout", type=float, default=6.0)
    launch.add_argument("--no-wait", action="store_true")
    launch.add_argument("argv", nargs=argparse.REMAINDER)

    for name in ("focus", "minimize", "restore", "undock", "redock", "toggle-undock", "close"):
        cmd = sub.add_parser(name)
        cmd.add_argument("wid", nargs="?")

    move = sub.add_parser("move")
    move.add_argument("wid")
    move.add_argument("workspace")

    sub.add_parser("minimize-all")
    sub.add_parser("close-all")
    sub.add_parser("restore-session")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    client = WindowManagerClient()
    client.ensure_daemon()

    if args.command == "snapshot":
        return _cli_print({"ok": True, "snapshot": client.snapshot()})
    if args.command == "launch":
        argv = list(args.argv)
        if argv and argv[0] == "--":
            argv = argv[1:]
        result = client.launch_app(
            argv,
            app_id=args.app_id,
            label=args.label,
            icon_name=args.icon_name,
            wait_window=not args.no_wait,
            timeout=args.timeout,
        )
        return _cli_print(result)
    if args.command == "move":
        return _cli_print(
            {"ok": client.move_to_workspace(args.wid, args.workspace), "wid": args.wid}
        )
    if args.command == "minimize-all":
        return _cli_print({"ok": client.minimize_all()})
    if args.command == "close-all":
        return _cli_print({"ok": client.close_all()})
    if args.command == "restore-session":
        return _cli_print({"ok": client.restore_session()})

    action = getattr(client, args.command.replace("-", "_"))
    target = _resolve_cli_wid(getattr(args, "wid", ""), client)
    return _cli_print({"ok": bool(action(target)), "wid": target})


if __name__ == "__main__":
    raise SystemExit(main())
